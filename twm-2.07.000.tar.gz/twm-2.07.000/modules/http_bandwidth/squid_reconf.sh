#!/bin/bash

. /etc/rc.status
RC_OPTIONS='-v'
rc_reset

SQUID_BIN=`perl $TWMFOLDER/bin/get_varValue.pl squid http_logging`
SQUID_CONF=$1

if [ -e $SQUID_CONF ]; then
	if checkproc $SQUID_BIN ; then
		rc_status $RC_OPTIONS
		$SQUID_BIN -f $SQUID_CONF -k reconfigure
	fi
else
	echo "Could not find file $SQUID_BIN"
fi

exit 0
