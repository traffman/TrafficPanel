#!/bin/sh

httpr_sl=$TWMFOLDER/modules/http_ip_limit/httpr_sl

set -e

case $1 in
start)
	if [ -e $httpr_sl ]; then
		$httpr_sl start
	else
		echo "Could not find file: $httpr_sl"
	fi
        ;;
stop)
	if [ -e "$httpr_sl" ]; then
		$httpr_sl stop
	else
		echo "Could not find file: $httpr_sl"
	fi
        ;;
reconf)
	if [ -e "$httpr_sl" ]; then
#		$httpr_sl restart
# need run as daemon to avoid apache wait finishing $httpr_sl process. or need use bin/forker
#		$httpr_sl restart 2>&1 >/dev/null &
		$TWMFOLDER/bin/forker $TWMFOLDER $httpr_sl restart
	else
		echo "Could not find file: $httpr_sl"
	fi
        ;;
restart)
	if [ -e "$httpr_sl" ]; then
		$httpr_sl restart
	else
		echo "Could not find file: $httpr_sl"
	fi
        ;;
*)
	N=/etc/init.d/$NAME
	echo "Usage: $N {start|stop|restart|reconf}" >&2
	exit 1
	;;
esac

exit 0

