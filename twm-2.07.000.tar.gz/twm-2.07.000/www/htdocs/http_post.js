// HTTPPost initialization
// ctype - content type
// encode - encoding
function HTTPPost(ctype, encode)	{
	if (ctype)
		this.ContentType = ctype;
	else
		this.ContentType = 'application/x-www-form-urlencoded';

	if (encode)
		this.Encoding = encode;
	else
		this.Encoding = 'UTF-8'; //ISO-8859-1

	this.httpRequest = null;
	try	{
		if (typeof ActiveXObject != 'undefined')	{
			this.httpRequest = new ActiveXObject('Microsoft.XMLHTTP');//Microsoft.XMLHTTP or Msxml2.XMLHTTP
		}else if (typeof XMLHttpRequest != 'undefined')	{
			this.httpRequest = new XMLHttpRequest();
		}
	}catch(e)	{
		alert("Your browser security does not allow to create required object. If you are IE user please enable 'Initialize and script ActiveX controls not marked as safe'")
	}
	this.postData = HTTPPost_postData;
	this.encodeValue = HTTPPost_encodeValue;
	this.showResponseText = HTTPPost_showResponseText;
	this.abort = HTTPPost_abort;
}


function HTTPPost_abort()	{
	this.httpRequest.abort();
}


// send AJAX POST request
// url - AJAX script url
// data - submited data
// callback - request processor
// async - false if sync method
function HTTPPost_postData(url, data, callback, async)	{
	var httpRequest = this.httpRequest;
	if (httpRequest)	{
		if (async == null)
			async = true;
		httpRequest.open('POST', url, async);
		if (async)	{
			httpRequest.onreadystatechange = function()	{
				callback(httpRequest);
			}
		}
		httpRequest.setRequestHeader('Content-Type',this.ContentType);
		httpRequest.setRequestHeader('Accept-Encoding',this.Encoding);
		var requestBody = '';
		if (typeof data != 'string')	{
			for (var argName in data)	{
				var encodedArgName = this.encodeValue(argName);
				var value = data[argName];
				if (typeof value == 'object')	{
					for (var i = 0; i < value.length; i++) {
						requestBody += encodedArgName + '=' + this.encodeValue(value[i]) + '&';
					}
				}else	{
					requestBody += encodedArgName + '=' + this.encodeValue(value) + '&';
				}
			}
			requestBody = requestBody.substring(0, requestBody.length - 1);
		}else	{
			requestBody = data;
		}
		httpRequest.send(requestBody);
		if (!async)	{
			callback(httpRequest);
		}
	}
}

// encode value
function HTTPPost_encodeValue(value)	{
	if (typeof encodeURIComponent != 'undefined')	{
		return encodeURIComponent(value);
	}else	{
		return escape(value);
	}
}

// alert response text
function HTTPPost_showResponseText() {
   alert(this.httpRequest.responseText);
}

// Usage examples
//postData('test.php', 'GOD=Kibo&devil=Xibo', showResponseText);
//postData('test.php', {'GOD': 'Kibo', 'devil': 'Xibo'},showResponseText);
//postData('test.php', {'riders': ['Lance', 'Jan', 'Erik'],'year': 2004}, showResponseText);


function getXMLData(p1)	{
	return (p1 && p1[0] && p1[0].firstChild)?p1[0].firstChild.data:'';
}
