#!/bin/bash

cbq=$TWMFOLDER/modules/shaping_cbq/cbq.init

set -e

case $1 in
start)
	if [ -e $cbq ]; then
		$cbq restart nocache
	else
		echo "Could not find file: $cbq"
	fi
        ;;
stop)
	if [ -e "$cbq" ]; then
		$cbq stop
	else
		echo "Could not find file: $cbq"
	fi
        ;;
reconf)
        ;;
restart)
        shift
        $0 stop
        $0 start "$@"
        ;;
*)
	N=/etc/init.d/$NAME
	echo "Usage: $N {start|stop|restart|reconf}" >&2
	exit 1
	;;
esac

exit 0
