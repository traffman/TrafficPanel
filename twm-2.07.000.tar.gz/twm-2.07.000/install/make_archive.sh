#!/bin/bash

cd /root/TWM/release
version=`cat version.conf | grep "version=" | sed -e "s/version=//g"`
cd ../
mv release twm-$version

#cp -Rf twm-$version twm-$version-apache
#tar -czf twm-$version-apache.tar.gz twm-$version-apache

mv twm-$version/install/configure_VHOST.sh twm-$version/install/configure.sh
rm -Rf twm-$version/install/src/apache
rm -Rf twm-$version/install/configure_x86_64.sh
rm -Rf twm-$version/install/apache_setup.sh
tar -czf twm-$version.tar.gz twm-$version

