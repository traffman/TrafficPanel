#!/bin/bash



cd ../

release_folder=/root/TWM/release



rm -Rf $release_folder
mkdir $release_folder

mkdir $release_folder/backup
mkdir $release_folder/logs
mkdir $release_folder/etc
while read item ; do
	cp -RHfp ./$item $release_folder
done <<!
bin
install
modules
template
www
license.txt
version.conf
!

echo "" > $release_folder/etc/passwd
cat bin/twm.sh | sed 's|/usr/local/twm|TWMFOLDER|' > $release_folder/bin/twm.sh
cat bin/init.sh | sed 's|/usr/local/twm|TWMFOLDER|' > $release_folder/bin/init.sh
cat bin/set_logs_permission.sh | sed 's|chown root:apachetwm|chown APACHE_USER:APACHE_GROUP|' > $release_folder/bin/set_logs_permission.sh


cd $release_folder

rm -Rf modules/http_logging/logs
rm -Rf modules/http_top/logs
rm -Rf modules/tcp_logging/logs
rm -Rf modules/if_meter/logs
find ./ | grep -E "\/logs\/|\.log|./.svn|.BAK|.swp|_old." | while read item ; do
	if [ -e "$item" ]; then
		rm -Rf $item
	fi
done


while read item ; do
	rm -Rf $item
done <<!
bin/ip.conf
bin/masquarading.sh
bin/forker
bin/runner
modules/close_ports/conf/*
modules/http_bandwidth/conf/*
modules/http_ip_limit/conf/*
modules/http_ip_limit/logs/*
modules/http_logging/conf/*
modules/http_traffic_limit/conf/*
modules/if_meter/logs/*
modules/mac_filtering/conf/*
modules/port_mapping/conf/*
modules/shaping_cbq/cbq/*
modules/shaping_cbq/conf/*
modules/tcp_logging/conf/*
modules/traffic_routing/conf/*
modules/vpn_traffic/conf/*
modules/traffic_routing/masquearading.sh
template/kernel/scand.ca
template/kernel/scand.lan
!

echo "<?xml version='1.0' standalone='yes'?><config><items></items></config>" > bin/ip.conf
echo '#!/bin/bash' > bin/masquarading.sh
while read item ; do
	echo "<?xml version='1.0' standalone='yes'?><config></config>" > $item
done <<!
modules/tcp_logging/conf/limit.xml
modules/http_bandwidth/conf/acl.xml
modules/http_bandwidth/conf/pool.xml
modules/close_ports/conf/ports.xml
modules/http_ip_limit/conf/httpr_sl.xml
modules/http_ip_limit/conf/ignore.xml
modules/http_traffic_limit/conf/pool.xml
modules/mac_filtering/conf/blocked.xml
modules/port_mapping/conf/ports.xml
modules/shaping_cbq/conf/config.xml
modules/tcp_logging/conf/limit.xml
modules/traffic_routing/conf/rules.conf
modules/traffic_routing/conf/services.xml
modules/vpn_traffic/conf/hosts.xml
!




mkdir modules/http_logging/logs
mkdir modules/http_top/logs
mkdir modules/tcp_logging/logs
mkdir modules/if_meter/logs


grep -R scand ./*
echo "Go to $release_folder Remove all SCAND email addresses, ppp3|ppp4 from TWM.conf|http_loggin/module.conf|if_meter/module.cfg and run ./make_archive.sh"


