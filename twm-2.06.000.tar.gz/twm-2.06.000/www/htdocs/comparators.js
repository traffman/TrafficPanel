function stringComparator() {
    this.compare = function (val1, val2) {
        return ( val1 == val2
                 ? 0 : ( val1 > val2 ? 1 : -1 ) );
    }
}
function integerComparator() {
    this.compare = function (val1, val2) {
        val1 = parseInt(val1);
        val2 = parseInt(val2);
        return ( val1 == val2
                 ? 0 : ( val1 > val2 ? 1 : -1 ) );
    }
}
function floatComparator() {
    this.compare = function (val1, val2) {
        val1 = parseFloat(val1);
        val2 = parseFloat(val2);
        return ( val1 == val2
                 ? 0 : ( val1 > val2 ? 1 : -1 ) );
    }
}
function IPComparator(separator) {
    this.delimiter = ( separator ? separator : "." );
    this.compare = function (val1, val2) {
        val1 = this.getIntFromStr(val1);
        val2 = this.getIntFromStr(val2);
        return ( val1 == val2
                 ? 0 : ( val1 > val2 ? 1 : -1 ) );
    }
    this.getIntFromStr = function (val) {
        val = new String(val);
        res = 0;

        var idx = val.indexOf(this.delimiter);
        while ( idx != -1 ) {
            res = res * 1000 + parseInt(val.substring(0, idx));
            val = val.substring(idx+1);
            idx = val.indexOf(this.delimiter);
        }
        res = res * 1000 + parseInt( val ? val : 0 );
        return res;
    }
}

