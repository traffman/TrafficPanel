#!/bin/bash

if [ ! $1 ]; then
	echo "Usage: $0 TWM_folder"
	exit
fi

log_dir="$TWMFOLDER1/modules/http_top/logs"

COMMON_VARIABLES=(`perl $TWMFOLDER/bin/get_varMultipleValue.pl date ls grep gawk tar sed _DEFAULT_`)
date=${COMMON_VARIABLES[0]}
ls=${COMMON_VARIABLES[1]}
grep=${COMMON_VARIABLES[2]}
gawk=${COMMON_VARIABLES[3]}
tar=${COMMON_VARIABLES[4]}
sed=${COMMON_VARIABLES[5]}

m1=`$date +%m`
y1=`$date +%Y`
aM=( AAA Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec )
months_number=`perl $1/bin/get_varValue.pl backup_in_months http_top`

m1=`expr $m1 - $months_number`
if [ $m1 -le 0 ]; then
	m1=`expr 12 + $m1`
	y1=`expr $y1 - 1`
fi
m2=`expr ${aM[$m1]}`

cd $log_dir
fn=`$ls -l|$grep $y1$m2*-$y1$m2*|$gawk '{print $9}'`
if [ -d $fn ]; then
	$tar -czf "$fn.tgz" $fn > /dev/null 2>&1
	rm -Rf $fn
fi

arch=(`$ls -d */|$sed -e 's/\///g'`)
for i in "${arch[@]}"
do
	if [ -d "$i" ] && [ -e "$i.tgz" ]; then
		rm -Rf $i
	fi
done

exit 0
