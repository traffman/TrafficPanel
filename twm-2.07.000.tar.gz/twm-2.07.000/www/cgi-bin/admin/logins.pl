#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
print "Content-Type: text/html\n\n";


my $twm_htdocs_folder = "";
my $twm_cgi = "/cgi-bin";
my $logins = &getLogins();

print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/http_post.js"></script>
<script>
function checkedItem(obj)
{
	var httpp = new HTTPPost();
	httpp.postData('enable_login.pl', 'login='+obj.parentNode.parentNode.getAttribute("login")+'&enable='+(obj.checked?1:0), checkedHandler);

	function checkedHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status != 'true')
				{
					obj.checked = !obj.checked;
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
			}
		}
	}
}
</script>
</head>
<body>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellspacing=0 cellpadding=0 width=600>
  <tr>
    <td class=titlepage>Logins</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td height=50>
__EOF
if ($allowEdit)
{
	print "<a class=grid href='edit_login.pl?login='>Add new</a>";
}
print <<__EOF;
    </td>
    <td align=right>&nbsp;</td>
  </tr>

  <tr class=tableborder>
    <td colspan=2>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th>Login</th>
    <th>Full Name</th>
    <th>Role</th>
    <th>Last login</th>
    <th width=50>Enabled</th>
  </tr>
__EOF
my $i = 0;
for (sort keys %$logins)
{
	my $dt = $logins->{$_}->{last_access}?getDateTime($logins->{$_}->{last_access}):'&nbsp;';
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff login="$logins->{$_}->{login}">
    <td style="padding-left: 5px;"><a class=grid href='edit_login.pl?login=$logins->{$_}->{login}'>$logins->{$_}->{login}</a></td>
    <td style="padding-left: 5px;">$logins->{$_}->{full_name}</td>
    <td style="padding-left: 5px;">$logins->{$_}->{role}</td>
    <td style="padding-left: 5px;">$dt</td>
    <td align=middle><input type=checkbox name=chk value=0 ${\($logins->{$_}->{enabled} eq '1'?'checked':'')} onclick="checkedItem(this);"></td>
  </tr>
__EOF
}


print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>

<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see users list which have access to TrafficPanel based on their roles. To disable access just uncheck "Enabled".
</div>


</body>
</html>
__EOF
