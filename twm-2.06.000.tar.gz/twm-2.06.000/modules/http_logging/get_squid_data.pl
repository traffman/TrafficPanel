#!/usr/bin/perl -w

BEGIN   {
	sub getPoints{return '../../' if (!$_[1]); return '../' if (!$_[0]); return '/';}
	(my $file = __FILE__) =~ s/(\/?modules)?(\/?http_logging)?\/?\w+\.pl$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/'; #$file .= "bin";
	unshift(@INC, $file.'bin');
	unshift(@INC, $file.'modules/http_logging');
}

use strict;
use TWM;
use Logging;

my $logging = new Logging;
my $squid_settings = $logging->getSquidsSettings();

my $data = '';
foreach my $v (values %$squid_settings)
{
	$data .= $v->{port}.":".$v->{inf}.":".$v->{log_folder}.":".$v->{access_log}.":".$v->{isp}.":".$v->{config}."\n";
}
print $data;

__END__
