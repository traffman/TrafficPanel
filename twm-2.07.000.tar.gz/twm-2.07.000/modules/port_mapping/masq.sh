#!/bin/bash

declare -a COMMON_VARIABLES
COMMON_VARIABLES=(`perl $TWMFOLDER/bin/get_varMultipleValue.pl gawk iptables _DEFAULT_`)
gawk=${COMMON_VARIABLES[0]}
iptables=${COMMON_VARIABLES[1]}

ACTION="D"
if [ "$1" = "A" ] || [ "$1" = "I" ]; then
	ACTION="I"
fi


# logging
#perl $TWMFOLDER/modules/port_mapping/get_data.pl | $gawk '{ print("'$iptables'" " -t nat -'$ACTION' PREROUTING -i " $1 " -p " $3 " --dport " $2 " -j DNAT --to "$4":"$5" ") }'

perl $TWMFOLDER/modules/port_mapping/get_data.pl | $gawk '{ system("'$iptables'" " -t nat -'$ACTION' PREROUTING -i " $1 " -p " $3 " --dport " $2 " -j DNAT --to "$4":"$5" ") }'

exit 0