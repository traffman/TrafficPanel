#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
    unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;

my $co = new CGI;
my $ip = $co->param('ip');
my $data = getIPInfo($ip);
print "Content-Type: text/html\n\n";
print $data->{'full_name'}."|".$data->{'dns_name'}."|".$data->{'mac'};
