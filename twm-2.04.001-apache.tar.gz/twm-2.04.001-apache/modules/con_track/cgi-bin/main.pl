#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
&checkAuthorization;
$| = 1;

my $co = new CGI;

my $host = $co->param("host");
my $ip_src = $co->param("ip_src");
my $ip_dst = $co->param("ip_dst");
my $port_src = $co->param("port_src");
my $port_dst = $co->param("port_dst");

my $dnsresolution = $co->param("dnsresolution")||0;
my $portresolution = $co->param("portresolution")||0;
my $masqueradeonly = $co->param("masqueradeonly")||0;
my $directonly = $co->param("directonly")||0;
my $establishedonly = defined $co->param("establishedonly")?$co->param("establishedonly"):1;

my $mtime = &getCurrentDate;


print "Content-Type: text/html\n\n";

print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
function openItem(p1)
{
	if (document.getElementById("div_"+p1).style.display == "none")	
	{
		document.getElementById("div_"+p1).style.display = "block";
	}
	else
	{
		document.getElementById("div_"+p1).style.display = "none";
	}
}
</script>
</head>
<body style="margin: 10 10 10 10; padding: 10 10 10 10;">
<table cellspacing=1 cellpadding=1 width=700>
  <tr>
    <td class=titlepage>${\(&getModuleInfo->{name})}</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</table>
<!--\&nbsp;\&nbsp;Current Time: $mtime-->
<br><br>
<form name=f1 action="" method=post>
<table cellspacing=1 cellpadding=1 width=400>
  <tr>
    <td>IP host:</td>
    <td>&nbsp;<input type=text class=control name=host value="$host" size=25 maxlength=15></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>IP src:</td>
    <td>&nbsp;<input type=text class=control name=ip_src value="$ip_src" size=25 maxlength=15></td>
    <td>Port src:</td>
    <td>&nbsp;<input type=text class=control name=port_src value="$port_src" size=5 maxlength=5></td>
  </tr>
  <tr>
    <td>IP dst:</td>
    <td>&nbsp;<input type=text class=control name=ip_dst value="$ip_dst" size=25 maxlength=15></td>
    <td>Port dst:</td>
    <td>&nbsp;<input type=text class=control name=port_dst value="$port_dst" size=5 maxlength=5></td>
  </tr>
  <tr>
    <td valign=top>Conditions:</td>
    <td align=left colspan=2>
      <ul style="list-style: none; margin-left: 0px; padding-left: 0px;">
<input type=hidden name=dnsresolution value="$dnsresolution">
<input type=hidden name=portresolution value="$portresolution">
<input type=hidden name=masqueradeonly value="$masqueradeonly">
<input type=hidden name=directonly value="$directonly">
<input type=hidden name=establishedonly value="$establishedonly">
        <li><input type=checkbox name=_dnsresolution value=1 ${\(setChecked($dnsresolution, 1))} onClick="toggleStatus(this);"> - resolve IP
        <li><input type=checkbox name=_portresolution value=1 ${\(setChecked($portresolution, 1))} onClick="toggleStatus(this);"> - resolve port
        <li><input type=checkbox name=_masqueradeonly value=1 ${\(setChecked($masqueradeonly, 1))} onClick="toggleStatus(this);"> - Masquarad connections only
        <li><input type=checkbox name=_directonly value=1 ${\(setChecked($directonly, 1))} onClick="toggleStatus(this);"> - Direct connections only
        <li><input type=checkbox name=_establishedonly value=1 ${\(setChecked($establishedonly, 1))} onClick="toggleStatus(this);"> - Established connections only
      </ul>
    </td>
    <td valign=bottom style="padding-bottom: 12px;">&nbsp;<input type=submit class=control name=submit value=Search></td>
  </tr>
</table>
</form>
<table cellspacing=1 cellpadding=1 width=700>
  <tr bgcolor=#dddddd>
    <td>
<table cellspacing=1 cellpadding=2 width=700>
  <tr>
    <th width=88%>Host</th>
    <th width=12%>Number</th>
  </tr>
</table>
__EOF


my $cl = "$cm{ip_conntrack} -tw";
$cl .= "n" if (!$dnsresolution);
$cl .= "p" if (!$portresolution);
$cl .= "m" if ($masqueradeonly);
$cl .= "d" if ($directonly);
$cl .= "e" if ($establishedonly);
$cl .= " --host $host" if ($host =~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
$cl .= " --src $ip_src" if ($ip_src =~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
$cl .= " --dst $ip_dst" if ($ip_dst =~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
$cl .= " --port_src $port_src" if ($port_src =~ /^\d+$/);
$cl .= " --port_dst $port_dst" if ($port_dst =~ /^\d+$/);
my @ip_conntrack = run_twm_script($cl, $mc);

my (%ip_track);
foreach (@ip_conntrack)	
{
	next if !$_;
	my ($proto, $ip_src, $port_src, $ip_dst, $port_dst, $port, $state, $masq, $dirrection) = ("")x9;
	if ($directonly)
	{
		($proto, $ip_src, $port_src, $ip_dst, $port_dst, $port, $state, $masq, $dirrection) = ($1, $2, $3, $4, $5, $6, $7, $8, $9) if (/^(\w+)\t(\S+)\:(\d+)\t(\S+)\:(\d+)\t(.+)/);
	}
	else
	{
		($proto, $ip_src, $port_src, $ip_dst, $port_dst, $port, $state, $masq, $dirrection) = ($1, $2, $3, $4, $5, $6, $7, $8, $9) if (/^(\w+)\t(\S+)\:(\d+)\t(\S+)\:(\d+)\t(.+)\t(.+)\t(.+)\t(.+)\t/);
	}
#	next if ($ip_src eq '127.0.0.1' && $ip_dst eq '127.0.0.1');
	if ($proto)	
	{
		my $s = <<__EOF;
  <tr bgcolor=#ffffff onmouseover="ovrMouse(this);" onmouseout="outMouse(this);">
    <td width=50>&nbsp;$proto</td>
    <td>&nbsp;<a class=grid href="who.pl?host=$ip_src" target=_blank>$ip_src</a>:$port_src</td>
    <td>&nbsp;<a class=grid href="who.pl?host=$ip_dst" target=_blank>$ip_dst</a>:$port_dst</td>
__EOF
		$s .= "    <td>&nbsp;$port</td>\n" if ($portresolution);
		$s .= "    <td width=50>&nbsp;$state</td>\n" if (!$establishedonly);
		$s .= "    <td width=50>&nbsp;$masq</td>\n" if (!$masqueradeonly && !$directonly);
		$s .= "    <td>&nbsp;$dirrection</td>\n" if ($dnsresolution);
		$s .= "  </tr>\n";

		push @{$ip_track{$ip_src}}, $s;
	}
	else	
	{
		toErrorLog("Can not parse: $_");
	}
}


my $header = <<__EOF;
  <tr>
    <th width=50>Proto</th>
    <th>Source</th>
    <th>Destination</th>
__EOF
$header .= "    <th>Port</th>\n" if ($portresolution);
$header .= "    <th width=50>State</th>\n" if (!$establishedonly);
$header .= "    <th width=50>Masq</th>\n" if (!$masqueradeonly && !$directonly);
$header .= "    <th>Dirrection</th>\n" if ($dnsresolution);
$header .= "  </tr>\n";

my $ips = get_ip_name_hash(&getIPs);
my @ip_track = map {s/^0{1,2}//g; s/(?<=\.)0{1,2}//g; $_;} sort {$a cmp $b} map {&normIP} keys %ip_track; 
for my $key (@ip_track)
{
	print <<__EOF;
<table cellspacing=1 cellpadding=2 border=0 width=700>
  <tr bgcolor=#ffffff onmouseover="ovrMouse(this);" onmouseout="outMouse(this);">
    <td width=28% style="padding-left: 10px;"><a href="" class=grid onclick="openItem('$key'); return false;">$key</a></td>
    <td width=60% style="padding-left: 10px;"><a href="" class=grid onclick="openItem('$key'); return false;">$ips->{$key}</a></td>
    <td width=12% align=right>&nbsp;${\($#{$ip_track{$key}}+1)}&nbsp;</td>
  </tr>
</table>
<table cellspacing=0 cellpadding=0 width=700 id="div_$key" border=0 style="display: none;">
  <tr bgcolor=#dddddd>
    <td width=700>
<table cellpadding=1 cellspacing=1 border=0 width=700>
$header
__EOF
	print $_ for (@{$ip_track{$key}});
	print <<__EOF;
</table>
    </td>
  </tr>
</table>
__EOF
}

print <<__EOF; 
    </td>
  </tr>
</table>
Total: <b>$#ip_conntrack</b> connections
<br><br>
Current system timeouts:
<li>UDP - ${\(getTimeOut('udp_timeout'))} sec
<li>TCP established - ${\(getTimeOut('tcp_timeout_established'))} sec
<li>TCP close - ${\(getTimeOut('tcp_timeout_close'))} sec
<li>TCP close wait - ${\(getTimeOut('tcp_timeout_close_wait'))} sec
<li>TCP fine wait - ${\(getTimeOut('tcp_timeout_fin_wait'))} sec
<li>TCP last ack - ${\(getTimeOut('tcp_timeout_last_ack'))} sec
<li>TCP syn_recv - ${\(getTimeOut('tcp_timeout_syn_recv'))} sec
<li>TCP syn_sent - ${\(getTimeOut('tcp_timeout_syn_sent'))} sec
<li>TCP time_wait - ${\(getTimeOut('tcp_timeout_time_wait'))} sec



<div class=help style="width: 400px; height: 150px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Here is list of tcp/udp connections between local hosts and internet hosts.
By default you see total report of local host and number live connections. 
Click on row link of interesting host to get detail connections info and there you can click on remote host link 
to get remote host detail info.
<br>
The filter criteria under table allows you look for some specific connection.
</div>


</body>
</html>
__EOF


sub getTimeOut
{
	(my $conntrack = $cm{proc_net_ip_conntrack}) =~ s/.+\///;
	open(PROC, "$cm{proc_net_timeout_folder}/${conntrack}_$_[0]") || die("Can not read $_[0]: $!");
	my $a = join("",<PROC>);
	close(PROC);
	$a;
}

sub normIP	{
	($_ .= '.') =~ s/(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/000$1\.000$2\.000$3\.000$4/g;
	s/\d+(?=\d{3}\.)//g;
	s/\.$//;
	$_;
}

