#!/bin/bash

if [ `uname -a | grep -c Ubuntu` == 1 ]; then
	sudo apt-get install libcarp-clan-perl
	sudo apt-get install libxml-simple-perl
	sudo apt-get install libdate-calc-perl
	sudo apt-get install libstorable-perl
	sudo apt-get install libipc-sharelite-perl
	sudo apt-get install libxml-sax-perl
	exit
fi

mkdir perl_modules
cd perl_modules

if [ `perldoc -rlm XML::Simple | wc -l` != 1 ]; then
    	wget http://search.cpan.org/CPAN/authors/id/G/GR/GRANTM/XML-Simple-2.18.tar.gz
    	tar -xzf XML-Simple-2.18.tar.gz
    	cd XML-Simple-2.18
    	perl Makefile.PL
    	make
    	make test
    	make install
    	cd ../
fi


if [ `perldoc -rlm Date::Calc | wc -l` != 1 ]; then
    	wget http://search.cpan.org/CPAN/authors/id/S/ST/STBEY/Date-Calc-6.3.tar.gz
    	tar -xzf Date-Calc-6.3.tar.gz
    	cd Date-Calc-6.3
    	perl Makefile.PL
    	make
    	make test
    	make install
    	cd ../
fi

if [ `perldoc -rlm Storable | wc -l` != 1 ]; then
    	wget http://search.cpan.org/CPAN/authors/id/A/AM/AMS/Storable-2.25.tar.gz
    	tar -xzf Storable-2.25.tar.gz
    	cd Storable-2.25
    	perl Makefile.PL
    	make
    	make test
    	make install
    	cd ../
fi

if [ `perldoc -rlm IPC::ShareLite | wc -l` != 1 ]; then
    	wget http://search.cpan.org/CPAN/authors/id/A/AN/ANDYA/IPC-ShareLite-0.17.tar.gz
    	tar -xzf IPC-ShareLite-0.17.tar.gz
    	cd IPC-ShareLite-0.17
    	perl Makefile.PL
    	make
    	make test
    	make install
    	cd ../
fi


if [ `perldoc -rlm XML::SAX | wc -l` != 1 ]; then
    	wget http://search.cpan.org/CPAN/authors/id/G/GR/GRANTM/XML-SAX-0.96.tar.gz
    	tar -xzf XML-SAX-0.96.tar.gz
    	cd XML-SAX-0.96
    	perl Makefile.PL
    	make
    	make test
    	make install
    	cd ../
fi

if [ `perldoc -rlm Carp::Clan | wc -l` != 1 ]; then
    	wget http://search.cpan.org/CPAN/authors/id/S/ST/STBEY/Carp-Clan-6.04.tar.gz
    	tar -xzf Carp-Clan-6.04.tar.gz
    	cd Carp-Clan-6.04
    	perl Makefile.PL
    	make
    	make test
    	make install
    	cd ../
fi

cd ../


