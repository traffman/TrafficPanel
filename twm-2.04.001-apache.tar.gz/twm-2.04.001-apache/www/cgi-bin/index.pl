#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__) =~ s/\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization();

print "Content-Type: text/html\n\n";
my $co = new CGI;

if (defined $co->param("top"))
{
	print '<script>if (window.parent){window.parent.document.location.replace("index.pl")}</script>';
	exit;
}

my $task_manager_status = join("", run_script("$ck{ps} ax | $ck{grep} 'task_manager.pl' | $ck{grep} -v grep | $ck{wc} -l"));
chomp $task_manager_status;
############################
#$task_manager_status = '';
############################
$task_manager_status = $task_manager_status?'':'<br><b><font size=3 color=#FF0000>Task Manager is down. Start it by hand from server shell.</font></b><br><br>';

my $twm_htdocs_folder = "";
my $twm_cgi = "/cgi-bin";
my @index = ('a'..'z');
my %modules = &getModules();
my $tree = {};

for (sort keys %modules)
{
	next if ($modules{$_}->{enabled} ne 'true');
	my $html_tree = $modules{$_}->{'html_tree'};
	$html_tree = correctXML($html_tree);
#	if (exists($html_tree->{branch}))
#	{
		populateBranch($html_tree->{branch}, $_, $tree);

#	}
}
#print "TREE <br><br>";
#print Dumper $tree;
#exit;

my @keys = keys %$tree;
my $count_branches = $#keys+1+2;

print <<__EOF;
<html>
<head>
  <title>Traffic Web Management</title>
<style>
body	
{
	margin: 0px 0px 0px 0px;
	padding: 0px 0px 0px 0px;
	background-color: #ffffff;
}
a
{
	font-family: tahoma;
	font-size: 11px;
	color: #333333;
	text-decoration: none;
}
.mContent 
{
	width: 100%; 
	height: 100%;
	background-color: #f3f3f3;
}
.scrollType, .mContent	
{
    scrollbar-3dlight-color: #b2b2b2; 
    scrollbar-arrow-color: #ffffff; 
    scrollbar-base-color: #00ffff; 
    scrollbar-darkshadow-color: #b2b2b2; 
    scrollbar-face-color: #dedede; 
    scrollbar-highlight-color: #ffffff;
    scrollbar-shadow-color: #eaeaea;
}
</style>
<script src="$twm_htdocs_folder/tree/DHTMLTree.js"></script>
<script>
function onTreeSelect(act)	{
	if (act != 0)	{
		var page = document.getElementById("af"+getTreeItem(act).id).getAttribute("PAGE");
		var description = document.getElementById("af"+getTreeItem(act).id).getAttribute("DESCRIPTION");
		if (page)	{
			if (page.indexOf("?")>0)	{
				document.getElementById("bodyFrame").src = page+"&t="+((new Date).getTime());
			}else	{
				document.getElementById("bodyFrame").src = page+"?t="+((new Date).getTime());
			}
			window.status = description?description:"";
		}
		return false;
	}
}


function getChilds(parentNode) {
//alert("getChilds="+parentNode.id);
//	if (parentNode.hasUnloadedChild) {
//		onTreeSelect(parentNode.id);
//	}
	return true;
}


function selNode(id) {
//	if (id.length <2 || (id.length <= 2 && id.indexOf("1") == 0) ) {
		clickCross(id);
//		return false;
//	}
//	else {
		return true;
//	}
}


sColor = "#c5c8ca";
canDynamicalLoad = true;
onCross = getChilds;
onSelectNode = selNode;
imgBase = "$twm_htdocs_folder/tree/img/";

var parentIdArray = new Array();
var idArray = new Array();
var labelArray = new Array();
var hasCheckboxArray = new Array();
var imgCArray = new Array();
var img0Array = new Array();
var hasNotChilds = new Array();
var iIndex = -1;


function setTreeArrays(p1, p2 ,p3, p4, p5, p6, p7)	{
	parentIdArray[++iIndex] = p1;
	idArray[iIndex] = p2;
	labelArray[iIndex] = p3;
	hasCheckboxArray[iIndex] = p4;
	imgCArray[iIndex] = p5;
	img0Array[iIndex] = p6;
	hasNotChilds[iIndex] = p7;

	if (p1 != null && p1 != "")	{
		for (var j=0; j<= parentIdArray.length; j++)	{
			if (idArray[j] == p1)	{
				hasNotChilds[j] = false;
			}
		}
	}

	return false;
}


function buildTree()	{
	var newNode = insertRootImg("0", "<font id=af0>TrafficPanel</font>", "root.gif", "root.gif",false);
	newNode.hasUnloadedChild = true;
	showTree();
	for (var i=0; i<=iIndex; i++)	{
		addChildNode(parentIdArray[i], idArray[i], labelArray[i], hasCheckboxArray[i], imgCArray[i], img0Array[i], hasNotChilds[i]);
	}
	return false;
}


function setTreePosition()	{
	document.getElementById("tree_limit").style.width = document.getElementById("treeDiv").clientWidth;
}

setTreeArrays('0', '1', '<font id=af1 description="Dashboard" page="$twm_cgi/admin/dashboard.pl">Dashboard</font>', null, 'stuff.gif', 'stuff.gif', true);
${\(buildTree($tree, 0, 1))}
setTreeArrays('0', '$count_branches', '<font id=af$count_branches description="Setup">Setup</font>', null, 'kernel.gif', 'kernel.gif', true);

setTreeArrays('$count_branches', '${count_branches}b', '<font id=af${count_branches}b description="Local network hosts" page="$twm_cgi/admin/ip.pl">Local network hosts</font>', null, 'stuff.gif', 'stuff.gif', true);
setTreeArrays('$count_branches', '${count_branches}c', '<font id=af${count_branches}c description="Config" page="$twm_cgi/admin/config.pl">Config</font>', null, 'stuff.gif', 'stuff.gif', true);
setTreeArrays('$count_branches', '${count_branches}d', '<font id=af${count_branches}d description="Login" page="$twm_cgi/admin/logins.pl">Logins</font>', null, 'stuff.gif', 'stuff.gif', true);
setTreeArrays('$count_branches', '${count_branches}e', '<font id=af${count_branches}e description="Modules" page="$twm_cgi/admin/modules.pl">Modules</font>', null, 'stuff.gif', 'stuff.gif', true);
setTreeArrays('$count_branches', '${count_branches}f', '<font id=af${count_branches}f description="Task Manager" page="$twm_cgi/admin/tm.pl">Task Manager</font>', null, 'stuff.gif', 'stuff.gif', true);
setTreeArrays('$count_branches', '${count_branches}g', '<font id=af${count_branches}g description="Modules Configuration">Modules Configuration</font>', null, 'kernel.gif', 'kernel.gif', true);
${\(buildModuleConfigurationTree($count_branches.'g'))}
setTreeArrays('0', '${\(++$count_branches)}', '<font id=af$count_branches description="Help">Help</font>', null, 'kernel.gif', 'kernel.gif', true);
${\(buildHelpTree($count_branches))}

function doLoad()
{
	doResize();
	document.getElementById("treeDiv").style.visibility = 'visible';
}

function doResize()
{
	document.getElementById("treeDiv").style.height = document.body.clientHeight+'px';
	var d = document.getElementById("logoutDiv");
	d.style.visibility = 'visible';
	if ('$task_manager_status' == '')
	{
		d.style.left = (document.body.clientWidth - 50) + 'px';
	}
	else
	{
		d.style.width = (document.body.clientWidth - 260) + 'px';
		d.style.left = (260) + 'px';
	}

}


window.onresize = doResize;

</script>
</head>
<body style="overflow: hidden;" onLoad="doLoad();">
<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>
  <tr>
    <td width=250 height=100% valign=top bgcolor="#f3f3f3">
<div id=treeDiv style="overflow: auto; width: 250px; height: 500px; border: #b2b2b2 1px solid; visibility: hidden;">
<script>
buildTree();
</script>
</div>
    </td>
    <td width=100% height=100%>
<iframe marginheight=0 scrolling=auto marginwidth=0 frameborder=0 id=bodyFrame name=bodyFrame src="" style="z-index:999;width:100%; height:100%;"></iframe>
    </td>
  </tr>
</table>
<div id=logoutDiv style="visibility: hidden; position: absolute; top: 5px; text-align: right; width: 50px;">
<a title="Logout" href="logout.pl" style="margin-right: 20px;">
<img width=16 height=16 border="0" onmouseout="this.src='/logout.gif'" onmouseover="this.src='/logout-hover.gif'" src="/logout.gif"/>
</a>
<div style="text-align: center; background-color: #ffffff; opacity:0.7; filter: alpha(opacity = 70);">$task_manager_status</div>
</div>
</body>
</html>
__EOF



sub getBranch
{
	my $items = shift;
	my $mc = shift;
	if (ref $items eq 'HASH')
	{
		$items = [$items];
	}
	
	return sort {$a->{ordering}<=>$b->{ordering}} map {$_->{'module_code'} = $mc; $_;} @{$items};
}

sub populateBranch
{
	my ($branch, $mc, $tree) = (shift, shift, shift);
	$branch = correctXML($branch);
	if (exists($branch->{branch}))
	{
		if (ref $branch->{branch} eq 'HASH')
		{
			$branch->{branch} = [$branch->{branch}];
		}
		if (!exists($tree->{$branch->{label}}))
		{
			$tree->{$branch->{label}} = {};

		}
		for (@{$branch->{branch}})
		{
			if (exists($branch->{icon1}))
			{
				$tree->{$branch->{label}}->{icon1} = $branch->{icon1};
			}
			if (exists($branch->{icon2}))
			{
				$tree->{$branch->{label}}->{icon2} = $branch->{icon2};
			}

			populateBranch($_, $mc, $tree->{$branch->{label}});
		}
	}
	elsif (exists($branch->{item}))
	{
		if (!exists($tree->{$branch->{label}}->{'content'}))
		{
			$tree->{$branch->{label}}->{'content'} = [];
		}
		if (exists($branch->{icon1}))
		{
			$tree->{$branch->{label}}->{icon1} = $branch->{icon1};
		}
		if (exists($branch->{icon2}))
		{
			$tree->{$branch->{label}}->{icon2} = $branch->{icon2};
		}
		push @{$tree->{$branch->{label}}->{'content'}}, getBranch($branch->{item}, $mc);
	}	
}


sub buildTree
{
	my $s = '';
	my ($tree, $parent_index, $i) = (shift, shift, shift);
	for (sort keys %$tree)
	{
		if ($_ eq 'content' && ref $tree->{$_} eq 'ARRAY')
		{
			my $content = $tree->{$_};
			for my $item (@$content)
			{
				$i++;
				my $index_prefix = $parent_index.$index[$i];
				my $icon1 = exists($item->{'icon1'})?$item->{'icon1'}:'stuff.gif';
				my $icon2 = exists($item->{'icon2'})?$item->{'icon2'}:'stuff.gif';
				$s .= "setTreeArrays('$parent_index', '$index_prefix', '<font id=af$index_prefix description=\"$item->{description}\" page=\"$twm_cgi/modules/$item->{module_code}/$item->{'script'}\">$item->{label}</font>', null, '$icon1', '$icon2', true);\n";
			}
		}
		elsif (ref $tree->{$_} eq 'HASH')
		{
			$i++;
			my $index_prefix = $parent_index == 0 ? $parent_index + $i : $parent_index.$index[$i];
			my $icon1 = exists($tree->{$_}->{'icon1'})?$tree->{$_}->{'icon1'}:'kernel.gif';
			my $icon2 = exists($tree->{$_}->{'icon2'})?$tree->{$_}->{'icon2'}:'kernel.gif';
			$s .= "setTreeArrays('$parent_index', '$index_prefix', '<font id=af$index_prefix description=\"$_\">$_</font>', null, '$icon1', '$icon2', true);\n";
			$s .= buildTree($tree->{$_}, $index_prefix, 0);
		}
	}
	$s;
}


sub buildModuleConfigurationTree
{
	my ($parent_index , $s, $i) = (shift, '', 0);
	my %modules = &getModules();

	for (sort keys %modules)
	{
		next if ($modules{$_}->{enabled} ne 'true');
		my $index_prefix = $parent_index.$index[$i++];
		$s .= "setTreeArrays('$parent_index', '$index_prefix', '<font id=af$index_prefix description=\"$modules{$_}->{full_name}\" page=\"$twm_cgi/admin/config.pl?module=$_\">$modules{$_}->{name}</font>', null, 'stuff.gif', 'stuff.gif', true);\n";
	}
	$s;
}

sub buildHelpTree
{
	my ($parent_index , $s, $i) = (shift, '', 0);
	my %modules = &getModules();

	for (sort keys %modules)
	{
		next if ($modules{$_}->{enabled} ne 'true');
		my $index_prefix = $parent_index.$index[$i++];
		$s .= "setTreeArrays('$parent_index', '$index_prefix', '<font id=af$index_prefix description=\"$modules{$_}->{full_name}\" page=\"$twm_cgi/help.pl?module=$_\">$modules{$_}->{name}</font>', null, 'stuff.gif', 'stuff.gif', true);\n";
	}
	$s;
}

sub correctXML
{
	my $x = shift;
	if (exists($x->{name}) && $x->{name} eq 'branch')
	{
		delete $x->{name};
		my $t = $x;
		$x = {};
		$x->{branch} = $t;
	}
	$x;
}

__END__
