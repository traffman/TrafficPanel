#!/bin/bash

cd ../
update_folder=/root/TWM/update
version=`cat version.conf | grep "version=" | sed -e "s/version=//g"`

rm -Rf $update_folder
mkdir $update_folder

find . -type d | grep -vE "\.\/etc|\.\/apache|\.svn|\.\/backup" | while read item ; do
	mkdir $update_folder/$item
done

find . -mtime -50 -type f | grep -vE "\.\/etc|\.\/apache|\/\cbq\/\cbq\-|\.log|\.svn|\.BAK|\/backup|\.swp|_old|\/conf|\.conf" | while read item ; do
	cp $item $update_folder/$item
done

find $update_folder -type d -empty | xargs rm -R

cd install


cd /root/TWM/
mv update twm-$version-update
tar -czf twm-$version-update.tar.gz twm-$version-update
