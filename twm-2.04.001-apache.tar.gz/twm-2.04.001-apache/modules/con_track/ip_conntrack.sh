#!/bin/bash

if [ -e $TWMFOLDER/modules/con_track/ip_conntrack.pl ]; then
	perl $TWMFOLDER/modules/con_track/ip_conntrack.pl $@
else
	echo "Could not find file $TWMFOLDER/modules/con_track/ip_conntrack.pl"
fi

