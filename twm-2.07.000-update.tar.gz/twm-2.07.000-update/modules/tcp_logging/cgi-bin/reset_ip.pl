#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}


# this script used to set total http traffic restriction
# after total amount is set then script sends SIGUSR1 to httpr_sl daemon
use strict;
use CGI;
use TWM;
use TrafficLogging;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
print "Content-Type: text/xml\n\n";

my $trafficLogging = TrafficLogging->new();
my $ip = $co->param("ip")||'';
my ($status, $message) = ('')x2;
if ($allowEdit)
{
	if ($ip) 
	{
		my $report_file = "$ck{twmfolder}modules/$mc/logs/".$trafficLogging->get_report_filename();
		open(REPORTS, "+<$report_file") || (toErrorLog("Can't open $report_file: $!") && die("Can't open $report_file: $!\n"));
		my $str = '';
		while (<REPORTS>)
		{
			chomp;
			$str .= "$_\n" if (!/\t(\-?\-?\>?$ip\-?\-?\>?)\t(.+?)\t(\d+)/);
		}
		seek(REPORTS,0,0) || die "Seeking: $!\n";
		print REPORTS $str."\n";
		truncate(REPORTS, tell(REPORTS)) || (toErrorLog("Truncating: $!") && die "Truncating: $!\n");
		close(REPORTS);

		keepHistory("Reset tcp traffic of $ip");
		($status, $message) = ('true', '');
	}
	else
	{
		($status, $message) = ('false', 'IP is not defined');
	}
}
else
{
	($status, $message) = ('false', 'You do not have required permissions');
}


print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
