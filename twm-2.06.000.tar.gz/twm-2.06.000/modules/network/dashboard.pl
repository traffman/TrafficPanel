#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(network\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
}

use strict;
use TWM;
use Data::Dumper;

my $host = $ARGV[0];
exit if ($host);

print <<__EOF;
fullrow=1

<div class="paneltitle"><span class="paneltitlerow">System network information</span></div>
<div class="panelcontent">
<div class="panelcontentrow">
__EOF

my(%isp_name,%data);
my $isp_list = &getISP;

for(keys %$isp_list) {
	$isp_name{$_} = $isp_list->{$_}->{'attributes'}
}

my $gw = join("", run_script("$ck{ip} route | $ck{grep} default | $ck{gawk} '{print \$5}'"));
chomp $gw;

my $if = undef;
my @ifinfo = run_script($ck{ifconfig});
for (@ifinfo)
{
    if (/^(\w\w\w\d+(\:\d+)?)\s+Link encap:(.+)/)
    {
        $if = $1;
        $data{$if}->{type} = $3;
        $data{$if}->{extra} .= "Default Gateway<br>" if ($gw eq $if);
    }
    elsif (/^\s+inet addr:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(.+)/)
    {
        $data{$if}->{ip} = $1;
        $data{$if}->{extra} .= "P-t-P addr: $1<br>" if ($2 =~ /P\-t\-P:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/);
    }
    elsif (/^\s+RX bytes\:\d+ \((.+?)\)  TX bytes\:\d+ \((.+?)\)/)
    {
        $data{$if}->{rx} = $1;
        $data{$if}->{tx} = $2;
    }
}

print <<__EOF;
<table cellspacing=0 cellpadding=0 width=100% border=0>
	<tr bgcolor=#dddddd>
    <td width=100%>
<table cellpadding=1 cellspacing=1 width=100% border=0>
<tbody>
  <tr height=24>
    <th>Information</th>
    <th>ip</th>
    <th>Received</th>
    <th>Transfered</th>
    <th>Extra information</th>
    <th>Default</th>
  </tr>
__EOF

for (keys %data)
{
	my $default = '';
	if (exists($isp_name{$_}))
	{
		$isp_name{$_}->{'internal'} = 1 if ($isp_name{$_}->{'internal'} ne 0);
		if (!$isp_name{$_}->{'internal'} && $isp_name{$_}->{'default'})
		{
			$default = 'Yes';
		}
		elsif (!$isp_name{$_}->{'internal'} && !$isp_name{$_}->{'default'})
		{
			$default = 'No';
		}
	}
	printRow($_,$data{$_}->{ip}||'',$data{$_}->{rx}||'',$data{$_}->{tx}||'',$data{$_}->{extra}||'',$default||'');
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
__EOF

print <<__EOF;
</div>
</div>
__EOF

sub printRow
{
	my ($intf,$ip,$rx,$tx,$extra,$default) = (shift,shift,shift,shift,shift,shift);
	$intf = $isp_list->{$intf}{code}?$intf." [$isp_list->{$intf}{code}]":$intf;
	print <<__EOF;
<tr onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff><td
 style='padding-left: 5px;'>$intf</td><td
 style='padding-left: 5px;'>$ip</td><td
 style='padding-left: 5px;'>$rx</td><td
 style='padding-left: 5px;'>$tx</td><td
 style='padding-left: 5px;'>$extra</td><td
 align=center>$default</td></tr>
__EOF
}

__END__
