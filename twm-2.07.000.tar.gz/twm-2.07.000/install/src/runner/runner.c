/*
 * Install owned by root.
 * If you want anyone to be able to run it, set
 * permissions to 4711
 * If you only want a set of users to be able to
 * run it: chgrp it to the group that should be
 * able to run it and set permissions to 4710
 */

#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>

char *strconc(char *s1, char *s2)
{
	char *s3 = s1, *result;
	result = malloc(strlen(s3) + strlen(s2) + 1);
	if (result)
	{
		strcpy(result, s3);
		strcat(result, s2);
	}
	return result;
}




int main(int argc, char *argv[])
   {
   /* must be called with an argument */
	if (argc < 3)
	{
		fprintf(stderr,"Usage: %s {twm folder} {comands}\n", argv[0]);
		exit(1);
	}


	int is_debug = 0;
	char *twmfolder = "[TWMFOLDER]"; // get TrafficPanel folder "/usr/local/twm"

	char *env[] = {
		"PATH=/bin:/usr/bin:/usr/sbin/",
		strconc("TWMFOLDER=", twmfolder),//"TWMFOLDER=/usr/local/twm/"
		NULL};

	int param_length = argc-1;
	char *param[param_length];
	int i;

	for (i=0; i<param_length-1; i++) param[i] = argv[i+2];
	param[param_length-1] = NULL;
//for (i=0; i<param_length; i++) fprintf(stderr,"param: %s \n", param[i]);
//for (i=0; i<argc; i++) fprintf(stderr,"argv: %s \n", argv[i]);

	setuid(0);  /* become root */
	execve(param[0], &param, &env); 

/*   if (strcmp(argv[1], "on") == 0)
      {
      execle(PPP_OFF, (const char *) NULL,
         &env);
      }
   else if (strcmp(argv[1], "off") == 0)
      {
      execve(PPP_OFF, &param, &env); 
      }
   else
      {
      fprintf(stderr, "%s: invalid argument\n",
         argv[0]);
      exit(2);
      }*/
   }
