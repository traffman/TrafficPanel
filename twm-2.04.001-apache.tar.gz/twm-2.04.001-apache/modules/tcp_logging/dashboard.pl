#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(tcp_logging\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
	unshift(@INC, $file.'modules/tcp_logging');
}

use strict;
use TWM;
use TrafficLogging;
use Time::Local;
use Data::Dumper;

my $host = $ARGV[0];

print <<__EOF;
fullrow=0

<div class="paneltitle"><span class="paneltitlerow">TCP Logging</span></div>
<div class="panelcontent">
<div class="panelcontentrow">
__EOF

my $ip_list = &getIPs;
my $ips = get_ip_name_hash($ip_list);

my($dtstart,$dtend);
my $trafficLogging = TrafficLogging->new();
my $interfaces = $trafficLogging->get_ext_interfaces();

my %monthN = ();
for (my $i=0; $i<=$#short_months; $i++)
{
    $monthN{$short_months[$i]} = sprintf("%02s",$i+1);
}

my $report_file = $trafficLogging->get_report_filename();

if (!$dtend && $report_file =~ /(\d{4})(\d\d)(\d\d)/)
{
    $dtstart = "$1$2$3";
    $dtend = $dtstart;
}
else
{
    $dtstart =~ s/\-(\w\w\w)\-/$monthN{$1}/;
    $dtend =~ s/\-(\w\w\w)\-/$monthN{$1}/;
    $report_file =~ s/\d{8}/$dtend/;
}
my $repArray = $trafficLogging->populate_report($dtstart, $dtend, $report_file);

#my @showM = split /\,/, $cm{log_items_list};
my @showM = @{$trafficLogging->get_items_list()};

$dtstart =~ s/(\d{4})(\d\d)(\d\d)/$1-$short_months[$2-1]-$3/;
$dtend =~ s/(\d{4})(\d\d)(\d\d)/$1-$short_months[$2-1]-$3/;

push @showM, 'Total';
if ($host) {
	for my $ip (keys %$ips) {
		if ($ip eq $host) {
        
			my ($enabled,$blocked,$limit,%traffic4ip,%limits);
        
			for my $item (@showM) {
				my $index = $item eq 'Total'?0:$item+2;
				my $count = $trafficLogging->traffic_count($index, $interfaces, $ip);
				if($item eq 'Total') {
					$traffic4ip{$item} = ${\(getHumanTrafficNumber($count,'m'))}
				}
				else {
					$traffic4ip{$item} = ${\(getHumanTrafficNumber($count,$cm{total_width}))}
				}
			}
        
			my $xml = readModuleConfigFile($cm{tcp_limit});
			my $areas = $xml->{'pc'};
			if (ref $areas eq 'HASH') {
				$limits{$areas->{ip}} = $areas->{size}
			}
			else {
			    foreach (@$areas) {
		        	$limits{$_->{ip}} = $_->{size}
			    }
			}
        
			$limit = exists $limits{$ip}?$limits{$ip}:$cm{'default_size'};
        
			foreach (@$ip_list) { 
				if ($_->{ip} eq $host)
				{
					$enabled = $_->{enabled};
					last;
				}
			}
        
			if ((! $enabled) && ($traffic4ip{'Total'} >= $limit)) {
				print "<div class=warning>Traffic is blocked</div>";
			}
			else { 
				print "<div>Traffic is not blocked</div>";
			}
        		print "<div>Traffic of last:";
			for (sort {$a <=> $b} keys %traffic4ip) {
				print "<div style='padding-left: 10px;'>${\($_+1)} min is $traffic4ip{$_} $cm{total_width}b</div>" unless $_ eq 'Total';
			}
			print "</div>";
			print "<br>";
			print "<div>Daily traffic is $traffic4ip{'Total'} Mb</div>";
			print "<div>Traffic limit is $limit Mb</div>";
			last;
		}	
	}	
}
else {
	my %total = ();
	$total{$_} = 0 for (@showM);

	for my $ip (keys %$ips) {
		my $count;
		for my $item (@showM) {
			my $index = $item eq 'Total'?0:$item+2;
			$count = $trafficLogging->traffic_count($index, $interfaces, $ip);
			$total{$item} += $count;
		}
	}
	print "<div>Traffic of last:";
	for (sort {$a <=> $b} keys %total) {
		print "<div style='padding-left: 10px;'>${\($_+1)} min ${\(getHumanTrafficNumber($total{$_},'m'))} Mb</div>" unless $_ eq 'Total';
	}
	print "</div>";
	print "<br>";
	print "<div>Daily: ${\(getHumanTrafficNumber($total{'Total'},'m'))} Mb</div>";

}

print <<__EOF;
</div>
</div>
__EOF

__END__
