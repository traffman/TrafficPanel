#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(traffic_routing\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
}

use strict;
use TWM;

my $host = $ARGV[0];

exit unless ($host);

print <<__EOF;
fullrow=0

__EOF

print <<__EOF;
  <div class="paneltitle"><span class="paneltitlerow">Routing</span></div>
  <div class="panelcontent">
    <div class="panelcontentrow">
__EOF

my %isp_name;
my $isp_list = &getISP;

for(keys %$isp_list) {
	if ($isp_list->{$_}->{attributes}->{default} eq '0' && $isp_list->{$_}->{attributes}->{internal} eq '0') {
		$isp_name{$isp_list->{$_}->{inf}} = $isp_list->{$_}->{code}
	}
}

my $xml = readModuleConfigFile($cm{rules});
my $list = (ref $xml->{rule} eq 'HASH')?[$xml->{rule}]:$xml->{rule};

my $rules_set;
for(@$list) {
	if($_->{'ip'} eq $host) { $rules_set = '1' }
}

if ($rules_set) {
	print <<__EOF;
<table cellspacing=0 cellpadding=0 width=100% border=0>
  <tr bgcolor=#dddddd>
    <td width=100%>
<table cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr>
    <th width=60>ISP</th>
    <th width=100>Port</th>
    <th width=50>Proto</th>
    <th>Description</th>
  </tr>
__EOF

	for (@{sortIPs($list)}) {
		printRow($_) if $_->{'ip'} eq $host;
	}

	print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
__EOF

}
else {
	print <<__EOF;
<table align=center>
	<tr><td height=50>&nbsp</td></tr>
	<tr><td>
	<table cellpadding=1 cellspacing=1 border=0>
		<tr height=25><td align=center>There are no any special rules.</td></tr>
	</table>
	</td></tr>
</table>
__EOF
}

print <<__EOF;
</div>
  </div>
__EOF

sub printRow
{
    my ($row) = (shift);
    $row->{service} = '' if ref $row->{service} eq 'HASH';
    $row->{description} = '' if ref $row->{description} eq 'HASH';
    my $description = ($row->{service} && !$row->{description})?"[Service: $row->{service}]":$row->{description};

    print <<__EOF;
<tr onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff><td
 align=center>$isp_name{$row->{interface}}</td><td
 align=center>$row->{port}</td><td
 align=center>$row->{proto}</td><td
 align=left>$description</td></tr>
__EOF
}

__END__
