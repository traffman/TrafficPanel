#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}


# this script used to set total http traffic restriction
# after total amount is set then script sends SIGUSR1 to httpr_sl daemon
use strict;
use CGI;
use TWM;
use IPLimit;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

my $objIPLimit = IPLimit->new();
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
my $title = "HTTP traffic restriction by size <br>";            
my $ips = get_ip_name_hash(&getIPs);
my %usedTraffic = %{$objIPLimit->load_total()};

my $status = join("", run_script("$ck{ps} ax | $ck{grep} 'httpr_sl.pl' | $ck{grep} -v grep | $ck{wc} -l"));
chomp $status;
$status = $status?'':'<br><b><font size=3 color=#FF0000>Daemon is down. "Save" to start it.</font></b><br><br>';


print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<script>
function formValidate() {
  var f = document.forms.f1;
  var obj = document.getElementsByTagName("INPUT");
  f.values.value = "";
  for (var i=0; i<obj.length; i++)  {
    if (obj[i].getAttribute("name") == "fld1")  {
      f.values.value += "|"+obj[i].value;
    }
    if (obj[i].getAttribute("name") == "fld2")  {
      f.values.value += "*"+obj[i].value;
    }
  }
  f.submit();
  return false;
}


function addItem()  
{
  var obj = document.getElementById("cTable").tBodies[0];
  var tr = document.createElement("TR");
  tr.height = 22;
  tr.style.backgroundColor = "#ffffcc";
  tr.onmouseover = function() {ovrMouse(this);};
  tr.onmouseout = function()  {outMouse(this);};
  var td = document.createElement("TD");
  td.allign = "middle";
  td.innerHTML = "<a href='' onClick='delItem(this); return false'>x</a>";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.innerHTML = "&nbsp;<input class=control type=text name=fld1 value='' style='width: 135px;'>";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;<input class=control style='text-align: right; width: 54px;' type=text name=fld2 value=''>&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);

  obj.appendChild(tr);
 
}

function openItem(obj)  {
  obj.parentNode.parentNode.parentNode.childNodes[3].childNodes[1].style.display = "none";
  obj.parentNode.parentNode.parentNode.childNodes[3].childNodes[2].style.display = "inline";
  obj.parentNode.parentNode.parentNode.childNodes[7].childNodes[1].style.display = "none";
  obj.parentNode.parentNode.parentNode.childNodes[7].childNodes[2].style.display = "inline";
}


</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=values value="">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF

my $doneString = "";
if ($co->param("values")) 
{
	my %exp_limit;
	my @value = split /\|/, $co->param("values");
	my ($ips);
	for (@value)  
	{
		next if ! $_;
		if (/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\*(\d+)/)  
		{
			my ($ip, $size) = ($1, $2);
			my $isexist = 0;
			foreach($ips->{pc})
			{
				$isexist = 1 if ($_ && $_->[0]->{ip} eq $ip);
			}
			if ($isexist eq 1)  
			{
				$doneString .= "<br>Duplicate IP: $ip. Ignore second data.";
			}
			else 
			{
				push @{$ips->{pc}}, {ip=>$ip, size=>$size};
				if (exists($usedTraffic{$ip}) && $size*1024**2>$usedTraffic{$ip})
				{
					$exp_limit{$ip} = 1;
				}
			}
		}
		else 
		{
			$doneString .= "<br> Incorrect data: $_";
		}
	}
	my $blockedlist = $objIPLimit->get_blocked_list();
	my %blocked_ip_list;
	for (@$blockedlist)
	{
		$blocked_ip_list{$_} = 1 if (!exists($exp_limit{$_}));
	}

	$objIPLimit->saveBlockedList(\%blocked_ip_list);
	&saveModuleConfigFile($cm{restriction_file}, $ips);
	run_twm_script("$cm{daemon} init", $mc);
	$doneString = "Data are saved.".getWebDebugLog();
	keepHistory($title);
}

my $xml = readModuleConfigFile($cm{restriction_file});
my $areas = $xml->{'pc'};

  print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
$status
<p>
Default amount size: ${\$cm{default_amount}} Mb
</p>
<p><small>$doneString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=400>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=145>IP</th>
    <th width=180>Name</th>
    <th width=90>Available (Mb)</th>
    <th width=65>Used (Mb)</th>
    <th width=65>Blocked</th>
  </tr>
__EOF

my $blockedlist = $objIPLimit->get_blocked_list();
if (ref $areas eq 'HASH')
{
	print_row($areas, $usedTraffic{$areas->{ip}}, $ips->{$areas->{ip}});
}
else
{
	print_row($_, $usedTraffic{$_->{ip}}, $ips->{$_->{ip}}) foreach (@$areas);
}
print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
}
print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can set daily total amout available http traffic per ip. Default available traffic you can set in the module confguration. 
For unlimited http traffic just set big value, for example 10000 ( 10Gb ).
Every midnight used http traffic amount set to zero and calculation starts again.
</div>


</body>
</html>
__EOF


sub print_row
{
	my ($trcolor, $status, $used) = ("ffffff", '', defined $_[1]?$_[1]:0);
	$used = getHumanTrafficNumber($used, 'm');
	($trcolor, $status) = ("f5f5f5", 'Yes') if in_array($blockedlist, $_[0]->{ip});
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#$trcolor >
    <td align=middle width=10><a href="" onClick='delItem(this);return false' style="visibility: hidden;"><img src="/delete.gif" border=0/></a></td>
    <td>&nbsp;<span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{ip}</a></span><span style="display: none;"><input  class=control type=text name=fld1 value='$_[0]->{ip}' style='width: 135px;'></span></td>
    <td>&nbsp;$_[2]</td>
    <td align=right>&nbsp;<span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{size}</a></span><span style="display: none;"><input  class=control style="text-align: right; width: 54px;" type=text name=fld2 value='$_[0]->{size}'></span>&nbsp;</td>
    <td align=right>$used</td>
    <td align=center>$status</td>
  </tr>
__EOF
}
