#!/bin/sh

gcc forker.c -o forker
chown root:$1 forker
chmod 4750 forker
cp -p forker ../../../bin

exit 0
