#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
    unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
print "Content-Type: image/png\n\n";

my $query = new CGI;
my $dt = $query->param(-name=>'dt') || "";
my $fl = $query->param(-name=>'fl') || "";
my $squid = $query->param('squid')||'';

if ($dt && $fl) {
	$fl =~ /(\d{1,3}[._]\d{1,3}[._]\d{1,3}[._]\d{1,3}\/graph_day\.png)/;
	binmode STDOUT;
	open(FILE, "../logs/$squid/$dt/$fl") || die "can't open file $!\n";
		binmode FILE;
		while (<FILE>) {print}
	close FILE;
}

print $query->end_html;


__END__
