#!/bin/bash

declare -a COMMON_VARIABLES
COMMON_VARIABLES=(`perl $TWMFOLDER/bin/get_varMultipleValue.pl gawk iptables _DEFAULT_`)
gawk=${COMMON_VARIABLES[0]}
iptables=${COMMON_VARIABLES[1]}

ACTION="D"
if [ "$1" = "A" ] || [ "$1" = "I" ]; then
	ACTION="I"
fi


# logging
#perl $TWMFOLDER/modules/close_ports/get_data.pl | $gawk '{ print("'$iptables'" " -'$2' INPUT -i " $3 " -p " $2 " --dport " $1 " -j REJECT ") }'

perl $TWMFOLDER/modules/close_ports/get_data.pl | $gawk '{ system("'$iptables'" " -'$ACTION' INPUT -i " $3 " -p " $2 " --dport " $1 " -j REJECT ") }'

exit 0