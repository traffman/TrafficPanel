#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
    unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
my $default_area_name = 'area';
my $co = new CGI;
my $module_name = $co->param('module') || "";
my $configFile = "$ck{cgfolder}TWM.conf";
$configFile = "$ck{twmfolder}modules/$module_name/module.conf" if ($module_name);
my $webaccess_style = "style='background-color: #fff5d9;'";
my $done_string = '';

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<title>Proxy2 IP configuration</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<form name=f1 action="" method=post>
<input type=hidden name=module value='$module_name'>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<div class=titlepage>Configuration</div>
__EOF
if ($allowEdit && $co->param("save") && $co->param("save") eq 'Save')
{
	my $xml = &readConfigFile($configFile);
	my $areas = $xml->{'variables'};
	if (exists($areas->{name}))
	{
		populatexml($areas, $default_area_name) if ($ck{all_variables} || IsTrue($areas->{'webaccess'}));
	}
	else
	{
		for my $key (keys(%$areas))
		{
			populatexml($areas->{$key}, $key) if (ref $areas->{$key} eq 'HASH' && ($ck{all_variables} || IsTrue($areas->{'webaccess'})));
		}
	}
#print Dumper $xml;
	saveConfigFile($configFile, $xml);
	my $init_script = $module_name?"$ck{twmfolder}modules/$module_name/init.sh":"$ck{scfolder}init.sh";
	if (-e $init_script)
	{
		run_twm_script("init.sh reconf", $module_name);
	}
	$done_string .= 'Data has beed saved.'.getWebDebugLog();
}
print <<__EOF;
$done_string
<br>
<table cellpadding=0 cellspacing=0 border=0 width=400>
__EOF
my $xml = &readConfigFile($configFile);
my $areas = $xml->{'variables'};
if (exists($areas->{name}))
{
	printItem($areas, $default_area_name) if ($ck{all_variables} || IsTrue($areas->{'webaccess'}));
}
else
{

	foreach my $key (%$areas)
	{
		printItem($areas->{$key}, $key) if (ref $areas->{$key} eq 'HASH' && ($ck{all_variables} || IsTrue($areas->{'webaccess'})));
	}
}

if ($allowEdit)
{
	print <<__EOF;
  <tr><td><input class=control type=submit name=save value="Save"></td></tr>
__EOF

	if (!$module_name)
	{ 
	print <<__EOF;
  <tr><td>&nbsp</td></tr>
  <tr><td>note! all ISP will be restarted when you save config.</td></tr>
__EOF
	}
}
print <<__EOF;
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
__EOF



sub printItem
{
	my ($label, $desc, $items, $webaccess) = ($_[0]->{'label'}, $_[0]->{'description'}, $_[0], IsTrue($_[0]->{'webaccess'}));
	if (!$ck{all_variables} && !$webaccess)
	{
		return;
	}
	my $style = $webaccess?'':$webaccess_style;
	print <<__EOF;
  <tr id='area_$_[1]' height=20 class="tableborder">
    <th align=left class="sectionname" tooltip='$desc' $style>$label</th>
  </tr>
  <tr>
     <td width="100%" $style>
<table cellpadding=0 cellspacing=0 border=0 width="100%" class=sectioncontent>
__EOF
	my @arr = ();
	for (keys %$items)
	{
		if (ref $items->{$_} eq 'HASH')
		{
			$items->{$_}->{name} = $_;
			push @arr, $items->{$_};
		}
	}
	for (sort {$a->{ordering} <=> $b->{ordering}} @arr)
	{
		printHTMLItem("area_${_[1]}_item_$_->{name}", $_) if ($ck{all_variables} || IsTrue($_->{'webaccess'}));
	}
  print <<__EOF;
</table>
<br>
    </td>
  </tr>
__EOF
}

sub printHTMLItem
{
	my $readonly = "";
	my $checked = "";
	my $className = 'control';
	my $style = IsTrue($_[1]->{'webaccess'})?'':$webaccess_style;
	if (exists $_[1]->{html_control}->{readonly} && IsTrue($_[1]->{html_control}->{readonly}))
	{
		$readonly = "readonly='$_[1]->{html_control}->{readonly}'";
		$className = 'rocontrol';
	}
	if ($_[1]->{html_control}->{type} eq 'checkbox')
	{
		$checked = $_[1]->{'value'} eq 1?'checked':'';
		$_[1]->{'value'} = 1;
	}
	my $val = ref($_[1]->{'value'}) eq 'HASH'?"":$_[1]->{'value'};

	if ($_[1]->{html_control}->{type} eq 'textarea')
	{
		print <<__EOF;
  <tr id='$_[0]' $style>
    <td style='padding: 3px;' width=10% nowrap>$_[1]->{'label'}:</td>
    <td style='padding: 3px;' width=90%><textarea $readonly class=$className name='$_[0]' rows='$_[1]->{html_control}->{rows}' cols='$_[1]->{html_control}->{cols}'>$val</textarea></td>
  </tr>
__EOF

	}
	else
	{ 
			print <<__EOF;
  <tr id='$_[0]' $style>
    <td style='padding: 3px;' width=10% nowrap>$_[1]->{'label'}:</td>
__EOF
		if ($_[1]->{html_control}->{type} eq 'grid')
		{
			print "<td style='padding: 3px;' width=90%>";
			print printGrid($readonly, $className, $_[0], $val, $_->{name});
			print "</td></tr>";
		}
		else 
		{
			print <<__EOF;
    <td style='padding: 3px;' width=90%><input type='$_[1]->{html_control}->{type}' $readonly $checked class=$className name='$_[0]' value='$val' size='$_[1]->{html_control}->{size}'></td>
  </tr>
__EOF
		}
	}
}

sub printGrid
{
	my ($readonly, $className, $name, $value, $nodename) = (shift, shift, shift, shift, shift);
	my ($checked);
	my $str = <<__EOF;
	 <table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=400>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
<tr>
__EOF

	my $node = getConfigNode($nodename, $configFile);
	my (@colList);
	for my $itemKey (keys %{$node->{html_control}->{columns}})
	{
		push @colList, {
			column => $itemKey,
			type => $node->{html_control}->{columns}->{$itemKey}->{type},
			title => $node->{html_control}->{columns}->{$itemKey}->{title},
			size => $node->{html_control}->{columns}->{$itemKey}->{size},
			ordering => $node->{html_control}->{columns}->{$itemKey}->{ordering},
			width => $node->{html_control}->{columns}->{$itemKey}->{width}
		};
	}
	my (@colSortList);
	for (sort {$a->{ordering} <=> $b->{ordering}} @colList)
	{
		push @colSortList , $_;
		$str .= "<th width='$_->{width}'>".$_->{title}."</th>";
	}

	$str .= "</tr><tr bgcolor=#ffffff>";
	my $index = 0;
	my $s = $node->{value}." ";
	my @arr = split(/\|/, $s);
	my $indexY = 0;
	foreach (@arr)
	{
		if ($index > $#colSortList)
		{
			$index = 0;
			$indexY++;
			$str .= "</tr><tr bgcolor=#ffffff>";
		}
		my $nv = $name.$index.$indexY;
		$colSortList[$index]->{items} = $_;
		if ($colSortList[$index]->{type} eq 'checkbox')
		{
			$checked = $_ =~ /1/?'checked':'';
			$_  = 1;
		}
		$str .= "<td align='center'>"."<input type='$colSortList[$index]->{type}' $readonly $checked class=$className name='$nv' value='$_' style=' margin-left:5%; margin-right:5%; width:90%;'  />"."</td>";
		$index++;
	}
	$str .= "</tr><tr bgcolor='#ffffff'>";
	if (!$readonly)
	{
		for(my $i = 0; $i <= $#colSortList; $i++)
		{
			my $v ="";
			if ($colSortList[$i]->{type} eq 'checkbox')
			{
				$checked = $_ eq 1?'checked':'';
				$v = 1;
			}
			$str .= "<td align='center'>"." <input type='$colSortList[$i]->{type}' $readonly class=$className name='".$name.$i.($indexY+1)."' value='$v' style=' margin-left:5%; margin-right:5%; width:90%;'  />"."</td>";
			
		}
	}
	$str .= "</tr></tbody></table></td></tr></table><input type=hidden name='".$name.'X'."' value='$index'><input type=hidden name='".$name.'Y'."' value='$indexY'>";
	
	return $str;

}

sub IsTrue
{
  my $s = lc($_[0]);
  return (!($s eq 'false' || $s eq '1'))
}


sub populatexml
{
	my $areas = $_[0];
	if (IsTrue($areas->{'webaccess'}))
	{
		for my $itemkey (keys %$areas)
		{
			if (ref($areas->{$itemkey}) eq 'HASH' && &IsTrue($areas->{$itemkey}->{'webaccess'}))
			{
			        if ($areas->{$itemkey}->{html_control}->{type} eq 'grid')
			        {
			        	my $gridValue  = "";
			                for(my $y = 0; $y < $co->param("area_${_[1]}_item_${itemkey}Y")+2; $y++)
			                {
			                	my $tmpValue = "";
			                	for(my $i = 0; $i < $co->param("area_${_[1]}_item_${itemkey}X"); $i++)
                                                {
                                                	$tmpValue .= $co->param("area_${_[1]}_item_${itemkey}$i$y")."|";
                                                }
                                                if ($tmpValue =~ /\d+|\w+/)
                                                {
                                                	$gridValue .= $tmpValue;
                                                }
                                                print "<br>";

                                        }         
                                        $areas->{$itemkey}->{value}  = substr $gridValue, 0, length($gridValue)-1;
			        }
			        else
			        {
					if ($areas->{$itemkey}->{html_control}->{type} eq 'checkbox')
					{
						$areas->{$itemkey}->{value} = defined $co->param("area_${_[1]}_item_${itemkey}")?1:0;
					}
					else
					{
						$areas->{$itemkey}->{value} = $co->param("area_${_[1]}_item_${itemkey}");
					}
				}
			}
		}
	}
}
