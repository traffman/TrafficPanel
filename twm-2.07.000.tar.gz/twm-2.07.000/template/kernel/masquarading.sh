#!/bin/bash

# Accept masquerade INPUT FORWARD OUTPUT
[accept_ip_rules]


# Deny INPUT FORWARD OUTPUT
[deny_ip_rules]
