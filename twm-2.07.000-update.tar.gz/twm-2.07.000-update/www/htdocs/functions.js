function doLoad()
{
	doResize();
	document.getElementById("treeDiv").style.visibility = 'visible';
}

function doResize()
{
	document.getElementById("treeDiv").style.height = (document.body.clientHeight - 50)+'px';
	document.getElementById("bodyFrame").style.height = document.getElementById("treeDiv").style.height;
	var d = document.getElementById("logoutDiv");
	d.style.visibility = 'visible';
	d.style.left = (document.body.clientWidth - 50) + 'px';
}

window.onresize = doResize;
var page_id;
function frmLoaded()
{
	var fw = document.getElementById("bodyFrame").contentWindow.document;
	if (fw)
	{
		var as = e('tree_table').getElementsByTagName('a');
		for (var i=0; i<as.length; i++)
		{
			if (as[i].firstChild.className == 'slabel')
			{
				page_id = as[i].id;
				e('pagePath').innerHTML = getPath(as[i].childNodes[0]).replace(/^ \/ /, '');
				break;
			}
		}

		var trTitle;
		var helpDiv = e('divHelp', fw, 'div');
		if (helpDiv)
		{
			var t = helpDiv.getElementsByTagName('table')[0];
			helpDiv.removeChild(t);
			var as = fw.getElementsByTagName('a');
			for (var i=0; i<as.length; i++)
			{
				if (as[i].className == 'help')
				{
					trTitle = as[i].parentNode.parentNode;
					var tr = fw.createElement('tr');
					var td = fw.createElement('td');
					td.colSpan = 2;
					tr.appendChild(td);
					var helpDiv = getHelpDiv(fw, helpDiv.innerHTML);
					var s = document.createElement('span');
					if (getCookie(page_id) == 0)
					{
						s.innerHTML = 'Show';
						helpDiv.style.display = 'none';
					}
					else
					{
						s.innerHTML = 'Hide';
						helpDiv.style.display = '';
					}
					s.style.color = '#2f8501';
					s.style.position = 'relative';
					s.style.top = '-4px';
					s.style.paddingRight = '5px';
					as[i].insertBefore(s, as[i].firstChild);
					as[i].onclick = function(){parent.openHelp(this); return false;}
					td.appendChild(helpDiv);
					trTitle.parentNode.insertBefore(tr, trTitle.nextSibling);
					break;
				}
			}
		}
			
	}
}


function getPath(obj)
{
	if (obj)
		return getPath(document.getElementById(obj.id.substr(0,obj.id.length-1))) + ' / ' + obj.innerHTML ;
	return '';
}


function openHelp(obj)
{
	var d = e('inlineHelpDiv', document.getElementById("bodyFrame").contentWindow.document, 'div');
	if (d.style.display == 'none')
	{
		d.style.display = ''
		obj.firstChild.innerHTML = 'Hide';
		setCookie(page_id, 1, 10 * 365);
	}
	else
	{
		d.style.display = 'none';
		obj.firstChild.innerHTML = 'Show';
		setCookie(page_id, 0, 10 * 365);
	}

}



function getHelpDiv(fw, html)
{
	var d = fw.createElement('div');
	d.style.backgroundColor = '#fafafa';
	d.style.border = '1px #e4e4e4 solid';
	d.id = 'inlineHelpDiv';
	d.innerHTML = "<div id=inlineHelp>"+html+'</div>';
	d.style.padding = '5';
	d.style.margin = '5 0';
	return d;
}


function deleteCookie(name, path)
{
	var expiration_date = new Date ();
	expiration_date . setYear (expiration_date . getYear () - 1);
	expiration_date = expiration_date . toGMTString ();
	var cookie_string = escape (name) + "=; expires=" + expiration_date;
	if (path != null)
		cookie_string += "; path=" + path;
	document.cookie = cookie_string;
}

function setCookie(name, value, expires, path, domain, secure)
{
	var today = new Date();
	today.setTime( today.getTime() );
	if ( expires )
		expires = expires * 1000 * 60 * 60 * 24;
	var expires_date = new Date( today.getTime() + (expires) );

	document.cookie = name + "=" +escape( value ) +
		( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
		( ( path ) ? ";path=" + path : "" ) +
		( ( domain ) ? ";domain=" + domain : "" ) +
		( ( secure ) ? ";secure" : "" );
}

function getCookie(name) {
	var a_all_cookies = document.cookie.split( ';' );
	var a_temp_cookie = '';
	var cookie_name = '';
	var cookie_value = '';
	for ( i = 0; i < a_all_cookies.length; i++ )
	{
		a_temp_cookie = a_all_cookies[i].split( '=' );
		cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');
		if ( cookie_name == name )
		{
			if ( a_temp_cookie.length > 1 )
				cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
			return cookie_value;
		}
		a_temp_cookie = null;
		cookie_name = '';
	}
	return null;
}
function e(id, scope, tagName, all)
{
	if (all == undefined)
		all = false;
	if (scope == undefined)
		scope = document;
	if (scope.getElementById && typeof id == "string")
		return scope.getElementById(id);
	else
	{
		var name = id;
		if (typeof id == "object")
		{
			name = id.name;
			id = id.id;
		}
		var items = scope.getElementsByTagName(tagName);
		var res = new Array();
		for (var i=0; i< items.length; i++)
		{
			if ((name != undefined && items[i].name == name) || (id != undefined && items[i].id == id))
			{
				if (all)
					res[res.length] = items[i];
				else
					return items[i];
			}
		}
		if (all)
			return res;
	}
	return undefined;
}
