#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
&checkAuthorization;

print "Content-Type: text/html\n\n";
my @protos = ('tcp','udp','gre','icmp');
my $proto_str = join('|', @protos);
my $allowEdit = &hasAdminAccess;

my $isp_list = &getISP;

my $co = new CGI;
my $doneString = "";

if ($allowEdit && defined $co->param("max_number"))
{
	my (%ips);
	my $max_number = $co->param("max_number") || 0;
	for (my $i=0; $i<=$max_number; $i++)
	{
		if (
			defined $co->param("port_$i")
			&& defined $co->param("proto_$i")
			&& defined $co->param("if_$i")
			&& defined $co->param("state_$i")
		)
		{
			my ($port, $proto, $if, $decs, $state) = ($co->param("port_$i"), $co->param("proto_$i"), $co->param("if_$i"), $co->param("desc_$i"), $co->param("state_$i"));
			if ($port !~ /^\d{1,5}$/)
			{
				$doneString .= "<br> Incorrect port number: $port";
			}
			elsif ($proto !~ /^tcp|udp|gre|icmp$/)
			{
				$doneString .= "<br> Incorrect protocol: $proto";
			}
			else
			{
				if (exists($ips{"$port, $proto, $if"}))	
				{
					$doneString .= "<br>Duplicate: $port, $proto, $if. Ignore second data.";
				}
				else	
				{
					$ips{"$port, $proto, $if"} = [$port, $proto, $if, $decs, $state];
				}
			}
		}
	}
	if (!$doneString)
	{
		runModuleMasq("D");
		my $xml;
		for (keys %ips)
		{
			push @{$xml->{rule}}, getNewItem($ips{$_});
		}
		saveModuleConfigFile($cm{ports}, $xml);
		runModuleMasq("A");
		$doneString = "Data are saved.";
	}
}

print <<__EOF;
<html>
<head>
<title>Close ports config page</title>
<script src="$ck{include_dir}twm.js"></script>
<link href="$ck{include_dir}twm.css" rel=stylesheet type=text/css>
</head>
<body>
<script>
function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return -1;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}

function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}

function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<a href="" class=grid onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	var s = '<select class=control name=proto_'+num+'>';
__EOF
print "s += '<option value=$_>$_</option>';\n" foreach (@protos);
print <<__EOF;
	s += '</select>';
	td.innerHTML = s;
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
//	td.innerHTML = '<input class=control style="width: 50px;" type=text name=if_'+num+' value="" maxlength=5>';
	var s = '<select class=control name=if_'+num+'>';
__EOF
print "s += '<option value=$isp_list->{$_}->{inf}>$isp_list->{$_}->{code}</option>';\n" for (keys %$isp_list);
print <<__EOF;
	s += '</select>';
	td.innerHTML = s;

	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control style="width: 50px;" type=text name=port_'+num+' value="" maxlength=5>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<select class=control name=state_'+num+'><option value=close>Close</option><option value=open>Open</option></select>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = '10px';
	td.innerHTML = '<input class=control style="width: 200px;" type=text name=desc_'+num+' value="">';
	tr.appendChild(td);
	obj.appendChild(tr);
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=max_number value="0">
<table cellpadding=0 cellspacing=0 border=0 width=400>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td class=titlepage>${\(&getModuleInfo->{name})}</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td width=100%>
<p><small>$doneString</small></p>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=24>
    <th width=20></th>
    <th width=70>Proto</th>
    <th width=150>ISP</th>
    <th width=70>Port</th>
    <th width=100>State</th>
    <th width=240>Description</th>
  </tr>
__EOF

my $i = 0;
my $xml = readModuleConfigFile($cm{ports});
if (ref $xml->{rule} eq 'HASH')
{
	printRow($xml->{rule}, $i);
}
else
{
	for (@{$xml->{rule}})
	{
		printRow($_, $i);
		$i++;
	}
}

my $input_policy = join("", run_script("$ck{iptables} -L INPUT -n|$ck{head} -1 "));
my $output_policy = join("", run_script("$ck{iptables} -L OUTPUT -n|$ck{head} -1 "));
my $forward_policy = join("", run_script("$ck{iptables} -L FORWARD -n|$ck{head} -1 "));

if ($input_policy =~ /ACCEPT/) { $input_policy = 'Input traffic - ACCEPT' } else { $input_policy = 'Input traffic - DENY' }
if ($output_policy =~ /ACCEPT/) { $output_policy = 'Output traffic - ACCEPT' } else { $output_policy = 'Output traffic - DENY' }
if ($forward_policy =~ /ACCEPT/) { $forward_policy = 'Forward traffic - ACCEPT' } else { $forward_policy = 'Forward traffic - DENY' }

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
__EOF

if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value="Save">
    </td>
  </tr>
</tbody>
</table>
__EOF
}

print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
  <tr><td>
	<br>Default firewall policy:
	<li>$input_policy
	<li>$output_policy
	<li>$forward_policy
  </td></tr>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>
<div class=help style="width: 400px; height: 220px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This page allows you to close or open access to specified local service. For example it is mysql 
and below are steps to create rule closing mysql from internet:
<br>
<li>Click "Add Item" buton
<li>Select Proto "tcp" because mysql uses tcp protocol
<li>Select your ISP
<li>Set port number (default mysql port number is 3306)
<li>Select state "Close"
<li>Set some description if you need
<li>Click "Save" button
<br>
If you need change rule need just click on link and save after changes.
<br><br>
Pay attention made changes are applied in the system at the moment you save them.
</div>
</body>
</html>
__EOF

sub printRow
{
	my $desc = ref $_[0]->{description} eq 'HASH'?'':$_[0]->{description};
	print <<__EOF;
<tr height=24 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[1]"><td
 align=center><a href="" onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a></td><td
 align=center><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{proto}</a></span><span style="display: none;"><select
 name=proto_$_[1] class=control style='width: 50px;'>
__EOF
	print "<option value=$_ ${\($_[0]->{proto} eq $_?'selected':'')}>$_</option>" foreach (@protos);
	print <<__EOF;
</select></span></td><td
 align=center><span><a href="" class=grid onClick="openItem(this); return false;">${\(getISPbyinf($_[0]->{interface}))}</a></span><span style="display: none;"><select
 name=if_$_[1] class=control style='width: 140px;'>
__EOF
print "<option value=$isp_list->{$_}->{inf} ${\($_[0]->{interface} eq $isp_list->{$_}->{inf}?'selected':'')}>$isp_list->{$_}->{code}</option>';\n" for (keys %$isp_list);
	print <<__EOF;
</select></span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{port}</a></span><span style="display: none;"><input class=control style='width: 50px; text-align: right;' type=text name=port_$_[1] value='$_[0]->{port}'></span></td><td
 align=center><span><a href="" class=grid onClick="openItem(this); return false;">${\($_[0]->{state} eq 'close'?'Closed':'Opened')}</a></span><span style="display: none;"><select 
 name=state_$_[1] class=control><option value='close' ${\($_[0]->{state} eq 'close'?'selected':'')}>Close</option><option value='open' ${\($_[0]->{state} eq 'open'?'selected':'')}>Open</option></select></td><td
 style='padding-left: 5px;'><span><a href="" class=grid onClick="openItem(this); return false;">$desc</a></span><span style="display: none;"><input class=control style='width: 230px;' type=text name=desc_$_[1] value='$desc'></span></td
></tr>
__EOF
}


sub getNewItem
{
	return {
		'port' => $_[0]->[0],
		'proto' => $_[0]->[1],
		'interface' => $_[0]->[2],
		'description' => $_[0]->[3],
		'state' => $_[0]->[4]
	};
}

sub getISPbyinf
{
	my $inf = shift;
	for (keys %$isp_list)
	{
		return $isp_list->{$_}->{code} if ($isp_list->{$_}->{inf} eq $inf);
	}
	return '';
}

__END__
