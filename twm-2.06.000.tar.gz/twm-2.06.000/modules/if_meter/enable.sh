#!/bin/bash

echo "ok"
#echo "some bug: $1 "
