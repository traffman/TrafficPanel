var tmpcolor;
var sColor = "#edeed5";
function ovrMouse(obj)	{
	tmpcolor = obj.style.backgroundColor;
	obj.style.backgroundColor = sColor; 
	var td = obj.getElementsByTagName("TD")[0];
	if (td && td.childNodes[0] && td.childNodes[0].style && td.childNodes[0].childNodes[0] && td.childNodes[0].childNodes[0].tagName=='IMG')
	{
		td.childNodes[0].style.visibility = "visible";
	}
	return true;
}


function outMouse(obj)	{
	obj.style.backgroundColor = tmpcolor; 
	var td = obj.getElementsByTagName("TD")[0];
	if (td && td.childNodes[0] && td.childNodes[0].style && td.childNodes[0].childNodes[0] && td.childNodes[0].childNodes[0].tagName=='IMG')
	{
		td.childNodes[0].style.visibility = "hidden";
	}
	return true;
}


function showHelp()	{
	var obj = document.getElementById("divHelp");
	obj.style.left = (document.body.clientWidth - parseInt(obj.style.width))/2;
	obj.style.top = (document.body.clientHeight - parseInt(obj.style.height))/2;
	if (obj.style.display == "block")	{
		obj.style.display = "none";
	}else	{
		obj.style.display = "block";
	}
}


function toggleStatus(chk, fld, f1, a1, a2)	{
	var f = (f1 != null)?f1:document.forms.f1;
	a1 = (a1 != null)?a1:1;
	a2 = (a2 != null)?a2:0;
	fld = (fld != null)?fld:chk.name.substring(1);
	f.elements[fld].value = (chk.checked ? a1 : a2) ;
}

function openItem(obj)	{
	var tr = obj.parentNode.parentNode.parentNode;
	for (var i=1; i<tr.cells.length; i++)
	{
		tr.cells[i].childNodes[0].style.display = "none";
		tr.cells[i].childNodes[1].style.display = "inline";
	}
}

function removeRow(thisRow){
    thisRow.parentNode.removeChild(thisRow,true);
}


function delItem(obj)	{
	removeRow(obj.parentNode.parentNode);
}
