package TrafficLogging;

require 5;
use Carp;

BEGIN 
{
	use TWM;
	use Data::Dumper;
	use Date::Calc qw(Today Date_to_Days Add_Delta_Days);
	$index = 0;
}


sub new
{
	my $self = {
		repArray => []
	};
	return bless $self;
}

sub DESTROY	{
	my $self = shift;
	delete $self->{$_} for (keys %$self);
	undef(%$self);
	undef $self;
}


############################################################
# creates reports array
############################################################
sub populate_report
{
	my ($self, $dtstart, $dtend, $report_file) = (shift, shift, shift, shift);
	$self->{repArray} = ();

	my ($dcSt, $mcSt, $ycSt) = ($3, $2, $1) if ($dtstart =~ /(\d{4})(\d\d)(\d\d)/);
	my ($dcEnd, $mcEnd, $ycEnd) = ($3, $2, $1) if ($dtend =~ /(\d{4})(\d\d)(\d\d)/);
	while (Date_to_Days($ycSt,$mcSt,$dcSt)  <= Date_to_Days($ycEnd,$mcEnd,$dcEnd))
	{
		(my $rpfile = $report_file) =~ s/\d{8}/${ycSt}${mcSt}${dcSt}/;
		if (-e "$ck{twmfolder}/modules/$mc/logs/$rpfile")
		{
			open(REPORTS, "$ck{twmfolder}/modules/$mc/logs/$rpfile") || (toErrorLog("Can not open #$ck{log_folder}$rpfile log file : $!") && die("Can not open #$ck{log_folder}$rpfile log file : $!")); 
			$index = 0;
			REP: while (<REPORTS>)
			{
				chomp;
				next REP if (!$_ || $_ =~ /^#/);
				$self->populate_report_item($_);
			}
			close(REPORTS);
		}
		($ycSt, $mcSt, $dcSt) = Add_Delta_Days($ycSt, $mcSt, $dcSt, 1);
		$dcSt = ('01'..'31')[$dcSt-1];
		$mcSt = ('01'..'12')[$mcSt-1];
	}
	return $self->{repArray};
}


sub populate_report_item
{
	my ($self, $item) = (shift, shift);
	$_ = $item;
	if (/^=(\d\d?)M/)	
	{
		$index = $1+2;
		$self->{repArray}->[$index] = {} if (! defined $self->{repArray}->[$index]);
	}
	elsif (/^=(Total)M/)	
	{
		$index = 0;
	}
	elsif (/\t(\-?\-?\>?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\-?\-?\>?)\t(.+?)\t(\d+)/)
	{
		my ($ip, $if, $size) = ($1, $2, $3);
		$size = 0 unless $size;
		$self->{repArray}->[1]->{$ip."\t".$if} = 0 unless $self->{repArray}->[1]->{$ip."\t".$if};
		$self->{repArray}->[$index]->{$ip."\t".$if} = $size + $self->{repArray}->[1]->{$ip."\t".$if};
	}
}


############################################################
# creates ip key hash with value true/false
############################################################
sub get_blocked
{
	my ($self, $ips) = (shift, shift);
	my $isblocked;
	for (@$ips) 
	{
		$isblocked->{$_->{ip}} = !$_->{enabled};
	}
	$isblocked;
}


############################################################
# 
############################################################
sub get_ext_interfaces
{
	my @interfaces;
	my $isp_list = &getISP;
	for (keys %$isp_list)
	{
		push @interfaces, [$isp_list->{$_}->{inf}, $isp_list->{$_}->{code}] if ! $isp_list->{$_}->{attributes}->{internal};
	}
	return \@interfaces;
}


############################################################
# returns report file name
############################################################
sub get_report_filename
{
	my $self = shift;
	my ($day,$month,$year) = (localtime())[3,4,5];
	return $cm{total_traffic_log}.(1900 + $year).('01'..'12')[$month].('00'..'31')[$day];
}

############################################################
# 
############################################################
sub get_report_file_mtime
{
	my ($self, $report_file) = (shift, shift);
	if (-e "$ck{twmfolder}/modules/$mc/logs/$report_file")
	{
		my $mtime = (stat("$ck{twmfolder}/modules/$mc/logs/$report_file"))[9];
		my ($sec, $min, $hour, $dc, $mc, $yc) = (localtime($mtime))[0,1,2,3,4,5];
		return ('00'..'31')[$dc].'-'.$short_months[$mc].'-'.(1901+$yc).' '.('00'..'24')[$hour].':'.('00'..'59')[$min].':'.('00'..'59')[$sec];
	}
	return undef;
}


############################################################
# calc total trafic
#	$index - col number (0 - Total)
#	$interfaceList - interfaces list
#	$ip - ip address
#	$stream - stream ('in' incomming, 'out' - ougouing, '' - both ways)
############################################################
sub traffic_count
{
	my ($self, $index, $interfaceList, $ip, $stream) = (shift, shift, shift, shift, shift);

	my $count = 0;
	my @items = ();
	push @items, "-->$ip" if ($stream eq 'in' || $stream eq '');
	push @items, "$ip-->" if ($stream eq 'out' || $stream eq '');
	foreach (@items)
	{
		foreach my $inf (@$interfaceList)
		{
			$count += $self->{repArray}->[$index]->{$_."\t".$inf->[0]} || 0;
		}
	}
	return $count;
}


############################################################
# returns %total_traffic
############################################################
sub total_traffic
{
	my ($self) = (shift);
	my $total_traffic;
	foreach (keys %{$self->{repArray}->[0]})
	{
		if (/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/)
		{
			$total_traffic->{$1} = 0 if (!exists $total_traffic->{$1});
			$total_traffic->{$1} += $self->{repArray}->[0]->{$_} || 0;
		}
	}
	return $total_traffic;
}



############################################################
# returns log items list
############################################################
sub get_items_list
{
	my ($self) = (shift, shift);
	my @showM = split /\,/, $cm{log_items_list};
	for (my $i=0; $i<=$#showM; $i++)
	{
		$showM[$i]--;
	}
	return \@showM;
}


return 1;
{}
