#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
&checkAuthorization;

print "Content-Type: text/html\n\n";
my @protos = ('tcp','udp');
my $proto_str = join('|', @protos);
my $allowEdit = &hasAdminAccess;

my $isp_list = &getISP;
my $ips = get_ip_name_hash(&getIPs);

my $co = new CGI;
my $doneString = "";

if ($allowEdit && defined $co->param("max_number"))
{
	my (%ips);
	my $max_number = $co->param("max_number") || 0;
	for (my $i=0; $i<=$max_number; $i++)
	{
		if (
			defined $co->param("gw_port_$i")
			&& defined $co->param("proto_$i")
			&& defined $co->param("gw_interface_$i")
			&& defined $co->param("host_port_$i")
			&& defined $co->param("host_ip_$i")
		)
		{
			my ($gw_port, $proto, $gw_interface, $host_port, $host_ip, $decsription) = ($co->param("gw_port_$i"), $co->param("proto_$i"), $co->param("gw_interface_$i"), $co->param("host_port_$i"), $co->param("host_ip_$i"), $co->param("description_$i"));
			$doneString .= "<br> Incorrect port number: $gw_port" if ($gw_port !~ /^\d{1,5}$/);
			$doneString .= "<br> Incorrect port number: $host_port" if ($host_port !~ /^\d{1,5}$/);
			$doneString .= "<br> Incorrect ip: $host_ip" if ($host_ip !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
			$doneString .= "<br> Incorrect protocol: $proto" if ($proto !~ /^tcp|udp|gre|icmp$/);
			if ($doneString eq '' && exists($ips{"$gw_port, $proto, $gw_interface"}))	
			{
				$doneString .= "<br>Duplicate: $gw_port, $proto, $gw_interface. Ignore second data.";
			}
			else	
			{
				$ips{"$gw_port, $proto, $gw_interface"} = [$gw_interface, $gw_port, $proto, $host_ip, $host_port, $decsription];
			}
		}
	}
	if (!$doneString)
	{
		runModuleMasq("D");
		my $xml;
		for (keys %ips)
		{
			push @{$xml->{rule}}, getNewItem($ips{$_});
		}
		saveModuleConfigFile($cm{ports}, $xml);
		runModuleMasq("A");
		$doneString = "Data are saved.";
	}
}

print <<__EOF;
<html>
<head>
<title>Close ports config page</title>
<script src="$ck{include_dir}twm.js"></script>
<link href="$ck{include_dir}twm.css" rel=stylesheet type=text/css>
</head>
<body>
<script>
function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return -1;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}

function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}

function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<a href="" class=grid onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	var s = '<select class=control name=proto_'+num+'>';
__EOF
print "s += '<option value=$_>$_</option>';\n" foreach (@protos);
print <<__EOF;
	s += '</select>';
	td.innerHTML = s;
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	var s = '<select class=control name=gw_interface_'+num+'>';
__EOF
for (keys %$isp_list)
{
	!$isp_list->{$_}->{attributes}->{internal} && print "s += '<option value=$isp_list->{$_}->{inf}>$isp_list->{$_}->{code}</option>';\n";
}
print <<__EOF;
	s += '</select>';
	td.innerHTML = s;
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control style="width: 50px;" type=text name=gw_port_'+num+' value="" maxlength=5>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control style="width: 100px;" type=text name=host_ip_'+num+' value="" maxlength=15>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control style="width: 50px;" type=text name=host_port_'+num+' value="" maxlength=5>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = '10px';
	td.innerHTML = '<input class=control style="width: 200px;" type=text name=description_'+num+' value="">';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = '10px';
	tr.appendChild(td);
	obj.appendChild(tr);
	tr.childNodes[3].childNodes[0].focus();
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=max_number value="0">
<table cellpadding=0 cellspacing=0 border=0 width=400>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td class=titlepage>${\(&getModuleInfo->{name})}</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td width=100% colspan=2>
<p><small>$doneString</small></p>
  </td>
  </tr>
  <tr bgcolor=#dddddd>
    <td colspan=2>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=24>
    <th width=20></th>
    <th width=50>Proto</th>
    <th width=100>ISP</th>
    <th width=50>GW Port</th>
    <th width=100>Host IP</th>
    <th width=170>User Name</th>
    <th width=70>Host Port</th>
    <th width=240>Description</th>
    <th width=140>Access to</th>
  </tr>
__EOF

my $i = 0;
my $xml = readModuleConfigFile($cm{ports});
if (ref $xml->{rule} eq 'HASH')
{
	printRow($xml->{rule}, $i);
}
else
{
	for (@{$xml->{rule}})
	{
		printRow($_, $i);
		$i++;
	}
}
print <<__EOF;
</tbody>
</table>
</td></tr>
__EOF

if ($allowEdit)
{
	print <<__EOF;
<td colspan=2><tr>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value="Save">
    </td>
  </tr>
</tbody>
</table>
</td></tr>
__EOF
}

print <<__EOF;
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 220px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This module maps your proxy server port number of external interface to local network host port number.
That allows you to get access to local network host from Internet using a specified port number.
</div>

</body>
</html>
__EOF

sub printRow
{
	my $desc = ref $_[0]->{description} eq 'HASH'?'':$_[0]->{description};
	my $gw_ip;
	my $name = $ips->{$_[0]->{host_ip}};
	print <<__EOF;
<tr height=24 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[1]"><td
 align=center><a href="" onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a></td><td
 align=center><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{proto}</a></span><span style="display: none;"><select
 name=proto_$_[1] class=control style='width: 50px;'>
__EOF
	print "<option value=$_ ${\($_[0]->{proto} eq $_?'selected':'')}>$_</option>" foreach (@protos);
	print <<__EOF;
</select></span></td><td
 align=center><span><a href="" class=grid onClick="openItem(this); return false;">${\(getISPbyinf($_[0]->{gw_interface}))}</a></span><span style="display: none;"><select
 name=gw_interface_$_[1] class=control>
__EOF
for (keys %$isp_list)
{
	if ($_[0]->{gw_interface} eq $isp_list->{$_}->{inf})
	{
		$gw_ip = $isp_list->{$_}->{ip};
	}
	!$isp_list->{$_}->{attributes}->{internal} && print "<option value=$isp_list->{$_}->{inf} ${\($_[0]->{gw_interface} eq $isp_list->{$_}->{inf}?'selected':'')}>$isp_list->{$_}->{code}</option>';\n";
}
	print <<__EOF;
</select></span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{gw_port}</a></span><span style="display: none;"><input class=control style='width: 50px; text-align: right;' type=text name=gw_port_$_[1] value='$_[0]->{gw_port}'></span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{host_ip}</a></span><span style="display: none;"><input class=control style='width: 100px; text-align: right;' type=text name=host_ip_$_[1] value='$_[0]->{host_ip}'></span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$name</a></span><span style="display: none;">$name</span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{host_port}</a></span><span style="display: none;"><input class=control style='width: 50px; text-align: right;' type=text name=host_port_$_[1] value='$_[0]->{host_port}'></span></td><td
 style='padding-left: 5px;'><span><a href="" class=grid onClick="openItem(this); return false;">$desc</a></span><span style="display: none;"><input class=control style='width: 230px;' type=text name=description_$_[1] value='$desc'></span></td><td
 style='padding-left: 5px;'><span>$gw_ip:$_[0]->{gw_port}</span><span style="display: none;">$gw_ip:$_[0]->{gw_port}</span></td
></tr>
__EOF
}


sub getNewItem
{
	return {
		'gw_interface' => $_[0]->[0],
		'gw_port' => $_[0]->[1],
		'proto' => $_[0]->[2],
		'host_ip' => $_[0]->[3],
		'host_port' => $_[0]->[4],
		'description' => $_[0]->[5]
	};
}

sub getISPbyinf
{
	my $inf = shift;
	for (keys %$isp_list)
	{
		return $isp_list->{$_}->{code} if ($isp_list->{$_}->{inf} eq $inf);
	}
	return '';
}

__END__
