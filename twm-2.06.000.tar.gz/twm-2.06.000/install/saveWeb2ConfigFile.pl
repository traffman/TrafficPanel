#!/usr/bin/perl -w

BEGIN   {
	my $file = '../bin/';
    unshift(@INC, $file);
}

use strict;
use TWM;

if ($ARGV[0])
{
	my $configFile = '../bin/TWM.conf';
	my $xml = &readConfigFile($configFile);
	my $areas = $xml->{'variables'}{'web_part'};
	foreach(@ARGV) {
		/(\w+)=([\/\w-]+)/;
		$areas->{$1}{'value'} = $2;
	}
	saveConfigFile($configFile, $xml);
}
else
{
	my $file = __FILE__;
	print <<EOF;
Usage: perl $file httpd_port=80
EOF
}

__END__

