#!/bin/bash

m1=`date +%m`
y1=`date +%Y`
aM=( AAA Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec )
m1=`expr $m1 - 0`
if [ $m1 -eq 1 ]; then
    m1=11
    y1=`expr $y1 - 1`
else
    if [ $m1 -eq 2 ]; then
        m1=12
        y1=`expr $y1 - 1`
    else
        if [ $m1 -gt 2 ]; then
            m1=`expr $m1 - 2`
        fi
    fi
fi

if [ $m1 -lt 10 ] ; then
	m1="0$m1"
fi

log_dir="$TWMFOLDER/modules/tcp_logging/logs"
cd $log_dir
tar -czf "reports$y1$m1.tz" ./reports$y1$m1?? > /dev/null 2>&1
rm -Rf ./reports$y1$m1??


