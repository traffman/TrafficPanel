#!/usr/bin/perl -w

BEGIN   {
	my $file = '../bin/';
    unshift(@INC, $file);
}

use strict;
use TWM;

if ($ARGV[0])
{

	my $configFile = '../bin/TWM.conf';
	my $xml = &readConfigFile($configFile);

	if ($ARGV[0] =~ /dns/) {
		my $areas = $xml->{'variables'}{'dns'};
		shift(@ARGV);
		foreach(@ARGV) {
			/(\w+)=([\/?\w+.?\w+?]+)/;
			$areas->{$1}{'value'} = $2;
		}
	}

	elsif($ARGV[0] =~ /common_twm/) {
		my $areas = $xml->{'variables'}{'common_twm'};
		shift(@ARGV);
		foreach(@ARGV) {
			/(\w+)=([\/\w-]+)/;
			$areas->{$1}{'value'} = $2;
			}
	}
	
	elsif($ARGV[0] =~ /system_scripts/) {
		my $areas = $xml->{'variables'}{'system_scripts'};
		shift(@ARGV);
		foreach(@ARGV) {
			/^(\/.+\/(\w+))$/;
			$areas->{$2}{'value'} = $1;
	    }
	}

	elsif($ARGV[0] =~ /web_part/) {
	    my $areas = $xml->{'variables'}{'web_part'};
		shift(@ARGV);
	    foreach(@ARGV) {
	        /(\w+)=([\/\w-]+)/;
	        $areas->{$1}{'value'} = $2;
	    }
	}

	saveConfigFile($configFile, $xml);
}
else {

	my $file = __FILE__;
	print <<EOF;
Usage: perl $file dns _domain_name=domain.name _named_direct_zone=zone.name _named_zone_dir=/var/lib/named/
	perl $file common_twm  _kernel_template=/usr/local/twm/template/kernel cgfolder=/usr/local/twm/www/cgi-bin/
	perl $file system_scripts /sbin/ifconfig /usr/bin/sha1sum
	perl $file web_part httpd_port=80
EOF

}

__END__
