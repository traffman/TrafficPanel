#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
    unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

my $co = new CGI;
my $allowEdit = &hasAdminAccess;
my $resultString = "";

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<title>Proxy2 IP configuration</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
__EOF

if ($allowEdit && $co->param("save") && $co->param("save") eq 'Save')
{
	my $areas = &getTaskManagerConfig;
        my $error = "";
	for my $areakey (keys(%$areas))
	{
		next if (ref($areas->{$areakey}) ne 'HASH' || !IsTrue($areas->{$areakey}->{'webaccess'}));
		if(exists $areas->{name})
		{
			$error = populatexml($areas, $areas->{name});
		} 
		else 
		{
			$error = populatexml($areas->{$areakey}, $areakey);
		}
		if ($error ne '')
		{
			print $error;
		}
	}
	setTaskManagerConfig($areas);
	run_twm_script("task_manager.sh init");
	$resultString .= getWebDebugLog();
}

print <<__EOF;
$resultString
<form name=f1 action="" method=post>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=700>
<tbody>
  <tr>
    <td class=titlepage>Task manager</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<br>
<table cellpadding=0 cellspacing=0 border=0 width=400>
__EOF

my %modules = getModules();
my $areas = &getTaskManagerConfig;
for my $areakey (keys(%$areas))
{
	next if (ref($areas->{$areakey}) ne 'HASH');
	if (exists $areas->{name})
	{
		printItem($areas->{$areakey}, $areas->{name}, \%modules, $areakey);	
	} 
	else
	{
		printItem($areas->{$areakey}, $areakey, \%modules);
	}
}

if ($allowEdit)
{
print <<__EOF;
  <tr><td><input class=control type=submit name=save value="Save"></td></tr>
__EOF
}
print <<__EOF;
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>

<div class=help style="width: 500px; height: 240px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img src="/logout-off.png" width=13 height=13 border=0></a></td></tr>
</tbody>
</table>
Task manager runs TrafficPanel scripts at specified time like it makes cron. If "Script" ends with ".pl" or ".php" then
this value will be passed to corresponding language interpreter otherwise task manager assumes it is shell script.
<br>
 Year,month,day,hour,minute,second can have different values:
<li>Number to run script at specified time. Example: 3, 16, 28
<li>Time frame to run script during time frame. Example: 0-10, 15-25, 20-40
<li>Asterisk to run always. Example: *
<li>Period to run at specified time periodically. Example: */5, */10
<br>
For example 
<li>if task date-time is */*/* 8-23:0 then it will be started every day at hours from 8:00 to 23:00 when minutes is 0.
<li>if task date-time is */*/1 5:0 then it will be started every first day of each months at 5:00 hour.
<li>if task date-time is */*/* *:*/20 then it will be started every day every 20 minutes of each hour.
</div>


</body>
</html>
__EOF



sub printItem
{
  	my ($items) = ($_[0]);
	my $name = $_[1] eq $twm_kernel_key?'TrafficPanel kernel':$_[2]->{$_[1]}->{name};
  print <<__EOF;
  <tr id='area_$_[1]' height=20 class="tableborder">
    <th align=left class="sectionname">$name</th>
  </tr>
  <tr>
     <td width="100%">
<table cellpadding=0 cellspacing=0 border=0 width="100%" class=sectioncontent>
__EOF
	if ($_[3])
	{
		printHTMLItem("area_${_[1]}_item_${\$_[3]}", $items);
	}
	else 
	{
        	for my $itemkey (keys %$items)
		{
			printHTMLItem("area_${_[1]}_item_${itemkey}", $items->{$itemkey});
		}
	}
  print <<__EOF;
</table>
<br>
    </td>
  </tr>
__EOF
}

sub printHTMLItem
{
	my $readonly = "";
	my $checked = "";
	my $className = 'control';
	if (exists $_[1]->{html_control}->{readonly} && IsTrue($_[1]->{html_control}->{readonly}))
	{
		$readonly = "readonly='$_[1]->{html_control}->{readonly}'";
		$className = 'rocontrol';
	}
	if (defined($_[1]->{html_control}->{type}) && $_[1]->{html_control}->{type} eq 'checkbox')
	{
		$checked = $_[1]->{'value'} eq 1?'checked':'';
		$_[1]->{'value'} = 1;
	}
	print <<__EOF;
  <tr>
     <td width="100%" style="padding-left: 10px; padding-bottom: 10px;">
	<input type="hidden" name='$_[0]_label' value='$_[1]->{label}'/>
	<input type="hidden" name='$_[0]_description' value='$_[1]->{description}'/>
     <div class="subsectionname" style="padding-top: 10px;">$_[1]->{label}</div>
<table cellpadding=0 cellspacing=0 border=0 width="100%" class=sectioncontent>
  <tr>
    <td style='padding: 3px;' width=10% nowrap>Enabled:</td>
    <td style='padding: 3px;' width=90%><input type='checkbox' $readonly ${\($_[1]->{enabled}?'checked':'')} class=$className name='$_[0]_enabled' value='1'></td>
  </tr>
  <tr>
    <td style='padding: 3px;' width=10% nowrap>Script:</td>
    <td style='padding: 3px;' width=90%><input type='text' $readonly class=$className name='$_[0]_cmd' value='$_[1]->{cmd}' size='25'></td>
  </tr>
  <tr>
    <td style='padding: 3px;' width=10% nowrap>Date:</td>
    <td style='padding: 3px;' width=90%>
      <input type='text' $readonly class=$className name='$_[0]_year' value='$_[1]->{year}' size='5'>
      /
      <input type='text' $readonly class=$className name='$_[0]_month' value='$_[1]->{month}' size='2'>
      /
      <input type='text' $readonly class=$className name='$_[0]_day' value='$_[1]->{day}' size='2'>
      (yyyy/mm/dd)
    </td>
  </tr>
  <tr>
    <td style='padding: 3px;' width=10% nowrap>Time:</td>
    <td style='padding: 3px;' width=90%>
      <input type='text' $readonly class=$className name='$_[0]_hour' value='$_[1]->{hour}' size='2'>
      :
      <input type='text' $readonly class=$className name='$_[0]_minute' value='$_[1]->{minute}' size='2'>
__EOF
if ($ck{task_manager_support_sec})
{
	print <<__EOF;
      :
      <input type='text' $readonly class=$className name='$_[0]_sec' value='$_[1]->{sec}' size='2'>
      (hh:mm:ss)
__EOF
}
else
{
	print <<__EOF;
      <input type='hidden' $readonly class=$className name='$_[0]_sec' value='0' size='2'>
      (hh:mm)
__EOF
}
print <<__EOF;
    </td>
  </tr>
  <tr>
    <td style='padding: 3px;' width=10% nowrap valign=top>Week Days:</td>
    <td style='padding: 3px;' width=90%>
     <select name='$_[0]_weekday' multiple size=3>
       <option value="any" ${\($_[1]->{weekday} =~ /any/?'selected':'')}>Any days
       <option value="Mon" ${\($_[1]->{weekday} =~ /Mon/?'selected':'')}>Monday
       <option value="Thu" ${\($_[1]->{weekday} =~ /Thu/?'selected':'')}>Thursday
       <option value="Wed" ${\($_[1]->{weekday} =~ /Wed/?'selected':'')}>Wednesday
       <option value="Tue" ${\($_[1]->{weekday} =~ /Tue/?'selected':'')}>Tuesday
       <option value="Fri" ${\($_[1]->{weekday} =~ /Fri/?'selected':'')}>Friday
       <option value="Sut" ${\($_[1]->{weekday} =~ /Sut/?'selected':'')}>Suterday
       <option value="Sun" ${\($_[1]->{weekday} =~ /Sun/?'selected':'')}>Sunday
     </select>
    </td>
  </tr>
</table>
     </td>
  </tr>
__EOF
}


sub IsTrue
{
  my $s = lc($_[0]);
  return (!($s eq 'false' || $s eq '1'))
}


sub populatexml
{
	my $errors = '';
	my $areas = $_[0];
	for my $itemkey (keys %$areas)
	{
		if (ref($areas->{$itemkey}) eq 'HASH')
		{
			for my $key (keys %{$areas->{$itemkey}})
			{

				my $value = "";
				if ($key eq 'weekday')
				{
					my @arr = $co->param("area_${_[1]}_item_${itemkey}_$key");
					foreach(@arr)
					{
						$value .= $_."|";
					}
					if ($value =~ /any/)
					{
						$value = "any|";
					}
					
				} else 
				{
					$value = $co->param("area_${_[1]}_item_${itemkey}_$key");
				}
				if ($key eq 'year')
				{
					if ($value !~ /^(\d{4}|\*|\*\/\d{1,2})$/)
					{
						$errors .= "incorect value : ".$value;  								
						$value = "";
					} 
				}
				if ($key eq 'day' || $key eq 'month' || $key eq 'hour' || $key eq 'minute' || $key eq 'sec')
				{
				    if ($value !~ /^(\d{1,2}|\*\/\d{1,2}|\d{1,2}\-\d{1,2}|\*)$/)
				    {
					$errors .= "incorect value : ".$value;  
					$value = "";
				    }
				}
				if ($key eq 'enabled')
				{
					$areas->{$itemkey}->{$key} = defined $value?1:0;
				} 
				else 
				{
					if ($value ne '')
					{
	                                	$areas->{$itemkey}->{$key} = $value;
					}
				}
			}
		}
	}
	return $errors;
}
