#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use File::Copy;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
my $co = new CGI;

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<script>
function formValidate(p1)
{
	var f = document.forms.f1;
	f.todo.value = p1;
	f.submit();
	return false;
}


function addItem()
{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	tr.height = 22;
	var dt = '&&temp&&.'+Date.parse(new Date);
	document.getElementById("added").value += dt + "|";
	tr.id = 'tr_'+dt;
	tr.onmouseover = function() {ovrMouse(this)};
	tr.onmouseout = function() {outMouse(this)};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.textAlign = "center";
	td.innerHTML = '<a href="" class=grid onClick="deleteItem(this); return false;" style="visibility: hidden;"><img src="/delete.gif" border=0></a>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control type=checkbox name='+dt+'_used value="1" checked>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_dns_name value="" size=16 maxlength=50>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<select class=control name='+dt+'_type style="width: 50px;"><option value=A>A</option><option value=MX>MX</option></select>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_ip value="" size=15 maxlength=15>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_description value="" size=28 maxlength=50>';
	tr.appendChild(td);

	obj.appendChild(tr);
	tr.childNodes[2].childNodes[0].focus();
}


function removeRow(thisRow)
{
    thisRow.parentNode.removeChild(thisRow,true);
}


function deleteItem(obj, p1)	
{
	var deletedObj = document.getElementById("deleted");
	var idObj = document.getElementById("s1_"+p1+"_id");
	if (deletedObj.value.indexOf(idObj.text + "|") == -1)
   		deletedObj.value += idObj.text + "|";
	removeRow(obj.parentNode.parentNode);
}


function openItem(p1)
{
	var changedObj = document.getElementById("changed");
	var idObj = document.getElementById("s1_"+p1+"_id");
	if (changedObj.value.indexOf(idObj.text + "|") == -1)
   		changedObj.value += (idObj.text||idObj.innerText) + "|";
	document.getElementById("s2_"+p1+"_used") .style.display = "inline";
	document.getElementById("s1_"+p1+"_dns_name") .style.display = "none";
	document.getElementById("s2_"+p1+"_dns_name") .style.display = "inline";
	document.getElementById("s1_"+p1+"_type") .style.display = "none";
	document.getElementById("s2_"+p1+"_type") .style.display = "inline";
	document.getElementById("s1_"+p1+"_ip") .style.display = "none";
	document.getElementById("s2_"+p1+"_ip") .style.display = "inline";
	document.getElementById("s1_"+p1+"_description") .style.display = "none";
	document.getElementById("s2_"+p1+"_description") .style.display = "inline";
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
__EOF
my $doneString = "";
my $xml = readConfigFile($ck{scfolder}.$ck{_dns_aliases_list});
if ($allowEdit && $co->param("todo"))
{
	my $items = $xml->{items}->{item};
	$items = [$items] if (ref $items eq 'HASH');

	foreach (@$items)
	{
		$_ = get_item($co, $_->{dns_name}."_ident") if ($co->param("changed") =~ /$_->{dns_name}\|/);
	}

	$_ = $co->param("added");
	push @$items, get_item($co, $1) while (/(.+?)\|/g);

	for (my $i=0; $i<=$#$items; $i++)
	{    
		splice(@$items, $i--,1) if ($co->param("deleted") =~ /$items->[$i]->{dns_name}\|/);
	}

	for (my $i=0; $i<=$#$items; $i++)
	{
		$doneString .= validate($items->[$i]);
	}

	$xml->{items}->{item} = $items;

	if (!$doneString)
	{
		saveConfigFile($ck{scfolder}.$ck{_dns_aliases_list}, $xml);
		if ($co->param("todo") eq 'apply')
		{
			run_twm_script("$ck{_ip_list_saver} n");
		}
		$doneString = "Data are applied. ".getWebDebugLog();
	}
	$doneString =~ s/\n/<br>/g;
}
        
print <<__EOF;
<input type=hidden name=added id=added value="">
<input type=hidden name=changed id=changed value="">
<input type=hidden name=deleted id=deleted value="">
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=760>
<tbody>
  <tr>
    <td class=titlepage>DNS aliases</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$doneString</small></p>
<table cellspacing=0 cellpadding=0 width=570>
  <tr class=tableborder>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=50>Used</th>
    <th width=120>Host Name</th>
    <th width=60>Type</th>
    <th width=110>IP Address</th>
    <th width=200>Description</th>
</tr>
__EOF
my $xml = readConfigFile($ck{scfolder}.$ck{_dns_aliases_list});
my $items = $xml->{items}->{item};
$items = [$items] if (ref $items eq 'HASH');
$items = [sort {$a->{dns_name} cmp $b->{dns_name}} @$items];
foreach (@$items)
{
	my ($used, $dns_name, $ip, $type, $description) = ($_->{used}, $_->{dns_name}, $_->{ip}, $_->{type}, $_->{description});
	(my $pr = $dns_name.'_ident');# =~ s/\./_/g;
	my $checkedUsed = $used eq 1?"checked":"";
	$description = '' if ref $description eq 'HASH';
	print <<__EOF;
  <tr height=22 id=tr_$pr onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff>
    <td width=10 align=middle><a href="" onClick="deleteItem(this,'$pr'); return false;" style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td nowrap align=middle><span id="s1_${pr}_used"><input name="${pr}_used" value="1" onClick="openItem('$pr');" type=checkbox $checkedUsed /></a></span><span id="s2_${pr}_used" style="display: none;"></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_dns_name"><a id="s1_${pr}_id" href="" class=grid onClick="openItem('$pr'); return false;">$dns_name</a></span><span id="s2_${pr}_dns_name" style="display: none;"><input class=control type=text name=${pr}_dns_name value="$dns_name" size=16 maxlength=50></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_type"><a href="" class=grid onClick="openItem('$pr'); return false;">$type</a></span><span id="s2_${pr}_type" style="display: none;"><select style="width: 50px;" class=control name=${pr}_type><option value=A ${\(setSelected($type, 'A'))}>A</option><option value=MX ${\(setSelected($type, 'MX'))}>MX</option></select></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_ip"><a href="" class=grid onClick="openItem('$pr'); return false;">$ip</a></span><span id="s2_${pr}_ip" style="display: none;"><input class=control type=text name=${pr}_ip id=${pr}_ip value="$ip" size=15 maxlength=15></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_description"><a href="" class=grid onClick="openItem('$pr'); return false;">$description</a></span><span id="s2_${pr}_description" style="display: none;"><input class=control type=text name=${pr}_description value="$description" size=28 maxlength=50></span></td>
</tr>
__EOF
}
print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</tbody>
</table>
<input type=hidden name=todo value="">
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=button value=Apply onClick="formValidate('apply');">
    </td>
  </tr>
</tbody>
</table>
__EOF
}
	print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>
<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Yor can define local and remote host DNS aliases available inside your network only.<br>
</div>
</body>
</html>
__EOF


sub get_item
{
	my %item;
	$item{used} = $_[0]->param($_[1]."_used")?1:0;
	$item{ip} = $_[0]->param($_[1]."_ip") || '';
	$item{dns_name} = $_[0]->param($_[1]."_dns_name") || '';
	$item{type} = $_[0]->param($_[1]."_type") || '';
	$item{description} = $_[0]->param($_[1]."_description") || '';
	return \%item;
}



sub validate_dns_name
{
	return $_[0]->{dns_name} !~ /^[a-zA-Z0-9\-]+$/ && "Incorrect Domain Name '$_[0]->{dns_name}'\n";
}

sub validate
{
	return 
		validate_dns_name($_[0])
		|| "";
}

__END__
