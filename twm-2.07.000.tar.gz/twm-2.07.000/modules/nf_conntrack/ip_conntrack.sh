#!/bin/bash

if [ -e $TWMFOLDER/modules/nf_conntrack/ip_conntrack.pl ]; then
	perl $TWMFOLDER/modules/nf_conntrack/ip_conntrack.pl $@
else
	echo "Could not find file $TWMFOLDER/modules/nf_conntrack/ip_conntrack.pl"
fi

