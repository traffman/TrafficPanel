#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
print "Content-Type: text/xml\n\n";
my $co = new CGI;
my $module_name = $co->param('code');
my $enable = $co->param('enable')?'true':'false';

my $xml = &getModuleInfo($module_name);
my ($status, $message) = ('true', '');
if ($allowEdit && ref $xml eq 'HASH')
{
	my $state = join("",run_twm_script("enable.sh $enable", $module_name));
	chomp $state;
	if (lc($state) eq 'ok')
	{
		$xml->{enabled} = $enable;
	}
	else
	{
		($status, $message) = ('false', 'Operation failed. '.$state);
	}
}
elsif (!$allowEdit)
{
	($status, $message) = ('false', 'Permission denied');
}
else
{
	($status, $message) = ('false', 'Module was not found');
}
setModuleInfo($module_name, $xml) if ($status eq 'true');

print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
