#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use Bandwidth;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $objBandWidth = Bandwidth->new();
my $xml = &readModuleConfigFile($cm{pools_config});
my $classes = &readModuleConfigFile($cm{classes_config});
my @sorted = $objBandWidth->convertPool2Array($xml);

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<script src="/twm.js"></script>
<script src="/http_post.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
function orderPool(obj, order)
{
	var httpp = new HTTPPost();
	var v = order==1?'&up=1':'&down=1';
	httpp.postData('pool_order.pl', 'name='+obj.parentNode.parentNode.getAttribute("name")+v, orderHandler);

	function orderHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)	
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status == 'true')
				{
					orderItem(obj, order);
				}
				else
				{
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
			}
		}
	}
}



function orderItem(obj, order)
{
	var tbd = obj.parentNode.parentNode.parentNode;
	for (var i=0; i<tbd.rows.length; i++)
	{
		if (tbd.rows[i].getAttribute("name") == obj.parentNode.parentNode.getAttribute("name"))
		{
			if (order == 1 && i>0)
			{
				tbd.insertBefore(tbd.rows[i], tbd.rows[i-1]);
			}
			else if (i+1<tbd.rows.length)
			{
				tbd.insertBefore(tbd.rows[i+1], tbd.rows[i]);
			}
			break;
		}

	}
}



function delPool(obj)
{
	var httpp = new HTTPPost();
	httpp.postData('delete_pool.pl', 'name='+obj.parentNode.parentNode.getAttribute("name"), deleteHandler);

	function deleteHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)	
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status == 'true')
				{
					delItem(obj);
				}
				else
				{
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
			}
		}
	}
}
</script>
</head>
<body>
<form name=f1 action="" method=post>
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>Pools</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td style="padding-top: 20px;">
__EOF
if ($allowEdit)
{
	print '<a href="pool.pl?new=1" class=control>Add new</a>';
}
	print <<__EOF;
    </td>
    <td align=right>&nbsp;</td>
  </tr>
</tbody>
</table>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=650>
  <tr bgcolor=#dddddd>
    <td colspan=2>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=50>Ordering</th>
    <th width=100>Name</th>
    <th width=100>Speed (Kb/s)</th>
    <th>Description</th>
    <th>Classes</th>
  </tr>
__EOF
	for (@sorted)	{
		my $bgcolor = $_->{'readonly'} eq 'false'?'#ffffff':'#fafafa';
		print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=$bgcolor name='$_->{'name'}'>
    <td align=middle><a href='' onClick='delPool(this); return false' style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td align=middle><a class=grid href="#" onClick='orderPool(this, 1);'><img src='/sort-up.gif' width=13 height=8 border=0></a><a class=grid href="#" onClick='orderPool(this, 0);' ><img src='/sort-down.gif' width=13 height=8 border=0></a></td>
    <td style='padding-left: 5px;'><a class=grid href='pool.pl?fl=$_->{'name'}' >$_->{'label'}</a></td>
    <td style='padding-right: 5px;' align=right>${\($_->{speed} eq '-1'?'Unlimited':$_->{speed})}</td>
    <td style='padding-left: 5px;'>${\(ref $_->{description} eq 'HASH'?'':$_->{description})}</td>
    <td style='padding-left: 5px;'>${\(getContentAsHTML($_->{'content'}, $classes))}</td>
  </tr>
__EOF
	}
	print <<__EOF;
</tbody>
</table>
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Here is a list of pools ordered by processing of http request. A pool is a classes combination with a defined speed and order number.
The first http request info coincidence with some pool class found is applied as pool speed for this http request.
</div>


</body>
</html>
__EOF


sub getContentAsHTML
{
	my $content = "";
	if (exists($_[0]->{name}))
	{
		$content.=${\(($_[0]->{allow} eq 'false')?'<span>!</span>':'<span style="visibility: hidden;">!</span>')}.' '.$objBandWidth->getClassName($_[1], $_[0]->{name})->[1]."<br>";
	}
	else
	{
		for my $key(keys %{$_[0]})
		{
			$content.=${\(($_[0]->{$key}->{allow} eq 'false')?'<span>!</span>':'<span style="visibility: hidden;">!</span>')}.' '.$objBandWidth->getClassName($_[1], $key)->[1]."<br>" if (ref $_[0]->{$key} eq 'HASH');
		}
	}
	$content;
}
