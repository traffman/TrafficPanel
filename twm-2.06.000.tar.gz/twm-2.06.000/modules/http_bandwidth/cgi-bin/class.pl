#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}
          
use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
use Bandwidth;

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
print "Content-Type: text/html\n\n";
my $xml = readModuleConfigFile($cm{classes_config});
my $objBandWidth = Bandwidth->new();

my $co = new CGI;
my $class = $co->param("fl") || '';
my $new = $co->param("new") || '0';

$class = addNewACL($class, $xml) if ($new eq '1');
my $acl = $objBandWidth->getACL($class, $xml);
print "Access class is not specified." if (!$acl);
my $title = $acl->{'label'}?'Edit class: '.$acl->{'label'} : 'Add new class';
my $ip_hash = get_ip_name_hash(&getIPs);

my $doneString = "";
if ($allowEdit && defined $co->param("max_number"))
{
	my @items;
	my $max_number = $co->param("max_number") || 0;
	for (my $i=0; $i<=$max_number; $i++)
	{
		my $value = $co->param("fld_$i");
		if ($value)
		{
			my $type = $co->param("type_$i") || '';
			if ($type eq 'Server Name')
			{
				$value =~ s/\./\\\./g;
				$value = '(.+\.)?'.$value;
			}
			elsif ($type eq 'File Extention')
			{
				$value =~ s/\./\\\./g;
				$value = '\.'.$value.'$';
			}
			elsif ($value =~ /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/)
			{
				$value .= "/$objBandWidth->{ip_mask}";
			}
			else
			{
				$value =~ s/\./w\\\./g;
			}
			push @items, $value;
		}
	}
	$acl->{blocked} = $co->param("blocked")||'0';
	$acl->{description} = $co->param("description")||'';
	$acl->{label} = $co->param("label")||'';
	$acl->{type} = $co->param("type");
	$acl->{content} = $#items>=0?join("\n",@items):'';
	$doneString = 'Label can not be empty' if ($acl->{label} eq '');
	$doneString = 'Content can not be empty' if ($#items == -1);
	if ($doneString eq '')
	{
		$objBandWidth->saveClass($xml);
		$doneString = "Data is saved successfully";
		keepHistory("$title:\n".Dumper($xml));
		$new = '';
	}
}

print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}

function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return 0;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}


function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", getNumber()+1);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.align = "middle";
	td.innerHTML = "<a href='' onClick='delItem(this); return false' style='visibility: hidden;'><img src='/delete.gif' border=0></a>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	td.innerHTML = "<input class=control type=text name=fld_"+num+" value='' style='width: 270px;'>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	var selectStr = "<select class=control name=type_"+num+" style='width: 115px;' onchange='typeChanged(this);'><option value=''>- as is -</option>";
	if (document.forms.f1.type.selectedIndex != 2)
	{
		selectStr += "<option value='Server Name'>Server Name</option><option value='File Extention'>File Extention</option>";
	}
	selectStr += "</select>";
	td.innerHTML = selectStr;
	tr.appendChild(td);

	obj.appendChild(tr);
}


function typeChanged(tobj)
{
	var obj = document.forms.f1.type;
	if (obj.selectedIndex == 2)
	{
		var selectList = document.getElementsByTagName("SELECT");
		for (var i=0; i<selectList.length; i++)
		{
			if (selectList[i].name.indexOf("type_")>-1)
			{
				while (selectList[i].options.length > 1)
				{
					selectList[i].options[1] = null;
				}
			}
		}
	}
	else
	{
		var selectList = document.getElementsByTagName("SELECT");
		for (var i=0; i<selectList.length; i++)
		{
			if (selectList[i].name.indexOf("type_")>-1)
			{
				if (selectList[i].options.length == 1)
				{
					selectList[i].options[selectList[i].options.length] = new Option('Server Name', 'Server Name');
					selectList[i].options[selectList[i].options.length] = new Option('File Extention', 'File Extention');
				}
			}
		}
	}
}
</script>
</head>
<body>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=fl value="$class">
<input type=hidden name=new value="$new">
<input type=hidden name=max_number value="0">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF


if ($class)	{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td style="padding-top: 20px;"><a class=control href="classes.pl">Back</a></td>
    <td align=right>&nbsp;</td>
  </tr>
</tbody>
</table>
<p class=donestring>$doneString</p>
<table cellpadding=2 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td width=100>* Label:</td>
    <td><input type=text name=label value="$acl->{label}" class=control size=25></td>
  </tr>
  <tr>
    <td>Description:</td>
    <td><input type=text name=description value="$acl->{description}" class=control size=45></td>
  </tr>
  <tr>
    <td>* Class Type:</td>
    <td>
__EOF
if ($acl->{readonly} eq 'true')
{
	print $objBandWidth->getFriendlyType($acl->{type})."<input type=hidden name=type value='$acl->{type}'>";
}
else
{
	print <<__EOF;
<select name=type onchange="typeChanged(this);">
  <option value="url_regex" ${\($acl->{type} eq 'url_regex'?'selected':'')}>${\($objBandWidth->getFriendlyType('url_regex'))}
  <option value="urlpath_regex" ${\($acl->{type} eq 'urlpath_regex'?'selected':'')}>${\($objBandWidth->getFriendlyType('urlpath_regex'))}
  <option value="src" ${\($acl->{type} eq 'src'?'selected':'')}>${\($objBandWidth->getFriendlyType('src'))}
</select>
__EOF
}
print <<__EOF;
    </td>
  </tr>
  <tr>
    <td>Blocked Traffic:</td>
    <td><input type=checkbox name=blocked value="1" ${\(setChecked($acl->{blocked}, 1))} class=control></td>
  </tr>
  <tr><td colspan=2>* Conditions:</td></tr>
</tbody>
</table>
<table cellspacing=1 cellpadding=1 border=0 width=500>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th>Condition</th>
    <th width=130>Apply as</th>
  </tr>
__EOF

	my @list = $objBandWidth->parseData([split(/\n/, (ref $acl->{'content'} ne 'HASH')?$acl->{'content'}:'')]);
	if ($#list > -1)
	{
		if ($list[0]->{'fld'} =~ /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/) 
		{
			my %list;
			foreach(@list) {
				$_->{'fld'} =~ /\d{1,3}\.\d{1,3}\.\d{1,3}\.(\d{1,3})/;
				$list{$1} = $_;
			}
        
			@list = undef;
			my @sorted = sort {$a <=> $b} keys %list;
			foreach(@sorted) { push(@list, $list{$_}) }
			shift @list;
		}

		my $i = 0;
		for (@list)	{
			my $type = $_->{'type'};
			if ($acl->{readonly} eq 'false')
			{
				print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$i">
    <td align=middle><a href='' onClick='delItem(this); return false' style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td style='padding-left: 5px;'><span><a class=grid href="" onClick="openItem(this); return false;">${\(resolveIp($_->{'fld'}))}</a></span><span style="display: none;"><input class=control type=text name=fld_$i value='$_->{'fld'}' style='width: 270px;'></span></td>
    <td align=middle style='padding-left: 5px;'><span><a class=grid href="" onClick="openItem(this); return false;">$type</a></span><span style="display: none;"><select class=control name=type_$i style='width: 115px;' onchange="typeChanged(this);"><option value=""> - as is - </option><option value="Server Name" ${\($type eq 'Server Name'?'selected':'')}>Server Name</option><option value="File Extention" ${\($type eq 'File Extention'?'selected':'')}>File Extention</option></select></span></td>
  </tr>
__EOF
			}
			else
			{
				print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$i">
    <td align=middle><a href='' style="display: none;" onClick="return false;"><img src="/delete.gif" border=0></a></td>
    <td style='padding-left: 5px;'><span><a class=grid href="" onClick="return false;">${\(resolveIp($_->{'fld'}))}</a></span><span style="display: none;"><input class=control type=text name=fld_$i value='$_->{'fld'}' style='width: 270px;'></span></td>
    <td align=middle style='padding-left: 5px;'><span><a class=grid href="" onClick="return false;">$type</a></span><span style="display: none;"><select class=control name=type_$i style='width: 115px;' onchange="typeChanged(this);"><option value=""> - as is - </option><option value="Server Name" ${\($type eq 'Server Name'?'selected':'')}>Server Name</option><option value="File Extention" ${\($type eq 'File Extention'?'selected':'')}>File Extention</option></select></span></td>
  </tr>
__EOF
			}
			$i++;
		}
	}
	print <<__EOF;
</tbody>
</table>
</tbody>
</table>
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
__EOF
if ($acl->{readonly} eq 'false')
{
	print <<__EOF;
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
__EOF
}
if ($allowEdit && $acl->{readonly} eq 'false')
{
	print <<__EOF;
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
__EOF
}
print <<__EOF;
    </td>
  </tr>
</tbody>
</table>
__EOF
}

print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 220px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This page allows you to create a class that contains conditions applied for http traffic restriction.
"Label" and "Description" are any friendly info. "Class Type" defines what http request info needs checking against the conditions:
<li>Request URI is part of url strings
<li>Name is the same server names
<li>Address is the list of ip addresses
<br><br>
And each condition has a type that defines how it must be applied.
<li>"as is" is used as is (192.168.1.1)
<li>"File extension" is used as file extension (zip)
<li>"Server Name" is used as resource server name (google.com)
<br><br>
If a class is blocked, no http traffic is allowed.
</div>


</body>
</html>
__EOF


sub getNewACL
{
	return {
		'name' => ${\($_[0] eq ''?&getRandomString(15):$_[0])},
		'content' => '',
		'description' => '',
		'label' => '',
		'type' => '',
		'readonly' => 'false'
	};
}



sub addNewACL
{
	my ($class, $xml) = @_;
	if (exists($xml->{acl}->{name}))
	{
		my $name = $xml->{acl}->{name};
		my $h;
		$h->{$_} = $xml->{acl}->{$_} for (keys %{$xml->{acl}});
		$xml->{acl}->{$name} = $h;
		for (keys %{$xml->{acl}})
		{
			delete $xml->{acl}->{$_} if ($_ ne $name);
		}
	}
	my $new = getNewACL($class);
	$xml->{acl}->{$new->{name}} = $new;
	return $new->{name};
}


sub resolveIp
{
	my $ip = shift;
	if (exists $ip_hash->{$ip} && $ip_hash->{$ip})
	{
		return "<div style='width: 90px; float: left;'>$ip</div>( $ip_hash->{$ip} )";
	}
	return $ip;
}
