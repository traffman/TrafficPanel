#!/usr/bin/perl

# display users total traffic based on iptables for spcified time and total per user/time

BEGIN   
{
  (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
  unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use TrafficLogging;
use Time::Local;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

my $co = new CGI;
my $stream = $co->param("stream");
my $inf = $co->param("inf");
my $dtstart = $co->param("dtstart");
my $dtend = $co->param("dtend");

my $trafficLogging = TrafficLogging->new();
my $interfaces = $trafficLogging->get_ext_interfaces();

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<script src="/comparators.js"></script>
<script src="/sorting.js"></script>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<head>
<style>
img.sort
{
	cursor: pointer;
}
td.sort
{
	padding-left: 0px;
}

</style>
<script>
var img_calendar_src = '/cal_control.gif';
var img_prev_src = '/cal_arrow_left.gif';
var img_next_src = '/cal_arrow_right.gif';
var img_close_src = '/cal_close.gif';
</script>
  <link href="/calendar.css" rel=stylesheet type=text/css>
  <script language="javascript" src="/calendar.js"></script>
</head>
<body onload="sortTable( true, 2, 1, 'report_table', ipCmpr);">
<table cellspacing=1 cellpadding=1 width=700>
  <tr>
    <td class=titlepage>Total amount tcp traffic per ip</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</table>

__EOF

my %monthN = ();
for (my $i=0; $i<=$#short_months; $i++)
{
	$monthN{$short_months[$i]} = sprintf("%02s",$i+1);
}

my $report_file = $trafficLogging->get_report_filename();
if (!$dtend && $report_file =~ /(\d{4})(\d\d)(\d\d)/)
{
	$dtstart = "$1$2$3";
	$dtend = $dtstart;
}
else	
{
	$dtstart =~ s/\-(\w\w\w)\-/$monthN{$1}/;
	$dtend =~ s/\-(\w\w\w)\-/$monthN{$1}/;
	$report_file =~ s/\d{8}/$dtend/;
}
my $repArray = $trafficLogging->populate_report($dtstart, $dtend, $report_file);

my @showM = @{$trafficLogging->get_items_list()};
$@ && toErrorLog("Incorrect log items list. Format: '($cm{log_items_list})'") && die("Incorrect log items list. Format: '($cm{log_items_list})'");

$dtstart =~ s/(\d{4})(\d\d)(\d\d)/$1-$short_months[$2-1]-$3/;
$dtend =~ s/(\d{4})(\d\d)(\d\d)/$1-$short_months[$2-1]-$3/;
my $mtime = $trafficLogging->get_report_file_mtime($report_file);
my $roundation_string = 'Traffic roundation is: '.'<b>'.uc($cm{total_width}).'b.'.'</b>';

print <<__EOF;
<br>&nbsp;&nbsp;&nbsp;Transit traffic (last update $mtime):<br>
<br>
<div id="popupcalendar" class=popupcalendar>&nbsp;</div>
<table cellpadding=0 cellspacing=0 border=0>
<form name=f1 action="" method=post>
  <tr>
    <td>\&nbsp;\&nbsp;Stream:</td>
    <td>\&nbsp;<select name=stream class=control>
        <option value="" >All
        <option value="in" ${\setSelected($stream,'in')}>Incomming
        <option value="out" ${\setSelected($stream,'out')}>Outgoing
      </select>
    </td>
    <td>\&nbsp;\&nbsp;Interface:</td>
    <td>\&nbsp;<select name=inf class=control>
        <option value="" >All
__EOF

for (@$interfaces)
{
	print "        <option value='$_->[0]' ${\setSelected($inf,$_->[0])}>$_->[1]";
}

print <<__EOF;
      </select>
    </td>
    <td>\&nbsp;\&nbsp;Date Start:\&nbsp;<input type=text name=dtstart value="$dtstart" maxlength=10 class=control style='width: 100px;' onclick="showCalendar('f1','dtstart','dtstart',0,20,4); return false;"></td>
    <td>\&nbsp;\&nbsp;Date End:\&nbsp;<input type=text name=dtend value="$dtend" maxlength=10 class=control style='width: 100px;' onclick="showCalendar('f1','dtend','dtend',0,20,4); return false;"></td>
    <td width=100 colspan=2 align=right><input type=submit name=submit value="Show" class=control></td>
  </tr>
</form>
</table>
<br>
<div style="padding-left: 10px;">$roundation_string</div>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=500>
<tr bgcolor=#dddddd>
    <td>
<table  id="report_table" cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody id="report_table_body">
  <tr >
    <th width="200px" >
    <table><tr><td>
    <b>Name</b>    </td><td class="sort">
<table cellpadding=0 cellspacing=0 border=0 width=1>
  <tr>
    <td><img onclick="sortTable( true, 0, 1, 'report_table', strCmpr);" src="/sort-up.gif" border="0" alt="sortUp" title="sortUp" width="16" height="16" class="sort"></td>
    <td><img onclick="sortTable( false, 0, 1, 'report_table', strCmpr);" src="/sort-down.gif" border="0" alt="sortDown" title="sortDown" width="16" height="16" class="sort"></td>
  </tr>
</table>
</td></tr></table>
    </th>
    <th width="90px" >
        <table><tr><td>
    <b>IP</b>    </td><td class="sort">
<table cellpadding=0 cellspacing=0 border=0 width=1>
  <tr>
    <td><img onclick="sortTable( true, 1, 1, 'report_table', ipCmpr);" src="/sort-up.gif" border="0" alt="sortUp" title="sortUp" width="16" height="16" class="sort"></td>
    <td><img onclick="sortTable( false, 1, 1, 'report_table', ipCmpr);" src="/sort-down.gif" border="0" alt="sortDown" title="sortDown" width="16" height="16" class="sort"></td>
</tr>
</table>  </td></tr></table>
   
    </th>

__EOF

my $item;
for ($item=0; $item<=$#showM; $item++)
{
	print <<__EOF;
<th width="90px">
        <table><tr><td nowrap>
last ${\($showM[$item]+1)} min </td><td class="sort">
<table cellpadding=0 cellspacing=0 border=0 width=1>
  <tr>
    <td><img onclick="sortTable( true, ${\($item+2)}, 1, 'report_table', ipCmpr);" src="/sort-up.gif" border="0" alt="sortUp" title="sortUp" width="16" height="16" class="sort"></td>
    <td><img onclick="sortTable( false, ${\($item+2)}, 1, 'report_table', ipCmpr);" src="/sort-down.gif" border="0" alt="sortDown" title="sortDown" width="16" height="16" class="sort"></td>
  </tr>
</table>
</td></tr></table>

</th>
__EOF
}
	print <<__EOF;
    <th  width="90px" >
<table><tr><td><b>Today&nbsp;</b> </td><td class="sort">
<table cellpadding=0 cellspacing=0 border=0 width=1>
  <tr>
    <td><img onclick="sortTable( true, ${\($item+2)}, 1, 'report_table', ipCmpr);" src="/sort-up.gif" border="0" alt="sortUp" title="sortUp" width="16" height="16" class="sort"></td>
    <td><img onclick="sortTable( false, ${\($item+2)}, 1, 'report_table', ipCmpr);" src="/sort-down.gif" border="0" alt="sortDown" title="sortDown" width="16" height="16" class="sort"></td>
  </tr>
</table> </td></tr></table>
</th>
</tr>
__EOF

my $ip_list = &getIPs;
my $ips = get_ip_name_hash($ip_list);
my $xml = readModuleConfigFile($cm{tcp_limit});

my (@blockedlist, %specific_limits, %isblocked);

my $areas = $xml->{'pc'};
if (ref $areas eq 'HASH')
{
    $specific_limits{$areas->{ip}} = $areas->{size}
}
else
{
    foreach (@$areas)
    {
        $specific_limits{$_->{ip}} = $_->{size}
    }
}

for (@$ip_list) {

    unless ($_->{enabled}) {

        my $total = $trafficLogging->traffic_count(0, $interfaces, $_->{ip}, '');

        $total = getHumanTrafficNumber($total, 'm');

        next if $total < 0.1;

        my $item = $_->{ip}.'|'.$total;

        if (exists($specific_limits{$_->{ip}})) {
            if ($total >= $specific_limits{$_->{ip}}) {
                $item .= '|'.$specific_limits{$_->{ip}};
                push(@blockedlist, $item);
            }
        }
        else {
            if ($total >= $cm{default_size}) {
                $item .= '|'.$cm{default_size};
                push(@blockedlist, $item);
            }
        }

    }

}

foreach (@blockedlist)
{
	/(.+)\|([\d\.]+)\|([\d\.]+)/;
	$isblocked{$1} = '1';
}

push @showM, 'Total'; # tricky, -2 == Total

my %total = ();
$total{$_} = 0 for (@showM);

my $interfaceList = $inf?[[$inf,'']]:$interfaces;

for my $ip (keys %$ips)
{
	my $bg = $isblocked{$ip} eq 1?"f5f5f5":"ffffff";
	my $s = <<__EOF;
	<tr style="background:#$bg;">
    <td>$ips->{$ip}</td>
    <td>$ip</td>
__EOF

	my $showLine = $cm{show_zero_result};
	my $count;

	for my $item (@showM)
	{
		my $index = $item eq 'Total'?0:$item+2;
		$count = $trafficLogging->traffic_count($index, $interfaceList, $ip, $stream);
		$total{$item} += $count;
		$showLine ||= $count;
		$s .= "<td align=right>${\(getHumanTrafficNumber($count, $cm{total_width}))}&nbsp;</td>\n";
	} 
	$s .= "  </tr>\n";
	print $s if $showLine;
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>

<table border=0 cellspacing=2 >
<tbody>
  <tr>
    <td width="200px">&nbsp;&nbsp;&nbsp;&nbsp;<b>Total</b></td>
    <td width="90px">&nbsp;</td>
__EOF

for (sort keys %total)
{
	print "<td width='90px' align=right><b>${\(getHumanTrafficNumber($total{$_}, $cm{total_width}))}</b>&nbsp;</td>\n";
}

print <<__EOF;
  </tr>
  </tbody>
</table>

<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see current and daily total tcp traffic amount per local ip. For old days you can see total amount only. 
Blocked ip has grey background row color. Blocked ip can be unblocked with increasing tcp available traffic amount. 
</div>


</body>
</html>
__EOF

__END__
