#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use File::Copy;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
#my $allowEdit = &hasManagerAccess;
my $co = new CGI;
my $is_mac_enabled = 1;

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<script>
function formValidate(p1)
{
	var f = document.forms.f1;
	f.todo.value = p1;
	f.submit();
	return false;
}


function addItem()
{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	tr.height = 22;
	var dt = '&&temp&&.'+Date.parse(new Date);
	document.getElementById("added").value += dt + "|";
	tr.id = 'tr_'+dt;
	tr.onmouseover = function() {ovrMouse(this)};
	tr.onmouseout = function() {outMouse(this)};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.textAlign = "center";
	td.innerHTML = '<a href="" class=grid onClick="deleteItem(this); return false;" style="visibility: hidden;"><img src="/delete.gif" border=0></a>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control type=checkbox name='+dt+'_used value="1" checked>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_ip value="" size=15 maxlength=15>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_nick value="" size=16 maxlength=50>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_name value="" size=28 maxlength=50>';
	tr.appendChild(td);
__EOF
if ($is_mac_enabled)
{
	print <<__EOF;
	var td = document.createElement("TD");
	td.style.paddingLeft = "5px";
	td.innerHTML = '<input class=control type=text name='+dt+'_mac value="" size=18 maxlength=30>';
	tr.appendChild(td);
__EOF
}
print <<__EOF;
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control type=checkbox name='+dt+'_enabled value="1">';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control type=checkbox name='+dt+'_nightly value="1">';
	tr.appendChild(td);

	obj.appendChild(tr);
}


function removeRow(thisRow)
{
    thisRow.parentNode.removeChild(thisRow,true);
}


function deleteItem(obj, p1)	
{
	var deletedObj = document.getElementById("deleted");
	var idObj = document.getElementById("s1_"+p1+"_id");
	if (deletedObj.value.indexOf(idObj.text + "|") == -1)
   		deletedObj.value += idObj.text + "|";
	removeRow(obj.parentNode.parentNode);
}


function openItem(p1)
{
	var changedObj = document.getElementById("changed");
	var idObj = document.getElementById("s1_"+p1+"_id");
	if (changedObj.value.indexOf(idObj.text + "|") == -1)
   		changedObj.value += (idObj.text||idObj.innerText) + "|";
	document.getElementById("s2_"+p1+"_used") .style.display = "inline";
	document.getElementById("s1_"+p1+"_nick") .style.display = "none";
	document.getElementById("s2_"+p1+"_nick") .style.display = "inline";
	document.getElementById("s1_"+p1+"_ip") .style.display = "none";
	document.getElementById("s2_"+p1+"_ip") .style.display = "inline";
	document.getElementById("s1_"+p1+"_name") .style.display = "none";
	document.getElementById("s2_"+p1+"_name") .style.display = "inline";
__EOF
if ($is_mac_enabled)
{
	print <<__EOF;
	document.getElementById("s1_"+p1+"_mac") .style.display = "none";
	document.getElementById("s2_"+p1+"_mac") .style.display = "inline";
__EOF
}

print  <<__EOF; 
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
__EOF
my $doneString = "";
my $xml = readConfigFile($ck{scfolder}.$ck{_ip_list});
if ($allowEdit && $co->param("todo"))
{
	backupUserConfigFiles($ck{scfolder}.$ck{_ip_list});
	my $items = $xml->{items}->{item};
	$items = [$items] if (ref $items eq 'HASH');

	foreach (@$items)
	{
		$_ = get_item($co, $_->{ip}."_ident") if ($co->param("changed") =~ /$_->{ip}\|/);
	}

	$_ = $co->param("added");
	push @$items, get_item($co, $1) while (/(.+?)\|/g);

	for (my $i=0; $i<=$#$items; $i++)
	{    
		splice(@$items, $i--,1) if ($co->param("deleted") =~ /$items->[$i]->{ip}\|/);
	}

	for (my $i=0; $i<=$#$items; $i++)
	{
		$doneString .= validate($items->[$i]);
	}

	$xml->{items}->{item} = $items;

	if (!$doneString)
	{
		saveConfigFile($ck{scfolder}.$ck{_ip_list}, $xml);
		if ($co->param("todo") eq 'apply')
		{
			run_twm_script("$ck{_ip_list_saver} a");
		}
		$doneString = "Data are saved. ".getWebDebugLog();
	}
	$doneString =~ s/\n/<br>/g;
}
        
print <<__EOF;
<input type=hidden name=added id=added value="">
<input type=hidden name=changed id=changed value="">
<input type=hidden name=deleted id=deleted value="">
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=760>
<tbody>
  <tr>
    <td class=titlepage>IP configuration</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$doneString</small></p>
<table cellspacing=0 cellpadding=0 width=820>
  <tr class=tableborder>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=50>Used</th>
    <th width=108>IP Address</th>
    <th width=120>Host Name</th>
    <th width=200>User Full Name</th>
__EOF
if ($is_mac_enabled)
{
	print <<__EOF;
    <th width=130>MAC Address</th>
__EOF
}
	print <<__EOF;
	<th>Enabled</th>
	<th>Nightly</th>
	</tr>
__EOF
my $ips = &getIPs;
foreach (@$ips)
{
	my ($used, $nick, $ip, $name, $mac, $enabled, $nightly) = ($_->{used}, $_->{dns_name}, $_->{ip}, $_->{full_name}, $_->{mac}, $_->{enabled}, $_->{nightly});
	(my $pr = $ip.'_ident');# =~ s/\./_/g;
	my $checkedUsed = $used eq 1?"checked":"";
	print <<__EOF;
  <tr height=22 id=tr_$pr onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff>
    <td width=10 align=middle><a href="" onClick="deleteItem(this,'$pr'); return false;" style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td nowrap align=middle><span id="s1_${pr}_used"><input name="${pr}_used" value="1" onClick="openItem('$pr');" type=checkbox $checkedUsed /></a></span><span id="s2_${pr}_used" style="display: none;"></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_ip"><a href="" id="s1_${pr}_id"  class=grid onClick="openItem('$pr'); return false;">$ip</a></span><span id="s2_${pr}_ip" style="display: none;"><input class=control type=text name=${pr}_ip id=${pr}_ip value="$ip" size=15 maxlength=15></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_nick"><a href="" class=grid onClick="openItem('$pr'); return false;">$nick</a></span><span id="s2_${pr}_nick" style="display: none;"><input class=control type=text name=${pr}_nick value="$nick" size=16 maxlength=50></span></td>
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_name"><a href="" class=grid onClick="openItem('$pr'); return false;">$name</a></span><span id="s2_${pr}_name" style="display: none;"><input class=control type=text name=${pr}_name value="$name" size=28 maxlength=50></span></td>
__EOF
	if ($is_mac_enabled)
	{
		print <<__EOF;
    <td nowrap style='padding-left: 5px;'><span id="s1_${pr}_mac"><a href="" class=grid onClick="openItem('$pr'); return false;">$mac</a></span><span id="s2_${pr}_mac" style="display: none;"><input class=control type=text name=${pr}_mac value="$mac" size=18 maxlength=50></span></td>
__EOF
	}
	else
	{
		print <<__EOF;
    <input type=hidden name=${pr}_mac value="$mac">
__EOF
	}
my $checked = $enabled eq 1?"checked":"";
my $chnightly = $nightly eq 1?"checked":"";
print <<__EOF; 
<td align=middle><input name="${pr}_enabled" value="1" onClick="openItem('$pr');" type=checkbox $checked /></td>
<td align=middle><input name="${pr}_nightly" value="1" onClick="openItem('$pr');" type=checkbox $chnightly /></td>
</tr>
__EOF


	if (!$is_mac_enabled)
	{
		print <<__EOF;
<input type=hidden name=${pr}_mac value="$mac">
__EOF
	}
}
print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</tbody>
</table>
<input type=hidden name=todo value="">
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
      <span style="width: 8px;">&nbsp;</span>
<!--      <input class=control type=button value=Save onClick="formValidate('save');">
      <span style="width: 8px;">&nbsp;</span> -->
      <input class=control type=button value=Apply onClick="formValidate('apply');">
    </td>
  </tr>
</tbody>
</table>
__EOF
}
	print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>
<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
TrafficPanel requires each local network host has static ip address used to control access to internet and 
configure DNS server. This page provides friendly interface to configure local network ip addresses. 
Not "Used" ip address will be ignored with TWM, not "Enabled" ip address will have disabled
access to internet. If "Mac filtering" module is enabled then you will see extra column "MAC Address".
Read "Mac filtering" help for more info on it. 
<br>
Applying made changes will restart some TrafficPanel processes and can take few seconds.
</div>
</body>
</html>
__EOF


sub get_item
{
	my %item;
	$item{used} = $_[0]->param($_[1]."_used")?1:0;
	$item{ip} = $_[0]->param($_[1]."_ip") || '';
	$item{dns_name} = $_[0]->param($_[1]."_nick") || '';
	$item{full_name} = $_[0]->param($_[1]."_name") || '';
	$item{mac} = $_[0]->param($_[1]."_mac") || '';
	$item{enabled} = $_[0]->param($_[1]."_enabled")?1:0;
	$item{nightly} = $_[0]->param($_[1]."_nightly")?1:0;
	$item{project} = $_[0]->param($_[1]."_project") || '';
	$item{room} = $_[0]->param($_[1]."_room") || '';
	return \%item;
}



sub validate_dns_name
{
	return $_[0]->{dns_name} !~ /^[a-zA-Z0-9\-]+$/ && "Incorrect Domain Name '$_[0]->{dns_name}'\n";
}

sub validate
{
	return 
		validate_dns_name($_[0])
		|| "";
}

__END__
