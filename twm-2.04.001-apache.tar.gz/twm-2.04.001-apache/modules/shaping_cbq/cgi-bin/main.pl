#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use File::Copy;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

print "Content-Type: text/html\n\n";
my $allowEdit = &hasAdminAccess;
my $co = new CGI;
print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<form>
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF
my ($resultString, $action, $state) = ('', undef, '');
if ($allowEdit)
{
	$action = $co->param("action");
	if ($action =~ /start|compile|stop|restart|timecheck|list|stats/)
	{
		$resultString = join("<br>", run_twm_script("$cm{cbq_script} $action", $mc));
	}
	elsif ($action)
	{
		$resultString = "Incorrect action";
	}
}
else
{
	$resultString = "You do not have required permissions!";
}
if ($action ne 'stats')
{
	$state = join("<br>",run_twm_script("$cm{cbq_script} stats", $mc));
	$state = ($state =~ /traffic classes/ && $state =~ /filtering rules/)?'Shaping is up':'Shaping is down';
}
print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=100%>
<tbody>
  <tr>
    <td><span class=titlepage>Shaper Manager</span></td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td><b>$state</b><br><br></td></tr>
__EOF
if ($allowEdit)
{
	print <<__EOF;
  <tr>
    <td>
      <select name=action class=control>
        <option value="">
        <option value="start" ${\setSelected($action, 'start')}>Start
        <option value="compile" ${\setSelected($action, 'compile')}>Compile
        <option value="stop" ${\setSelected($action, 'stop')}>Stop
        <option value="restart" ${\setSelected($action, 'restart')}>Restart
        <option value="timecheck" ${\setSelected($action, 'timecheck')}>Check
        <option value="list" ${\setSelected($action, 'list')}>List
        <option value="stats" ${\setSelected($action, 'stats')}>State
      </select>
    </td>
    <td style="padding-left: 20px;">
      <input class=control type=submit name="todo" value=Get>
    </td>
  </tr>
__EOF
}
print <<__EOF;
</tbody>
</table>
<p>$resultString</p>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Shaper management page provides gui to excetute availbale actions:
<li>Start - start shaping based on compiled configuration file. Modifications made with gui are compiled automatic.
<li>Compile - compile configuration file
<li>Stop - stop shaping
<li>Restart - restart shaping
<li>Check - check shaping state up/down
<li>List - get compiled rules
<li>Stats - get shaping state
</div>


</body>
</html>
__EOF

