#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}


# this script used to set total http traffic restriction
# after total amount is set then script sends SIGUSR1 to httpr_sl daemon
use strict;
use CGI;
use TWM;
use IPLimit;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
print "Content-Type: text/xml\n\n";

my $ip = $co->param("ip")||'';
my ($status, $message) = ('')x2;
if ($allowEdit)
{
	if ($ip) 
	{
		overwriteFile("$ck{twmfolder}/modules/$mc/logs/$cm{reset_ip}", $ip);
		keepHistory("Reset http traffic of $ip");
		($status, $message) = ('true', '');
		run_twm_script("$cm{daemon} clear", $mc);
	}
	else
	{
		($status, $message) = ('false', 'IP is not defined');
	}
}
else
{
	($status, $message) = ('false', 'You do not have required permissions');
}


print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
