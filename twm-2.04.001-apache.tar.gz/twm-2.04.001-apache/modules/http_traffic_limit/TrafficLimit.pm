package TrafficLimit;

require 5;

BEGIN	
{
	use TWM;
	use Data::Dumper;
}

sub new
{
	my $self = {
		this_module_code => 'http_traffic_limit'
	};
	return bless $self;
}

sub DESTROY	{
	my $self = shift;
	delete $self->{$_} for (keys %$self);
	undef(%$self);
	undef $self;
}


##################################################
# Returns ordered list of squidGuard db folders
##################################################
sub get_dest_list
{
	return sort {$a eq $b} map 
		{
			$_ = '' if (! -d $_);
			s/$cm{db_dir}\///g; 
			$_;
		} <$cm{db_dir}/*>;
}

##################################################
# Converts pool xml to sorted array
##################################################
sub convertPool2Array
{
	my ($self, $item) = (shift, shift);
	my @items;
	if (ref $item->{pool} eq 'HASH')
	{
		if (exists($item->{pool}->{name}))
		{
			push @items, $item->{pool};
		}
		else
		{
			for (keys %{$item->{pool}})
			{
				$item->{pool}->{$_}->{name} = $_;
				push @items, $item->{pool}->{$_};
			}
		}
	}
	return sort {$a->{order} <=> $b->{order}} @items;
}


return 1;
END {}
