#!/usr/bin/perl -w

BEGIN
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(shaping_cbq\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
}

use strict;
use TWM;
use Data::Dumper;

my $host = $ARGV[0];

exit unless ($host);

print <<__EOF;
fullrow=0

  <div class="paneltitle"><span class="paneltitlerow">TCP Shaping</span></div>
  <div class="panelcontent">
    <div class="panelcontentrow">
__EOF

my $xml = &readModuleConfigFile($cm{cbq_conf});
my $cbqlist = $xml->{item};

my %cbqlist_sorted;
if (ref $cbqlist eq 'HASH') {
    $cbqlist = copyHash($cbqlist) if (exists($cbqlist->{'class_rate_speed'}));
	foreach(keys(%$cbqlist)) {
        $cbqlist_sorted{$cbqlist->{$_}{'id'}} = $cbqlist->{$_};
        $cbqlist_sorted{$cbqlist->{$_}{'id'}}{'class_name'} = $_;
		$cbqlist_sorted{$cbqlist->{$_}{'id'}}{'rule'} = $cbqlist->{$_}{'ip'} =~ /([^,]+),/?$1:'any';
		$cbqlist_sorted{$cbqlist->{$_}{'id'}}{'rule'} =~ s/(:\d{2,3})/\*$1/;
	}
}

my $network_info = &getNetworkInfo;
foreach(sort(keys(%cbqlist_sorted))) {

	if ($cbqlist_sorted{$_}{'ip'} =~ /^:\d{1,4},\b$host\b/) {
		print_class();
	}
    elsif ($cbqlist_sorted{$_}{'ip'} =~ /^:\d{1,4},$network_info->{network}.+/) {
		print_class();
    }
    elsif ($cbqlist_sorted{$_}{'ip'} =~ /,?\b$host\b/) {
		print_class();
		last;
    }
	elsif ($cbqlist_sorted{$_}{'ip'} =~ /^$network_info->{network}.+/) {
		print_class();
    }

}

sub print_class {
	print_row($cbqlist_sorted{$_}{'class_rate_speed'}.' '.$cbqlist_sorted{$_}{'class_rate_dim'}, $cbqlist_sorted{$_}{'class_name'}, $cbqlist_sorted{$_}{'device'}, $cbqlist_sorted{$_}{'rule'});
}

print <<__EOF;
</div>
  </div>
__EOF

sub print_row
{
	my ($speed,$class,$intf,$rule) = (shift, shift, shift, shift);
    print <<__EOF;
<div>Class name: $class</div>
<div>Traffic from: $rule</div>
<div>Max speed: $speed</div>
<div>Interface: $intf</div><br>
__EOF
}

__END__
