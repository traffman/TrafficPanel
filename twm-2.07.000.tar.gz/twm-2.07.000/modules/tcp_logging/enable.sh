#!/bin/sh

echo "ok"
#echo "some bug: $1 "

