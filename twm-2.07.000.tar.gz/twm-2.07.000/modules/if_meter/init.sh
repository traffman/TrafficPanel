#!/bin/bash

traff_meter=$TWMFOLDER/modules/if_meter/traff_meter

set -e

case $1 in
start)
	if [ -e $traff_meter ]; then
		$traff_meter start
	else
		echo "Could not find file: $traff_meter"
	fi
        ;;
stop)
	if [ -e "$traff_meter" ]; then
		$traff_meter stop
	else
		echo "Could not find file: $traff_meter"
	fi
        ;;
reconf)
	if [ -e "$traff_meter" ]; then
#		$traff_meter restart
# need run as daemon to avoid apache wait finishing $traff_meter process. or need use bin/forker
#		$traff_meter restart 2>&1 >/dev/null &
		$TWMFOLDER/bin/forker $TWMFOLDER $traff_meter restart
	else
		echo "Could not find file: $traff_meter"
	fi
        ;;
restart)
	if [ -e "$traff_meter" ]; then
		$traff_meter restart
	else
		echo "Could not find file: $traff_meter"
	fi
        ;;
*)
	N=/etc/init.d/$NAME
	echo "Usage: $N {start|stop|restart|reconf}" >&2
	exit 1
	;;
esac

exit 0

