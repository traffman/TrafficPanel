#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
&checkAuthorization;

print "Content-Type: text/html\n\n";
my @protos = ('tcp','udp');
my $proto_str = join('|', @protos);
my $allowEdit = &hasAdminAccess;

my $isp_list = &getISP;
my $ips = get_ip_name_hash(&getIPs);

my $co = new CGI;
my $doneString = "";

if ($allowEdit && defined $co->param("max_number"))
{
	my (%ips);
	my $max_number = $co->param("max_number") || 0;
	for (my $i=0; $i<=$max_number; $i++)
	{
		if (
			defined $co->param("host_ip_$i")
		)
		{
			my $host_ip = $co->param("host_ip_$i");
			my $gw_interface = $co->param("gw_interface_$i");
			my $remote_ip = $co->param("remote_ip_$i");
			my $decsription = $co->param("description_$i");
			$doneString .= "<br> Incorrect ip: $remote_ip" if ($remote_ip && $remote_ip !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
			$doneString .= "<br> Incorrect ip: $host_ip" if ($host_ip !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
			if ($doneString eq '' && exists($ips{"$host_ip"}))	
			{
				$doneString .= "<br>Duplicate: $host_ip. Ignore second data.";
			}
			else	
			{
				$ips{"$host_ip"} = [$host_ip, $gw_interface, $remote_ip, $decsription];
			}
		}
	}
	if (!$doneString)
	{
		runModuleMasq("D");
		my $xml;
		for (keys %ips)
		{
			push @{$xml->{rule}}, getNewItem($ips{$_});
		}
		saveModuleConfigFile($cm{ports}, $xml);
		runModuleMasq("A");
		$doneString = "Data are saved.";
	}
}

print <<__EOF;
<html>
<head>
<title>Close ports config page</title>
<script src="$ck{include_dir}twm.js"></script>
<link href="$ck{include_dir}twm.css" rel=stylesheet type=text/css>
</head>
<body>
<script>
function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return -1;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}

function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}

function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";

	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<a href="" class=grid onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control style="width: 100px;" type=text name=host_ip_'+num+' value="" maxlength=15>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	var s = '<select class=control name=gw_interface_'+num+'><option value=""> -- Any -- </option>';
__EOF
for (keys %$isp_list)
{
	!$isp_list->{$_}->{attributes}->{internal} && print "s += '<option value=$isp_list->{$_}->{inf}>$isp_list->{$_}->{code}</option>';\n";
}
print <<__EOF;
	s += '</select>';
	td.innerHTML = s;
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<input class=control style="width: 100px;" type=text name=remote_ip_'+num+' value="" >';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = '10px';
	td.innerHTML = '<input class=control style="width: 200px;" type=text name=description_'+num+' value="">';
	tr.appendChild(td);
	obj.appendChild(tr);
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=max_number value="0">
<table cellpadding=0 cellspacing=0 border=0 width=400>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td class=titlepage>${\(&getModuleInfo->{name})}</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td width=100%>
<p><small>$doneString</small></p>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=24>
    <th width=20></th>
    <th width=100>Host IP</th>
    <th width=170>User Name</th>
    <th width=100>ISP</th>
    <th width=100>Remote IP</th>
    <th width=240>Description</th>
  </tr>
__EOF

my $i = 0;
my $xml = readModuleConfigFile($cm{ports});
if (ref $xml->{rule} eq 'HASH')
{
	printRow($xml->{rule}, $i);
}
else
{
	for (@{$xml->{rule}})
	{
		printRow($_, $i);
		$i++;
	}
}
print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
__EOF

if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value="Save">
    </td>
  </tr>
</tbody>
</table>
__EOF
}

print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 220px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This module maps your proxy server port number of external interface to local network host port number.
That allows you get access to local network host from internet using specified port number.
</div>

</body>
</html>
__EOF

sub printRow
{
	my $desc = ref $_[0]->{description} eq 'HASH'?'':$_[0]->{description};
	my $name = $ips->{$_[0]->{host_ip}};
	my $remote_ip = ref $_[0]->{remote_ip} eq 'HASH'?'':$_[0]->{remote_ip};
	my $gw_interface = ref $_[0]->{gw_interface} eq 'HASH'?' -- Any -- ':getISPbyinf($_[0]->{gw_interface});
	print <<__EOF;
<tr height=24 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[1]"><td
 align=center><a href="" onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{host_ip}</a></span><span style="display: none;"><input class=control style='width: 100px; text-align: right;' type=text name=host_ip_$_[1] value='$_[0]->{host_ip}'></span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$name</a></span><span style="display: none;">$name</span></td><td
 align=center><span><a href="" class=grid onClick="openItem(this); return false;">$gw_interface</a></span><span style="display: none;"><select
 name=gw_interface_$_[1] class=control><option value=''> -- Any -- </option>
__EOF
for (keys %$isp_list)
{
	!$isp_list->{$_}->{attributes}->{internal} && print "<option value=$isp_list->{$_}->{inf} ${\($_[0]->{gw_interface} eq $isp_list->{$_}->{inf}?'selected':'')}>$isp_list->{$_}->{code}</option>';\n";
}
	print <<__EOF;
</select></span></td><td
 align=right style="padding-right: 10px;"><span><a href="" class=grid onClick="openItem(this); return false;">$remote_ip</a></span><span style="display: none;"><input class=control style='width: 100px; text-align: right;' type=text name=remote_ip_$_[1] value='$remote_ip'></span></td><td
 style='padding-left: 5px;'><span><a href="" class=grid onClick="openItem(this); return false;">$desc</a></span><span style="display: none;"><input class=control style='width: 230px;' type=text name=description_$_[1] value='$desc'></span></td
></tr>
__EOF
}


sub getNewItem
{
	return {
		'host_ip' => $_[0]->[0],
		'gw_interface' => $_[0]->[1],
		'remote_ip' => $_[0]->[2],
		'decsription' => $_[0]->[3]
	};
}

sub getISPbyinf
{
	my $inf = shift;
	for (keys %$isp_list)
	{
		return $isp_list->{$_}->{code} if ($isp_list->{$_}->{inf} eq $inf);
	}
	return '';
}

__END__
