#!/bin/bash

dname=$1
if [ "$2" == "2" ]; then
    is_apache2=1
else
    is_apache2=0
fi
whereis='whereis'
gawk='gawk'
grep='grep'


############################################################
# BEGIN EDIT SECTION
VHOST_PORT_DEFAULT='8080'
VHOST_CONFIG_NAME='TWM-virtual-host.conf'
if [ $is_apache2 == 1 ]; then
    APACHE_VHOSTS_CONFIG_DIR='/etc/apache2/conf.d'
    if [ -e '/etc/apache2/ports.conf' ]; then
   	 LISTEN_CONF='/etc/apache2/ports.conf'
    else
   	 LISTEN_CONF='/etc/apache2/listen.conf'
    fi
else
    APACHE_VHOSTS_CONFIG_DIR='/etc/httpd/conf'
    LISTEN_CONF='/etc/httpd/conf/httpd.conf'
fi
# END EDIT SECTION
############################################################


############################################################
# Unix system utils.
############################################################
res=''
function get_tool()
{
    	res=''
	util=$1

    	for item in `$whereis -b $1`; do
            	if [ `echo "$item" | $grep -Ec ".+/$1$"` == "1" ]; then
                    	res=$item
                    	break
            	fi
    	done;

    	function print_err() {
            	echo ""
            	echo -e '\E[31m'"\033[1mError: \033[0m \033[1m$util\033[0m util has not been found.";
            	echo "Installation aborted."
            	echo -e "Please install \033[1m$util\033[0m and run installation again installation again."
            	exit 1
    	}

    	if [ ! -n "$res" ]; then
            	print_err
    	elif [ -n "$res" ] && [ ! -x "$res" ]; then
            	print_err
    	fi
}

function port_choice () {
    	echo -n "Please enter another port number: "
   	 read VHOST_PORT_DEFAULT
   	 if [ ! $VHOST_PORT_DEFAULT ]; then
            	port_choice
    	fi
}

function port_check () {
    	PortInUse=`$netstat -an|$grep -E '^tcp.+LISTEN'|$grep -c ":$VHOST_PORT_DEFAULT "`
    	if [ $PortInUse != '0' ]; then
            	echo "Port $VHOST_PORT_DEFAULT is already in use."
            	port_choice
            	port_check
    	fi
}

function listenConf_choice () {
    if [ $is_apache2 == 1 ]; then
   	 echo -n "Please enter apache 'listen.conf [ports.conf]' file location: "
    else
   	 echo -n "Please enter apache 'httpd.conf' file location: "
    fi
    read LISTEN_CONF
    if [ ! $LISTEN_CONF ]; then
   	 listenConf_choice
    fi
}
function editVhostTempl ()
{
    declare -a contents

    num=`$cat ./apache_templates/$1|$wc -l`
    for ((i=1; i<=$num; i++));
    do
   	 contents[$i-1]=`$sed -n "${i}p; ${i}q" ./apache_templates/$1`
    done

    if [ -e "./apache_templates/$VHOST_CONFIG_NAME" ]; then
   	 $rm "./apache_templates/$VHOST_CONFIG_NAME"
    fi

    for element in $($seq 0 $((${#contents[@]} - 1)))
    do
   	 echo "${contents[$element]}"|$gawk -v pattern="$2" -v replto="$3" '{gsub (pattern, replto); print}' >> "./apache_templates/$VHOST_CONFIG_NAME"
    done
}

get_tool 'ifconfig'; ifconfig=$res
get_tool 'head'; head=$res
get_tool 'netstat'; netstat=$res
get_tool 'ls'; ls=$res
get_tool 'cat'; cat=$res
get_tool 'seq'; seq=$res
get_tool 'wc'; wc=$res
get_tool 'sed'; sed=$res
get_tool 'useradd'; useradd=$res
get_tool 'groupadd'; groupadd=$res
get_tool 'tar'; tar=$res
get_tool 'make'; make=$res
get_tool 'rm'; rm=$res
get_tool 'cp'; cp=$res
get_tool 'mkdir'; mkdir=$res
get_tool 'chown'; chown=$res
get_tool 'grep'; grep=$res
VHOST_IP=`$ifconfig|$head -2|$grep 'inet addr'|$gawk '{print $2}'|$gawk -F: '{print $2}'`

if [ `cat $LISTEN_CONF | grep "TrafficPanel VIRTUAL HOST PORT" | wc -l` == 0 ]; then
	ServerName=$dname
	ServerAdmin="admin@$ServerName"
	echo -n "Virtual host port number [$VHOST_PORT_DEFAULT] : "
	read ans
	if [ $ans ]; then
		 VHOST_PORT_DEFAULT=$ans
	fi
	port_check

	if [ ! -e $LISTEN_CONF ]; then
		listenConf_choice
	fi

	echo -n "Changing apache virtual host config file  	.......... "
	editVhostTempl 'virtual-host.TEMPLATE' 'VHOST_IP' $VHOST_IP
	editVhostTempl $VHOST_CONFIG_NAME 'SERVER_NAME' $ServerName
	editVhostTempl $VHOST_CONFIG_NAME 'SERVER_ADMIN' $ServerAdmin
	editVhostTempl $VHOST_CONFIG_NAME 'VHOST_PORT' $VHOST_PORT_DEFAULT
	editVhostTempl $VHOST_CONFIG_NAME 'TWMFOLDER' $TWMFOLDER
	echo -e "[\E[32mok\033[0m]"
	echo "
# TrafficPanel VIRTUAL HOST PORT.
Listen $VHOST_IP:$VHOST_PORT_DEFAULT" >> $LISTEN_CONF
	if [ ! $is_apache2 == 1 ]; then
		echo "
# TrafficPanel VIRTUAL HOST CONFIG.
Include $APACHE_VHOSTS_CONFIG_DIR/$VHOST_CONFIG_NAME" >> $LISTEN_CONF
	fi
	$cp ./apache_templates/$VHOST_CONFIG_NAME $APACHE_VHOSTS_CONFIG_DIR
else
	echo "Apache has been configued already"
fi

# export TrafficPanel url as shell variable.
if [ $VHOST_PORT_DEFAULT = '80' ]; then
    export TWMlink="http://$dname"
else
    export TWMlink="http://$dname:$VHOST_PORT_DEFAULT"
fi

if [ -e '/tmp/twm.installation' ];then
	$rm -Rf /tmp/twm.installation
fi
echo "link:$TWMlink" >> /tmp/twm.installation
echo "ip:$VHOST_IP" >> /tmp/twm.installation
echo "port:$VHOST_PORT_DEFAULT" >> /tmp/twm.installation
echo "twm_apache:0" >> /tmp/twm.installation

echo -e "\nTrafficPanel virtual host configured."

exit 0