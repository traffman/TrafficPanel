#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
    unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

my $co = new CGI;
my $error_string = '';

if ($co->param('send'))
{
	my $name = $co->param('name');
	my $pass = $co->param('pass');
	my $authkey = checkLogin($name, $pass);
	if ($authkey)
	{
		print "Set-Cookie: authkey=$authkey; path=/;\n";
		print "Status: 301 Moved Permanantly\n";
		print "Location: /cgi-bin/index.pl?top=1\n\n";
		exit;
	}
	else
	{
		$error_string = "Incorrect Login";
	}
}
print "Content-Type: text/html\n\n";

print <<__EOF;
<html>
<head>
<title>TrafficPanel authorization page</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<table width=100% height=100% cellpadding=0 cellspacing=0>
<form name=f1 action="login.pl" method=post>
  <tr>
    <td width=100% height=100% align=center valign=center>

<div>
<img src="/twm-logo.png" width=290 height=70>
<div style="border: 1px #e2e4e8 solid; width: 250px; background-color: #f3f3f3; height: 110px; margin-top: 10px;">
<table cellpadding=5>
  <tr><td colspan=2>$error_string</td></tr>
  <tr>
    <td>Login</td>
    <td><input type="text" class=control name="name"  style="width: 150px;" /></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input type="password" class=control name="pass" style="width: 150px;" /></td>
  </tr>
  <tr>
    <td colspan='2' align="center">
      <input type="submit" class=control name="send" value="Enter"/>
    </td>
  </tr>
</table> 
</div>
</div>


   </td>
  </tr>
</form>
</table>
</body>
</html>
__EOF
