package TrafficRouting;

require 5;
use Carp;

BEGIN 
{
	use TWM;
	$index = 0;
}


sub new
{
	my $self = {
		protos => ['tcp','udp','gre','icmp']
	};
	return bless $self;
}


sub DESTROY	{
	my $self = shift;
	delete $self->{$_} for (keys %$self);
	undef(%$self);
	undef $self;
}


sub get_proto_string
{
	my $self = shift;
	return join('|', @{$self->{protos}});
}

sub getProtosSelect
{
	my ($self, $proto, $name) = (shift, shift, shift);
	my $str = "<select style='width: 50px;' name=$name class=control>";
	foreach (@{$self->{protos}})
	{
		$str .= "<option value='$_' ${\(setSelected($proto, $_))}>$_";
	}
	$str .= '</select>';
	$str;
}


sub get_services()
{
	my $xml = readModuleConfigFile($cm{services_conf});
	my $list = $xml->{service};
	if (exists($list->{'name'}) && exists($list->{'data'}))
	{
		$list->{$list->{'name'}} = {
			'data' => $list->{'data'}
		};
		delete $list->{'name'};
		delete $list->{'data'};
	}
	$list;
}


return 1;
{}
