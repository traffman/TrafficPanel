#!/bin/sh

httpr_sl=$TWMFOLDER/modules/http_ip_limit/httpr_sl

set -e

case $1 in
start)
        ;;
stop)
        ;;
reconf)
	if [ -e "$httpr_sl" ]; then
		$httpr_sl restart
	else
		echo "Could not find file: $httpr_sl"
	fi
        ;;
restart)
        ;;
*)
	N=/etc/init.d/$NAME
	echo "Usage: $N {start|stop|restart|reconf}" >&2
	exit 1
	;;
esac

exit 0

