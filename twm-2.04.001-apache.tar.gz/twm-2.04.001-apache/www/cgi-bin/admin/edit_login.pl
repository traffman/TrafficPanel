#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
#use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
print "Content-Type: text/html\n\n";
my $allowEdit = &hasAdminAccess;
my $co = new CGI;
my $nick = $co->param("login") || '';

my $title = $nick?'Edit : '.$nick : 'Add new login';
my $login = getLogin($nick);


my $doneString = "";
if ($allowEdit)
{
	if (defined $co->param("save"))
	{
		$login->{password} = $co->param("passwd1") || '';
		$login->{full_name} = $co->param("full_name") || '';
		$login->{enabled} = $co->param("enabled") || '0';
		$login->{authkey} = getRandomString() if !$login->{authkey};
		$login->{last_access} = 0 if !$login->{last_access};
		$login->{login} = $co->param("login") || '';
		$login->{role} = $co->param("role") || '';
		saveLogin($login);
		$doneString = "Data was saved successfully";
		keepHistory("$title\n".Dumper($login));
	}
	elsif (defined $co->param("delete"))
	{
		deleteLogin($login);
		$doneString = "Data was deleted successfully";
		keepHistory("$title\n".Dumper($login));
		$login = getLogin($nick);
		$nick = '';
	}
}

print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}
</script>
</head>
<body>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<span class=titlepage>$title</span>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 0;" width=600>
<tbody>
  <tr height=30>
    <td><a href="logins.pl">Back</a></td>
    <td align=right><a href="" class=help  onClick="showHelp(); return false;">Help</a></td>
  </tr>
</tbody>
</table>
<p class=donestring>$doneString</p>
<table cellpadding=2 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td width=60>* Nick:</td>
    <td><input type=text name=login value="$nick" ${\($nick?'readonly':'')} class=control size=25></td>
  </tr>
  <tr>
    <td width=60>* Full Name:</td>
    <td><input type=text name=full_name value="$login->{full_name}" class=control size=25></td>
  </tr>
  <tr>
    <td width=60>* Password:</td>
    <td><input type=text name=passwd1 value="" class=control size=25> <small>- keep blank to avoid changing</small> </td>
  </tr>
  <tr>
    <td width=60>* Role:</td>
    <td>
      <select name=role>
        <option value=guest>Guest
        <option value=user ${\($login->{role} eq 'user'?'selected':'')}>User
        <option value=manager ${\($login->{role} eq 'manager'?'selected':'')}>Manager
        <option value=admin ${\($login->{role} eq 'admin'?'selected':'')}>Admin
      </select>
    </td>
  </tr>
  <tr>
    <td>Enabled:</td>
    <td><input type=checkbox name=enabled value="1" ${\($login->{enabled}?'checked':'')}></td>
  </tr>
__EOF
if ($allowEdit)
{
print <<__EOF;
  <tr><td colspan=2>
      <input class=control type=submit name=save value="Save">
      &nbsp;&nbsp;&nbsp;
      <input type="submit" class=control name="delete" value="Delete"/>
  </td></tr>
__EOF
}
print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img src="/logout-off.png" width=13 height=13 border=0></a></td></tr>
</tbody>
</table>
TrafficPanel requires login to restrict access to resources and define user role. Dependent on user role some 
TrafficPanel resources will not available or will available as readonly. TrafficPanel supports 4 roles:

<li>Guest is lowest level access and can not change anything. Everything is in readonly mode.
<li>User is next level access and shows almost everything in readonly mode. 
<li>Manager is next level access and can make everything except configuration modification.
<li>Admin is top level access and can make everything.
<br><br>
Pay attention each module defines itself what functionality is role available.
</div>

</body>
</html>
__EOF



