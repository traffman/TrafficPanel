#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(mac_filtering\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
}

use strict;
use TWM;
use Data::Dumper;

my $ignore = join(" \|",map {s/^\D+//g;s/\D+$//g;$_} split "\n", $cm{ignore});
my (%main, %dif);

my $ip_list = &getIPs;
$main{$_->{ip}} = $_->{mac} foreach (@$ip_list);

my @res = run_script("$cm{arp} -n | $ck{grep} -v Address | $ck{gawk} \'{print \$1,\$3}\' | $ck{grep} -Ev '$ignore'");
for (@res) 
{
	if (/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s(\w{2}\:\w{2}\:\w{2}\:\w{2}\:\w{2}\:\w{2})/)
	{
		my ($ip, $mac) = ($1, $2);
		$dif{$ip} = $mac if (exists $main{$1} && $main{$1} && $main{$1} !~ /$2/i);
	}
}

if (%dif)
{
	my @todrop = keys %dif;
	my $xmlip = readConfigFile($ck{scfolder}.$ck{_ip_list});
	my $item = $xmlip->{items}->{item};
	my $xml = &readModuleConfigFile($cm{blocked_list});
	my $item2 = $xml->{items}->{item};
	my (@todrop2, %new_blocked, %blocked_xml, %mail_notice, %old_blocked);

	if (ref $item2 eq 'ARRAY')
	{ 
		foreach (@$item2) { $blocked_xml{$_->{ip}} = $_->{mac} }
	} 
	elsif (ref $item2 eq 'HASH')
	{ 
		$blocked_xml{$item2->{ip}} = $item2->{mac};
	}

	foreach (@todrop)
	{
		if (exists $blocked_xml{$_})
		{ 
			print "$_ is already blocked.\n" if isDebug();
			$mail_notice{$_} = $dif{$_} if (!$cm{send_once});
			$old_blocked{$_} = $dif{$_};
		} 
		else 
		{ 
			$new_blocked{$_} = $dif{$_};
		}
	}

	if (%new_blocked)
	{
		%new_blocked = (%new_blocked, %old_blocked);
		blocking_ip(\%new_blocked);
	}
	
	!$cm{send_once} && ip2email(\%mail_notice,'notice');

	sub blocking_ip
	{
		my $droplist = $_[0];
		$xml->{items} = undef;
	
		while ((my ($ip2drop, $mac)) = each (%$droplist))
		{
			push @{$xml->{items}->{item}}, { ip=>$ip2drop, mac=>$mac };
			foreach my $ip (@$item)
			{
				if ($ip->{ip} eq $ip2drop)
				{
					$ip->{enabled} = 0;
					last;
				}
			}
		}

		saveConfigFile($ck{scfolder}.$ck{_ip_list}, $xmlip);
		run_twm_script("$ck{_ip_list_saver} m");
		saveModuleConfigFile($cm{blocked_list}, $xml);
		keepHistory("Block list is changed\n".Dumper($xml));
		ip2email($droplist,'notice');
	}

}

sub ip2email
{
	my ($droplist, $notice) = (shift, shift);
	my $ip_hash = get_ip_name_hash(&getIPs);
	my $report = "Following internal ip addresses have incorrect mac and have blocked internet access:\r\n\r\n";
	$report .= join('',map {"\t".sprintf("%-15s",$_).sprintf("%-25s",$ip_hash->{$_})."\t$droplist->{$_}\r\n";} keys %$droplist);
	$report .= "\r\nYou can disable this notification via TWM GUI.\r\n" if $notice eq 'notice';
	$report .= "\r\nBest.\r\nRobot.\r\n";
	send_email({
		'to' => $cm{email_to},
		'subject' =>'Blocked ip list',
		'body' => $report
	});
}

__END__
