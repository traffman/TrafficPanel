#!/bin/bash


cd ../

release_folder=/root/TWM/release

rm -Rf $release_folder
mkdir $release_folder

find . -type d | grep -vE "./.svn" | while read item ; do
	mkdir $release_folder/$item
done

find . -type f | grep -vE "\/logs\/|\.log|./.svn|.BAK|.swp|_old." | while read item ; do #|\.conf
	cp $item $release_folder/$item
done


#cp -Rf ./ $release_folder

while read item ; do
	rm -Rf $release_folder/$item
done <<!
bin/forker
#bin/init.sh
bin/ip.conf
bin/masquerading.sh
bin/runner
#bin/twm.sh
#bin/isp/*
backup/*
etc/*
logs/isp/*
modules/close_ports/conf/*
modules/http_bandwidth/conf/*
modules/http_ip_limit/conf/*
modules/http_ip_limit/logs/*
modules/http_logging/conf/*
modules/http_logging/logs/*
modules/http_traffic_limit/conf/*
modules/if_meter/logs/*
modules/mac_filtering/conf/*
modules/shaping_cbq/cbq/*
modules/shaping_cbq/conf/*
modules/tcp_logging/conf/*
modules/traffic_routing/conf/*
modules/traffic_routing/masquearading.sh
template/kernel/*
set_twm_permissions.sh
!

#cd install

echo "" > $release_folder/etc/passwd


cd $release_folder
grep -R scand ./*
echo 'Go to /root/TWM/release to remove all SCAND email addresses and run ./install/make_archive.sh'


