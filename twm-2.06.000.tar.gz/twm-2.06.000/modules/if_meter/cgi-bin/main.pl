#!/usr/bin/perl -w

BEGIN   
{
  (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
  unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
use Time::Local;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $title = "Traffic meter";            
my $co = new CGI;

print "Content-Type: text/html\n\n";
my $selected_interface = $co->param("interface") || $cm{default_interface};

my $tm = time-60*60;
if ($co->param('today'))
{
	my ($day, $mon, $year) =  (localtime($tm))[3,4,5];
	$tm = timelocal(0, 0, $cm{show_today_since}, $day, $mon, $year);
}
my ($min_s, $hour_s, $mday_s, $mon_s, $year_s) =  (localtime($tm))[1,2,3,4,5];
my $fval = (1900 + $year_s).'-'.('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$mon_s].'-'.('00'..'31')[$mday_s];
my $time_forh = $hour_s;
my $time_form = $min_s;
my @start_period = ($mon_s, $mday_s, $year_s);

my ($sec, $min, $hour, $day,$month,$year) = (localtime())[0,1,2,3,4,5];
my $tval = (1900 + $year).'-'.('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$month].'-'.('00'..'31')[$day];
my $time_toh = $hour;
my $time_tom = $min;
my @end_period = ($month, $day, $year);


if (!$co->param('today'))
{
	$fval = $co->param("fval") if $co->param("fval");
	$time_forh = $co->param('time_forh') if $co->param('time_forh');
	$time_form = $co->param('time_form') if $co->param('time_form');
	@start_period = split (/\|/,$co->param("for_")) if $co->param("for_");
	$tval = $co->param("tval") if $co->param("tval");
	$time_toh = $co->param('time_toh') if $co->param('time_toh');
	$time_tom = $co->param('time_tom') if $co->param('time_tom');
	@end_period = split (/\|/ , $co->param("to_")) if $co->param("to_");
}

my $fullStart = timelocal(0, $time_form, $time_forh, $start_period[1], $start_period[0], $start_period[2]);
my $fullEnd = timelocal(0, $time_tom, $time_toh, $end_period[1], $end_period[0], $end_period[2]);

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<script>
function trafficItemClickHandler(obj)
{
	alert("Traffic is :"+obj.title);
}

var img_calendar_src = '/cal_control.gif';
var img_prev_src = '/cal_arrow_left.gif';
var img_next_src = '/cal_arrow_right.gif';
var img_close_src = '/cal_close.gif';

function setNewDate(item)
{
	if (item == 1)
	{
	  showCalendar('f1','for','for',-10,10,4, null,null, null, null, null, null, null,showReport); 
	} else {
	  showCalendar('f1','to','to',-20,20,4, null,null, null, null, null, null, null,showReport2); 
	}
  return false;
}

function showReport()
{
	var dt = document.getElementById('for').value;
	document.getElementById('fval').value = dt;
	document.getElementById("for_").value = curDate.getMonth()+"|"+curDate.getDate()+"|"+curDate.getYear();
	re = /\-/g;
	dt = dt.replace(re, "");

}

function showReport2()
{
  var dt = document.getElementById('to').value;
  document.getElementById('tval').value = dt;
  document.getElementById("to_").value = curDate.getMonth()+"|"+curDate.getDate()+"|"+curDate.getYear();
  re = /\-/g;
  dt = dt.replace(re, "");
}

</script>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<link href="/calendar.css" rel=stylesheet type=text/css>
<script language="javascript" src="/calendar.js?f=2"></script>
</head>
<body>
<table cellpadding=0 cellspacing=0 border=0 width=100% height=100%>
<form name=f1 action="" method=post >
<input type=hidden name=values value="">
<input type=hidden name=tval id=tval value="$tval">
<input type=hidden name=fval id=fval value="$fval">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
</td>
</tr>
</table>
__EOF

my (@r, @t, $maxDate, $minDate);
my ($allInterface, $select) = ""x2;
my @files = glob $ck{twmfolder}."modules/$mc/logs/*.log";
foreach (@files) 
{
	if(/\/logs\/(.+)\.log/)
	{       
		my @interfaceName = split (/\_/, $1);
		if ($allInterface !~ /$interfaceName[0]\|/)
		{ 
			$selected_interface = $selected_interface||$interfaceName[0];
			$allInterface .= $interfaceName[0]."|";
			my $selected = $selected_interface eq $interfaceName[0]?"selected":"";
			$select .= "<option value='$interfaceName[0]' $selected>".$interfaceName[0]."</option>";
		}
	}

	if (/\/logs\/$selected_interface(.+)\.log/)
	{       
		my @report_date = split(/\_/, $1);
		my $current_ = timelocal(0, $time_form, $time_forh, $report_date[3], $report_date[2]-1, $report_date[1]-1900);
		if ($current_ >= $fullStart && $current_<=$fullEnd)
		{
			open(IN, "< $_") || die "Cannot open $_ for read\n$!";
			while (my $line = <IN>) 
			{
				if ($line =~ /^(\d+)\s(R)\:\s(\d+)\s\(\+(\d+)\)\s(T)\:\s(\d+)\s\(\+(\d+)\)/)
				{
				        if ($1 >= $fullStart && $1<=$fullEnd)
				        {
						$maxDate = $1 if ($maxDate<$1);
						$minDate = $1 if (!$minDate);
						$minDate = $1 if ($minDate>$1);
	        				push @r, $4;
						push @t, $7;
				        }
				}
			}
			close(IN);
		}
	}      	
}
$minDate = $minDate||$fullStart;
$maxDate = $maxDate||$fullEnd;
&drow(\@r, 0, "blue", $minDate, $maxDate, "Incomming $selected_interface traffic (per $cm{period} sec)");
&drow(\@t, 1, "red", $minDate, $maxDate, "Outgoing $selected_interface traffic (per $cm{period} sec)");

print <<__EOF;
<table>
  <tr>
    <td>Interface:</td>
    <td><select id="interface" class="control"  name="interface">$select</select></td>
    <td width=20>&nbsp;</td>
    <td>From:</td>
    <td><input type=button name=for id=for value="$fval" maxlength=10 class=control style='width: 80px;' onclick="setNewDate(1);"/><div id="popupcalendar" class=popupcalendar>&nbsp;</div></td>
    <td colspan=2>
      <input type="text" class="control" id="time_forh" name="time_forh" value="${\sprintf("%02d",$time_forh)}" size=2/>
      :
      <input type="text" class="control" id="time_form" name="time_form" value="${\sprintf("%02d",$time_form)}" size=2/>
    </td>
    <td width=20>&nbsp;</td>
    <td>To:</td>
    <td><input type=button name=to id=to value="$tval" maxlength=10 class=control style='width: 80px;' onclick="setNewDate(2);"/></td>
    <td colspan=2>
      <input type="text" class="control" id="time_toh" name="time_toh" value="${\sprintf("%02d",$time_toh)}" size=2/>
      :
      <input type="text" class="control" id="time_tom" name="time_tom" value="${\sprintf("%02d",$time_tom)}"size=2/>
    </td>
    <td width=20>&nbsp;</td>
    <td>
      <input type="submit" class=control name=show value="Show"/>
      <input type="submit" class=control name=today value="ToDay" onClick="setToday();"/>
    </td>
  </tr>
</table>
<input type=hidden id="to_" name="to_" value="${\$co->param("to_")}"/>
<input type=hidden id="for_" name="for_" value="${\$co->param("for_")}"/>
</form>
</table>

<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Choosing interface and time period you get interface traffic bandwidth
</div>

</body>
</html>
__EOF


sub drow
{
	my $items = $_[0];
	return 0 if $#$items == -1;
	my $height = 400;	# bar height
	my $width = 600;	# bar width
	my $h_left = 150;	# bar left
	my $h_top = 100;	# bar top

	my $max_item = get_max_item($items);
	my $quantum_height = $max_item/$height;
	my $item_width = sprintf("%.0f", $width/($#$items+1)) || 1;
	$items = normalize_array($items, $width);
	for (my $i=0; $i<=$#$items; $i++)
	{
		my $item_height = sprintf "%.0f",$items->[$i]/$quantum_height;
		print qq|<div onclick='trafficItemClickHandler(this);' title='${\(getHumanTrafficNumber($items->[$i],'k'))} Kb' style="position:absolute; left:${\($h_left + $item_width*$i)}px; top:${\($height*(1+$_[1])+$h_top*(1+$_[1]) - $item_height)}px; background:$_[2]; width:${\($item_width+1)}px; height:${\($item_height)}px;"></div>|;
	}
	$width = $item_width*($#$items+1);
	my $lable_top1 =  $height*$_[1]+$h_top*(1+$_[1]);
	my $lable_top2 = $height*(1+$_[1])+$h_top*(1+$_[1]);
	my $date_top_min = $height*(1+$_[1])+$h_top*(1+$_[1]) + 10;
	print 	<<__EOF;
	<div style="position:absolute; left:${\($h_left+90)}px; top:${\($lable_top1-15)}px; width:350px; height:20px;"><b>$_[5]</b></div>
	<div style="position:absolute; left:${\($h_left-60)}px; top:${lable_top1}px; width:100px; height:10px;">${\(getHumanTrafficNumber($max_item,'k'))} Kb</div>
	<div style="position:absolute; left:${\($h_left-10)}px; top:${\($lable_top2-15)}px; width:40px; height:10px;">0</div>
	<div style="position:absolute; left:${\($h_left)}px; top:${\($lable_top1)}px; background:#000000;  width:2px; height:${height}px;"></div>
	<div style="position:absolute; left:${h_left}px; top:${lable_top2}px; background:#000000;  width:${\($width+5)}px; height:2px;"></div>
	<div style="position:absolute; left:${\($h_left+$width-60)}px; top:${date_top_min}px;  width:130px; height:2px;">${\getDateTime($_[4])}</div>
	<div style="position:absolute; left:${\($h_left)}px; top:${date_top_min}px;  width:130px; height:2px;">${\getDateTime($_[3])}</div>
__EOF
}

##################################################################
# transform array to show in grafic
##################################################################
sub normalize_array
{
	my $count_points = sprintf "%.0f", $#{$_[0]}/$_[1];
	if ($count_points > 0)
	{
		my @tmp;
		for (my $i=0; $i<$_[1] && push(@tmp, get_item_value($_[0],$count_points,$i)); $i++){};
		return \@tmp;
	}
	return $_[0];
}

###################################################
# calculate normalized array item
###################################################
sub get_item_value
{
	my $value = 0;
	for (my $i=($_[1]*$_[2]-$_[1]); $i < $_[1]*$_[2]; $i++)
	{
    	    $value += $_[0]->[$i];
	}                           
	return $value/$_[1];
}


##############################################
# returns max array item
##############################################
sub get_max_item
{
	my $max = 0;
	foreach (@{$_[0]})
	{
		$max = $_ if $_>$max;
	}
	return $max;
}


