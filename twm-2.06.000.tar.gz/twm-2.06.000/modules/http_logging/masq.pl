#!/usr/bin/perl -w

BEGIN   {
	sub getPoints{return '../../' if (!$_[1]); return '../' if (!$_[0]); return '/';}
	(my $file = __FILE__) =~ s/(\/?modules)?(\/?http_logging)?\/?\w+\.pl$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/'; #$file .= "bin";
    unshift(@INC, $file.'bin');
    unshift(@INC, $file.'modules/http_logging');
}

use strict;
use TWM;
use Logging;
#use Data::Dumper;

my $internalIP = &getInternalIP;
my $localip = $internalIP->{ip};
my $local_interface = $internalIP->{inf};
my $squid_port;

my $current_interface = `$ck{netstat} -nr|$ck{grep} -E '^.+0\.0\.0\.0.+UG'|$ck{gawk} '\{print \$8\}'` || die "Can't get interface info$!";
chomp $current_interface;

my $item;
my $logging = new Logging;
my $squid_settings = $logging->getSquidsSettings();
foreach my $v (values %$squid_settings)
{
	$squid_port = $v->{port} if ($current_interface eq $v->{inf});
}

my ($add_rules, $delete_rules) = ('I', 'D');
if ($#ARGV > -1)
{
	$add_rules = $ARGV[0]=~/([AI])/?$1:'';
	$delete_rules = $ARGV[0]=~/([D])/?$1:'';
}

if ( -e "$ck{twmfolder}modules/$mc/conf/list.txt" )
{
	open(FILE, "+<$ck{twmfolder}modules/$mc/conf/list.txt") || die "Can't open $ck{twmfolder}modules/$mc/conf/list.txt $!\n";
	if ($delete_rules)
	{
		while (<FILE>)
		{
			chomp;
			next if !$_;
			system "$ck{iptables} -t nat -$delete_rules PREROUTING -i $local_interface -p tcp -s $_ -d ! $localip --dport 80 -j REDIRECT --to-port $squid_port";
			system "$ck{iptables} -$delete_rules OUTPUT -p tcp -d $_ --sport $squid_port  -j ACCEPT";
		}
	}

	seek(FILE,0,0) || die "Seeking: $!\n";

	if ($add_rules)
	{
		my $ips = &getIPs;
		for (@$ips)
		{
			if ($_->{enabled})
			{
				print FILE "$_->{ip}\n";
				system "$ck{iptables} -t nat -$add_rules PREROUTING -i $local_interface -p tcp -s $_->{ip} -d ! $localip --dport 80 -j REDIRECT --to-port $squid_port";
				system "$ck{iptables} -$add_rules INPUT -p tcp -s $_->{ip} --dport $squid_port  -j ACCEPT";
				system "$ck{iptables} -$add_rules OUTPUT -p tcp -d $_->{ip} --sport $squid_port  -j ACCEPT";
			}
		}
		truncate(FILE, tell(FILE)) || die "Truncating: $!\n";
		close FILE;
	}
}


__END__
