#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
print "Content-Type: text/xml\n\n";

my $ip = $co->param("ip")||'';
my ($status, $message) = ('')x2;
if ($allowEdit)
{
	keepHistory("Restart squid");
	($status, $message) = ('true', '');
	run_twm_script("$cm{squid_init} restart", $mc);
}
else
{
	($status, $message) = ('false', 'You do not have required permissions');
}


print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
