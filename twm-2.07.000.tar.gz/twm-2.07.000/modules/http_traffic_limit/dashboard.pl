#!/usr/bin/perl -w

BEGIN
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(http_traffic_limit\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
	unshift(@INC, $file.'modules/http_traffic_limit');
}

use strict;
use TWM;
use TrafficLimit;
use Data::Dumper;

my $host = $ARGV[0];

exit unless ($host);

my $network_info = &getNetworkInfo;

print <<__EOF;
fullrow=0

__EOF

print <<__EOF;
  <div class="paneltitle"><span class="paneltitlerow">HTTP Content Limitation</span></div>
  <div class="panelcontent">
    <div class="panelcontentrow">
__EOF

my $objTrafficLimit = TrafficLimit->new();
my $xml = &readModuleConfigFile($cm{pool});
my @pools = $objTrafficLimit->convertPool2Array($xml);
my $break;

foreach my $pool (@pools) {

    if (ref $pool->{'content'}{'ip'} eq 'ARRAY') {
        foreach(@{$pool->{'content'}{'ip'}}) {
            if (/\b$host\b/) {
				print_row($pool->{'label'}, print_disabled_dest($pool->{'label'}));
                $break = '1';
            }
        }
    }
    else {
        if($pool->{'content'}{'ip'} =~ /$host/) {
			print_row($pool->{'label'}, print_disabled_dest($pool->{'label'}));
            $break = '1';
        }
        else {
            if($pool->{'content'}{'ip'} =~ /$network_info->{network}\/$network_info->{cidr}/) {
				print_row($pool->{'label'}, print_disabled_dest($pool->{'label'}));
                $break = '1';
            }
        }
    }

    last if $break;
}

sub print_disabled_dest {
    my $destinations;
    foreach my $pool(@pools) {
    if ($pool->{'label'} eq $_[0]) {
        if (ref $pool->{'disable'}{'destination'} eq 'ARRAY') {
            $destinations .= " <li>$_<br></li>" foreach(@{$pool->{'disable'}{'destination'}})
        }
        else {
            $destinations = $pool->{'disable'}{'destination'};
        }
    }
    }
    return $destinations;
}

print <<__EOF;
</div>
  </div>
__EOF

sub print_row
{
    my ($pool, $disabled) = (shift, shift);
	$disabled = $disabled?"<br>$disabled":'none';
    print <<__EOF;
<div>Pool name: $pool</div>
<div>Disabled resources: $disabled</div>
__EOF
}

__END__
