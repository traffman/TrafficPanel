#!/usr/bin/perl -w

BEGIN {
  (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
  unshift(@INC, $file);
}

use strict;
use TWM;
use Logging;

if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
print "Content-Type: text/html\n\n";
my $description = &getModuleInfo->{name};
my $dtstart = `/bin/date +%Y-%b-%d`;
chomp $dtstart;
(my $sdt = $dtstart) =~ s/\-//g;

my $logging = new Logging;
my $squids = $logging->getSquidsSettings();

print <<__EOF;
<html>
<head>
<script>
var img_calendar_src = '/cal_control.gif';
var img_prev_src = '/cal_arrow_left.gif';
var img_next_src = '/cal_arrow_right.gif';
var img_close_src = '/cal_close.gif';

function setNewDate()
{
  showCalendar('f1','dtstart','dtstart',-10,10,4, null,null, null, null, null, null, null,showReport); 
  return false;
}

function showReport()
{
  var dt = document.getElementById('dtstart').value;
  var re = /\-/g;
  dt = dt.replace(re, "");
  var squid = document.getElementById('squid').value;
  var url = 'sarg_rpt.pl?squid='+squid+'&dt='+dt+'&t='+((new Date).getTime());
  document.getElementById('sargFrame').src = url;
}

</script>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<link href="/calendar.css" rel=stylesheet type=text/css>
<script language="javascript" src="/calendar.js?f=2"></script>
</head>
<body>
<table cellpadding=0 cellspacing=0 border=0 width=100% height=100%>
<form name=f1 action="" method=post>
  <tr>
    <td height=50 width=100%>
<div style="margin: 10 0 0 10;">
<table cellpadding=0 cellspacing=0 border=0 width=90%>
<tbody>
  <tr>
    <td class=titlepage>$description</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p>

Show report for ISP <select name=squid id=squid class="control" onChange="showReport();">
__EOF

for my $v (values %$squids)
{
	print "<option value=$v->{isp}>$v->{isp}</option>\n";
}

print <<__EOF;
</select> at 
<input type=button name=dtstart id=dtstart value="$dtstart" maxlength=10 class=control style='width: 100px;' onclick="setNewDate();">
<div id="popupcalendar" class=popupcalendar>&nbsp;</div>
</div>
    </td>
  </tr>
  <tr>
    <td width=100% height=100%>
<iframe marginheight=0 scrolling=auto marginwidth=0 frameborder=0 id=sargFrame name=sargFrame src="sarg_rpt.pl?squid=${\([values %$squids]->[0]->{isp})}&dt=$sdt" style="z-index:999;width:100%; height:100%;"></iframe>
    </td>
  </tr>
</form>
</table>

<div class=help style="width: 400px; height: 110px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see http traffic report through proxy server per ISP at specified date.
</div>

</body>
</html>
__EOF

__END__
