#!/bin/sh

gcc runner.c -o runner
chown root:$1 runner
chmod 4750 runner
cp -p runner ../../../bin

exit 0
