#!/bin/bash

perl "$TWMFOLDER/modules/http_logging/masq.pl" $1
