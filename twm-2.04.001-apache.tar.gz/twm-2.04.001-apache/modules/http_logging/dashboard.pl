#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(http_logging\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
	unshift(@INC, $file.'modules/http_logging');
}

use strict;
use TWM;
use Logging;
use Data::Dumper;

my $host = $ARGV[0];
my $boundary = '____sdgjskdgnwurtigsdmbnsoruitwegnsdmfgbnsdugwiegmasdngfdhwrutgbrbmslgnaigqjlkr;tjergiorbnjwuegqkrjgdbnsdm,bnsug';

print <<__EOF;
fullrow=1
boundary=$boundary

__EOF

my $dt=`/bin/date +%Y%b%d`;
chomp $dt;
$host =~ s/\./_/g;
my $logging = new Logging;
my $squid_settings = $logging->getSquidsSettings();

foreach my $v (values %$squid_settings)
{
	my $squid = $v->{'isp'};
	my $paramHost = $host?"&fl=$host":'';
	print <<__EOF;
$boundary
  <div class="paneltitle"><span class="paneltitlerow">HTTP Log $squid</span></div>
  <div class="panelcontent">
    <div class="panelcontentrow"><iframe onload="this.style.height = (this.parentNode.parentNode.clientHeight - 6)+'px'; this.style.width = (this.parentNode.parentNode.clientWidth - 3)+'px';"
marginheight=0 scrolling=auto marginwidth=0 frameborder=0 src="/cgi-bin/modules/$logging->{this_module_code}/sarg_rpt.pl?squid=$squid&dt=$dt$paramHost"
></iframe></div>
  </div>
__EOF
}
