#!/usr/bin/perl

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
&checkAuthorization;
$| = 1;

my $co = new CGI;

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
</head>
<body>
__EOF
(my $host = $co->param("host")) =~ s/[^\w\.\-]//;
my $cmd = ($host =~ /^\d+\.\d+\.\d+.\d+$/)?"-x $host":"$host any";
my @res = run_script("$cm{dig} $cmd");
print "<b>Dig result for $host</b><br><br>";
print "<pre>".join("",@res)."</pre>";

print <<__EOF;
</body>
</html>
__EOF

