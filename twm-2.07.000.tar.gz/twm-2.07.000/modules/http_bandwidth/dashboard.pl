#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(http_bandwidth\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
	unshift(@INC, $file.'modules/http_bandwidth');
}

use strict;
use TWM;
use Bandwidth;

my $host = $ARGV[0];

exit unless ($host);

print <<__EOF;
fullrow=0

__EOF

print <<__EOF;
  <div class="paneltitle"><span class="paneltitlerow">HTTP Shaping</span></div>
  <div class="panelcontent">
    <div class="panelcontentrow">
__EOF

my $objBandWidth = Bandwidth->new();
my $xml_classes = &readModuleConfigFile($cm{classes_config});
my $xml_pools = &readModuleConfigFile($cm{pools_config});
my @classes = $objBandWidth->convertACL2Array($xml_classes);
my @pools = $objBandWidth->convertPool2Array($xml_pools);

my $show_default_class = '1';
my ($class_name, $pool_name, $pool_speed);

foreach(@classes) {

    if ($_->{'type'} eq 'src') {

        if ($_->{'content'} =~ /\b$host\b/) {

			$class_name = $_->{'label'};
			my $class = $_->{'name'};

			foreach(@pools) {
			    if (exists($_->{'content'}{$class})) {
	       			$pool_name = $_->{'label'};
	       			$pool_speed = $_->{'speed'};
					$pool_speed = 'Unlimited' if $pool_speed eq '-1';
				}
			}

		print_row($class_name, $pool_name, $pool_speed);
		$show_default_class = '0';
		}

    }

}

if ($show_default_class)	{
print <<__EOF;
<table align=center>
    <tr><td height=50>&nbsp</td></tr>
    <tr><td>
    <table cellpadding=1 cellspacing=1 border=0>
        <tr height=25><td align=center>There are no any special rules.</td></tr>
    </table>
    </td></tr>
</table>
__EOF
}

print <<__EOF;
</div>
  </div>
__EOF

sub print_row
{
	my ($class_name, $pool_name, $pool_speed) = (shift, shift, shift);
	print <<__EOF;
<div>Class name: $class_name</div>
<div>Pool name: $pool_name</div>
<div>Pool speed: $pool_speed</div>
__EOF
}

__END__
