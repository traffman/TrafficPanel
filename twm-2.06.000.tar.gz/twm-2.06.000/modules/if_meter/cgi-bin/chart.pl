#!/usr/bin/perl -w

BEGIN   
{
  (my $file = __FILE__)=~ s/modules\/.+?\/.+\.pl$//;
  unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
use Time::Local;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $title = "Traffic meter";            
my $co = new CGI;

print "Content-Type: text/html\n\n";
my $selected_interface = $co->param("interface") || $cm{default_interface} || '';

my $tm = time-60*60;
if ($co->param('today'))
{
	my ($day, $mon, $year) =  (localtime($tm))[3,4,5];
	$tm = timelocal(0, 0, $cm{show_today_since}, $day, $mon, $year);
}
my ($min_s, $hour_s, $mday_s, $mon_s, $year_s) =  (localtime($tm))[1,2,3,4,5];
my $fval = (1900 + $year_s).'-'.('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$mon_s].'-'.('00'..'31')[$mday_s];
my $time_forh = $hour_s;
my $time_form = $min_s;
my @start_period = ($mon_s, $mday_s, $year_s);

my ($sec, $min, $hour, $day,$month,$year) = (localtime())[0,1,2,3,4,5];
my $tval = (1900 + $year).'-'.('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$month].'-'.('00'..'31')[$day];
my $time_toh = $hour;
my $time_tom = $min;
my @end_period = ($month, $day, $year);


if (!$co->param('today'))
{
	$fval = $co->param("fval") if $co->param("fval");
	$time_forh = $co->param('time_forh') if $co->param('time_forh');
	$time_form = $co->param('time_form') if $co->param('time_form');
	@start_period = split (/\|/,$co->param("for_")) if $co->param("for_");
	$tval = $co->param("tval") if $co->param("tval");
	$time_toh = $co->param('time_toh') if $co->param('time_toh');
	$time_tom = $co->param('time_tom') if $co->param('time_tom');
	@end_period = split (/\|/ , $co->param("to_")) if $co->param("to_");
}

my $fullStart = timelocal(0, $time_form, $time_forh, $start_period[1], $start_period[0], $start_period[2]);
my $fullEnd = timelocal(0, $time_tom, $time_toh, $end_period[1], $end_period[0], $end_period[2]);

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<script>
function trafficItemClickHandler(obj)
{
	alert("Traffic is :"+obj.title);
}

var img_calendar_src = '/cal_control.gif';
var img_prev_src = '/cal_arrow_left.gif';
var img_next_src = '/cal_arrow_right.gif';
var img_close_src = '/cal_close.gif';

function setNewDate(item)
{
	if (item == 1)
	{
	  showCalendar('f1','for','for',-10,10,4, null,null, null, null, null, null, null,showReport); 
	} else {
	  showCalendar('f1','to','to',-20,20,4, null,null, null, null, null, null, null,showReport2); 
	}
  return false;
}

function showReport()
{
	var dt = document.getElementById('for').value;
	document.getElementById('fval').value = dt;
	document.getElementById("for_").value = curDate.getMonth()+"|"+curDate.getDate()+"|"+curDate.getYear();
	re = /\-/g;
	dt = dt.replace(re, "");

}

function showReport2()
{
  var dt = document.getElementById('to').value;
  document.getElementById('tval').value = dt;
  document.getElementById("to_").value = curDate.getMonth()+"|"+curDate.getDate()+"|"+curDate.getYear();
  re = /\-/g;
  dt = dt.replace(re, "");
}

</script>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<link href="/calendar.css" rel=stylesheet type=text/css>
<script language="javascript" src="/calendar.js?f=2"></script>
<script type="text/javascript" src="/jquery.min.js"></script>
<script type="text/javascript" src="/highcharts.js"></script>
</head>
<body>
<table cellpadding=0 cellspacing=0 border=0 width=100% height=100%>
<form name=f1 action="" method=post >
<input type=hidden name=values value="">
<input type=hidden name=tval id=tval value="$tval">
<input type=hidden name=fval id=fval value="$fval">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
</td>
</tr>
</table>
__EOF

my (@r, @t);
my ($maxDate, $minDate) = (0)x2;
my ($allInterface, $select) = ("")x2;
my @files = glob $ck{twmfolder}."modules/$mc/logs/*.log";
foreach (@files) 
{
	if(/\/logs\/(.+)\.log/)
	{       
		my @interfaceName = split (/\_/, $1);
		if ($allInterface !~ /$interfaceName[0]\|/)
		{ 
			$selected_interface = $selected_interface||$interfaceName[0];
			$allInterface .= $interfaceName[0]."|";
			my $selected = $selected_interface eq $interfaceName[0]?"selected":"";
			$select .= "<option value='$interfaceName[0]' $selected>".$interfaceName[0]."</option>";
		}
	}

	if (/\/logs\/$selected_interface(.+)\.log/)
	{       
		my @report_date = split(/\_/, $1);
		my $current_ = timelocal(0, $time_form, $time_forh, $report_date[3], $report_date[2]-1, $report_date[1]-1900);
		if ($current_ >= $fullStart && $current_<=$fullEnd)
		{
			open(IN, "< $_") || die "Cannot open $_ for read\n$!";
			while (my $line = <IN>) 
			{
				if ($line =~ /^(\d+)\s(R)\:\s(\d+)\s\(\+(\d+)\)\s(T)\:\s(\d+)\s\(\+(\d+)\)/)
				{
				        if ($1 >= $fullStart && $1<=$fullEnd)
				        {
						$maxDate = $1 if ($maxDate<$1);
						$minDate = $1 if (!$minDate);
						$minDate = $1 if ($minDate>$1);
	        				push @r, sprintf("%.0f",$4/1024);
						push @t, sprintf("%.0f",$7/1024);
				        }
				}
			}
			close(IN);
		}
	}      	
}
$minDate = $minDate||$fullStart;
$maxDate = $maxDate||$fullEnd;
my $rs = join(',',@r);
my $ts = join(',',@t);
my ($min_sd, $hour_sd, $mday_sd, $mon_sd, $year_sd) =  (localtime($minDate))[1,2,3,4,5];
$year_sd+=1900;
my $width = 800;
$width = $#r*5 if ($#r*5 > $width);


print <<__EOF;
<table>
  <tr>
    <td>Interface:</td>
    <td><select id="interface" class="control"  name="interface">$select</select></td>
    <td width=20>&nbsp;</td>
    <td>From:</td>
    <td><input type=button name=for id=for value="$fval" maxlength=10 class=control style='width: 80px;' onclick="setNewDate(1);"/><div id="popupcalendar" class=popupcalendar>&nbsp;</div></td>
    <td colspan=2>
      <input type="text" class="control" id="time_forh" name="time_forh" value="${\sprintf("%02d",$time_forh)}" size=2/>
      :
      <input type="text" class="control" id="time_form" name="time_form" value="${\sprintf("%02d",$time_form)}" size=2/>
    </td>
    <td width=20>&nbsp;</td>
    <td>To:</td>
    <td><input type=button name=to id=to value="$tval" maxlength=10 class=control style='width: 80px;' onclick="setNewDate(2);"/></td>
    <td colspan=2>
      <input type="text" class="control" id="time_toh" name="time_toh" value="${\sprintf("%02d",$time_toh)}" size=2/>
      :
      <input type="text" class="control" id="time_tom" name="time_tom" value="${\sprintf("%02d",$time_tom)}"size=2/>
    </td>
    <td width=20>&nbsp;</td>
    <td>
      <input type="submit" class=control name=show value="Show"/>
      <input type="submit" class=control name=today value="ToDay" onClick="setToday();"/>
    </td>
  </tr>
</table>
<input type=hidden id="to_" name="to_" value="${\($co->param("to_")||'')}"/>
<input type=hidden id="for_" name="for_" value="${\($co->param("for_")||'')}"/>
</form>
</table>

<script type="text/javascript">
var chart;
\$(document).ready(function() {
	chart = new Highcharts.Chart({
		chart: {
			renderTo: 'container', 
			defaultSeriesType: 'area'
		},
		credits: {
			enabled:false
		},
		title: {
			text: '$selected_interface traffic (per $cm{period} sec)'
		},
		xAxis: {
			type : 'datetime'
		},
		yAxis: {
			title: {
				text: 'Traffic'
			},
			labels: {
				formatter: function() {
					return this.value +'k';
				}
			}
		},
		tooltip: {
			formatter: function() {
				return this.series.name +' traffic <b>'+
					Highcharts.numberFormat(this.y, 0, null, ' ')+'kB' +'</b><br/> at '+ (new Date(this.x)).getHours()+':'+(new Date(this.x)).getMinutes();
			}
		},
		plotOptions: {
			area: {
				fillOpacity: 0.5
			}
		},
		series: [
			{
				name: 'Incomming',
				data: [$rs]
				, pointStart: Date.UTC($year_sd, $mon_sd, $mday_sd, $hour_sd, $min_sd)
				, pointInterval: 60 * 1000
		
			}
			, {
				name: 'Outgoing',
				data: [$ts]
				, pointStart: Date.UTC($year_sd, $mon_sd, $mday_sd, $hour_sd, $min_sd)
				, pointInterval: 60 * 1000
  
			}
		]
	});
	
	
});
</script>
<div id="container" style="width: ${width}px; height: 400px; margin: 0 auto"></div>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Choosing interface and time period you get interface traffic bandwidth
</div>

</body>
</html>
__EOF

