#!/usr/bin/perl -w

BEGIN   {
    my $file = '../bin/';
    unshift(@INC, $file);
}

use strict;
use TWM;
use Data::Dumper;

if ($ARGV[0])
{
	my $login;
	$login->{password} = $ARGV[1] || '';
	$login->{full_name} = $ARGV[0] || '';
	$login->{enabled} = '1';
	$login->{authkey} = '';
	$login->{last_access} = '0';
	$login->{login} = $ARGV[0];
	$login->{role} = 'admin';
	saveLogin($login);
}
else
{
	my $file = __FILE__;
	print <<EOF;
Usage: perl $file login password
EOF
}

__END__
