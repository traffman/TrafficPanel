#!/bin/bash


function logDebug()
{
#	if [ "$debug" = "1" ]; then
		echo "$@"
		echo "" >> $TWMFOLDER/logs/debug.log
		echo "Source: $TWMFOLDER/modules/network/run_isp.sh" >> $TWMFOLDER/logs/debug.log
		echo -n "Date: " >> $TWMFOLDER/logs/debug.log
		echo `date` >> $TWMFOLDER/logs/debug.log
		echo "User: " >> $TWMFOLDER/logs/debug.log
		echo "Host: " >> $TWMFOLDER/logs/debug.log
		echo "$@" >> $TWMFOLDER/logs/debug.log
#	fi
}

set -e

case $1 in
daemon)
	shift
	what=$1
	todo=$2
	is_default=$3
	#logDebug "$TWMFOLDER/bin/isp/$what $todo $is_default"
	#logDebug "$TWMFOLDER/bin/masq.sh"
	$TWMFOLDER/bin/isp/$what $todo $is_default
	$TWMFOLDER/bin/masq.sh
        ;;
*)
	if [ -x $TWMFOLDER/bin/isp/$what ]; then
		#echo "$TWMFOLDER/bin/forker $TWMFOLDER $0 daemon $@"
		$TWMFOLDER/bin/forker $TWMFOLDER $0 daemon $@ # 2>&1 >/dev/null &
	else
		echo "Could not find file $what"
	fi
	;;
esac

exit 0

