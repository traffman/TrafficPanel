#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
    unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&LogOut;
print "Set-Cookie: authkey=-987654321; path=/;\n";
print "Status: 301 Moved Permanantly\n";
print "Location: /cgi-bin/login.pl\n\n";
exit;
