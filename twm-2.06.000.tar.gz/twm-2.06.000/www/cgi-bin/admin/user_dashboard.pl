#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use File::Copy;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $co = new CGI;

print "Content-Type: text/html\n\n";

my $ip = $co->param("ip");
my $ipInfo = getIPInfo($ip);
my $ip_list = &getIPs;

print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<form name=f1 action="" method=post>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=760>
<tbody>
  <tr>
    <td>
	<div class=titlepage>Dashboard of $ipInfo->{full_name}</div>
	<div style="padding-left: 10px;">
__EOF
print "<font color=#880000>DISABLED</font><br>" unless $ipInfo->{'enabled'};
print <<__EOF;
	ip: $ipInfo->{ip}<br>
	DNS name: $ipInfo->{dns_name}<br>
	MAC: $ipInfo->{mac}<br>
	</div>
    </td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<br>
__EOF

my @modules;
my %modules = &getModules();
for (keys %modules)
{
	next if ($modules{$_}->{enabled} ne 'true');
	next unless (-e "$ck{twmfolder}modules/$_/dashboard.pl");
	populateCfromConfig($_);
	next if (!exists($C->{$_}->{dashboard}) || !$C->{$_}->{dashboard});
	my $order = exists($C->{$_}->{dashboard_number})?$C->{$_}->{dashboard_number}:100;
	push @modules, {'order' => $order, 'module' => $_};
}

@modules = sort {$a->{order} <=> $b->{order}} @modules;

my $left = 1;
for my $module (@modules)
{
	my $res = getData([run_twm_script("dashboard.pl ".$ip, $module->{module})]);
	my $data = $res->{data};
	for my $row (@$data)
	{
		next if !$row;
		print qq|<div class="rowpanel">\n|;
		if ($res->{cfg}->{fullrow})
		{
			print qq|<div class="fullpanel">\n|;
			$left = 1;
		}
		else
		{
			print qq|<div class="|.($left?'leftpanel':'rightpanel').qq|">\n|;
			$left = $left?0:1;
		}
		print qq|$row\n</div>\n</div>\n|;
	}
}

print <<__EOF;




    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>

<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
</div>

</body>
</html>
__EOF




sub getData
{
	my $is_data = 0;
	my $data = '';
	my @res;
	my %cfg;
	my $rows = shift;
	my $boundary = '';
	for (@$rows)
	{
		chomp;
		if ($_ && !$is_data)
		{
			$cfg{$1} = $2 if /(.+?)=(.+)/;
			$boundary = $2 if ($1 eq 'boundary');
		}
		elsif (!$_ && !$is_data)
		{
			$is_data = 1;
		}
		elsif ($is_data && $boundary && $_ && $_ eq $boundary)
		{
			push @res, $data if $data;
			$data = '';
		}
		else
		{
			$data .= $_;
		}
	}
	push @res, $data;
	return {'cfg'=>\%cfg, 'data'=>\@res};
}


__END__
