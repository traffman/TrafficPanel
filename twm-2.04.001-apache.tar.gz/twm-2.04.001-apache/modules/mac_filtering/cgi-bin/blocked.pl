#!/usr/bin/perl -w

BEGIN   
{
  (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
  unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
my $co = new CGI;
my $title = "Blocked hosts";            

print "Content-Type: text/html\n\n";

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<script>
function formValidate() {
  var f = document.forms.f1;
  var obj = document.getElementsByTagName("INPUT");
debugger;
  f.values.value = "";
  for (var i=0; i<obj.length; i++)  {
    if (obj[i].getAttribute("name") == "fld1")  {
      f.values.value += "|"+obj[i].value;
    }

    if (obj[i].getAttribute("name") == "fld2")  {
      f.values.value += "*"+obj[i].value;
    }
  }
  f.submit();
  return false;
}

        

function openItem(obj)  
{
	var tr = obj.parentNode.parentNode.parentNode;
	tr.childNodes[3].childNodes[0].style.display = "none";
	tr.childNodes[3].childNodes[1].style.display = "inline";
}


function  applyNewMac(obj)
{
	var tr = obj.parentNode.parentNode;
	tr.childNodes[3].childNodes[1].childNodes[0].value = tr.childNodes[4].innerHTML;
	openItem(tr.childNodes[3].childNodes[0].childNodes[0]);
}


</script>
__EOF

my $xml = &readModuleConfigFile($cm{blocked_list});
my $blockedlist = $xml->{items}->{item};
$blockedlist = [$blockedlist] if ref $blockedlist ne 'ARRAY';
my $ip = readConfigFile($ck{scfolder}.$ck{_ip_list});
my $item = $ip->{items}->{item};
$item = [$item] if ref $item ne 'ARRAY';

my (%ips);
$ips{$_->{ip}} = $_->{full_name}||$_->{dns_name} for (@$item) ;

my $doneString = "";
if ($allowEdit && defined $co->param("values")) 
{
	
	$_->{'delete'} = 1 for (@{$blockedlist}); # mark all "delete" to remove items were removed by user with gui

	my @value = split /\|/, $co->param("values");
	for (@value)  
	{
		next if ! $_;
		my @arr = split /\*/, $_;
		for (@{$blockedlist})
		{
			if ($_->{ip} eq $arr[0])
			{
				for (my $i=0; $i<=$#$item; $i++)
				{
					if ($item->[$i]->{ip} eq $_->{ip} && $item->[$i]->{mac} ne $arr[1])
					{
						$item->[$i]->{mac} = $arr[1];
		    	   			$_->{changed} = 1;
						if ($item->[$i]->{mac} eq $_->{mac})
						{
							$item->[$i]->{enabled} = 1;
			    	   			$_->{'delete'} = 1;
                      				}
						else
						{
							$item->[$i]->{enabled} = 0;
			    	   			$_->{'delete'} = 0;
						}
					}
				}
			}
		}
	}
	for (my $i=0; $i<=$#$blockedlist; $i++)
	{    
		splice(@$blockedlist, $i--,1) if $blockedlist->[$i]->{'delete'};
	}
	saveConfigFile($ck{scfolder}.$ck{_ip_list}, $ip);
	run_twm_script("$ck{_ip_list_saver} m");
	$xml->{items} = {};
	$xml->{items}->{item} = $blockedlist;
	saveModuleConfigFile($cm{blocked_list}, $xml);
	$doneString = "Data are saved.".getWebDebugLog();
	keepHistory($title);
}

print <<__EOF;
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=values value="">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$doneString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=500>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=20></th>
    <th width=135>IP</th>
    <th width=170>Name</th>
    <th width=145>Known Mac</th>
    <th width=145>New Mac</th>
    <th width=100>&nbsp;</th>
  </tr>
__EOF


foreach (@$blockedlist)
{
	print_row($_, $item, $ips{$_->{ip}}) if $_;
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
}
print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 210px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Table shows all blocked hosts because of changed ip or mac address. 
"Known Mac" column shows registered host mac address in the TWM.
"New Mac" column shows new mac address of the same host (unregistered mac address in the TWM).
<br><br>
To apply new mac address need click Apply link and save changes. You can unblock access to internet 
in the "IP List" with cheking "Enable" checkbox and setting correct mac address but in this case blocked list 
will still have this ip temporarily. Unblocking in the "IP List" without defining new mac address has 
temporarily effect because unblocked ip will block again soon.
<br><br>
All registered mac addresses you can see in the "IP list" of TrafficPanel configuration.
</div>


</body>
</html>
__EOF

sub print_row
{
	my $trcolor = $_[0]->{changed} eq 1?"ffffff":"fafafa";
	$ip = $_[0]->{ip};
	my ($known_mac);
	for (@{$_[1]}){
		if ($_->{ip} eq $ip)
		{
			$known_mac = ref $_->{mac} eq 'HASH'?'':$_->{mac};
		}
	}
	my $name = ref $_[2] eq 'HASH'?'':$_[2];
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#$trcolor ><td
 align=center><a href="" onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a></td><td
 style="padding-left: 5px;"><span>$_[0]->{ip}</span><span style="display: none;"><input  class=control type=text name=fld1 value='$_[0]->{ip}' style='width: 135px;'></span></td><td
 style="padding-left: 5px;">$name</td><td
 style="padding-left: 5px;"><span><a href="" class=grid onClick="openItem(this); return false;">$known_mac</a></span><span style="display: none;"><input  class=control style="width: 135px;" type=text name=fld2 value='$known_mac'></span>&nbsp;</td><td
>$_[0]->{mac}</td><td
 align=middle><a href="#" class=grid onClick="applyNewMac(this); return false;">Apply</a></td></tr
>
__EOF
}
