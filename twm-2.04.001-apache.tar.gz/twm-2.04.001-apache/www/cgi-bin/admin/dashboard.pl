#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use File::Copy;
#use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $co = new CGI;

print "Content-Type: text/html\n\n";
print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<form name=f1 action="" method=post>
__EOF

my $xml = readConfigFile($ck{scfolder}.$ck{_ip_list});
my $version = &get_version_info;
my %modules = &getModules();

my $disk_usage = get_directory_size($ck{twmfolder});

my($registered_users,$reg_modules,$last_logged,$role,$username) = (0,0,'','','');
my $authkey = $1 if ($ENV{'HTTP_COOKIE'} && $ENV{'HTTP_COOKIE'} =~ /authkey=(\w+)?/);

open(FF,"$ck{twmfolder}/etc/passwd") or die "Can't open file $ck{twmfolder}/etc/passwd: $!";
while(<FF>) {
	chomp;
	/^(\w+):\w+:(\w+):\d+:(\w+):(\d+):([\w\s]+)$/;
	if ($1)   {
		$registered_users++;
		if($authkey eq $2) {
			$role = $3;
			$username = $5;
			$last_logged = localtime($4);
		}
    }
}
close(FF);

foreach(keys %modules) {
	$reg_modules++ if $modules{$_}->{enabled} eq 'true';
}
my $taskm_started = (stat($ck{task_manager_pid}))[10];
$taskm_started = localtime($taskm_started);

print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=760>
<tbody>
  <tr>
    <td>
	<div class=titlepage>Dashboard of system</div>
	<div style="padding-left: 10px;">
	</div>
    </td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p></p>

<div class="rowpanel">
<div class="leftpanel">
<div class="paneltitle"><span class="paneltitlerow">TrafficPanel information</span></div>
<div class="panelcontent">
<div class="panelcontentrow">

<br><div style='padding-left: 10px;'><u>TrafficPanel version: <b>$version->{version}</b></u></div><br>
<div style='padding-left: 10px;'>User name: $username</div>
<div style='padding-left: 10px;'>Role: $role</div>
<div style='padding-left: 10px;'>Last logged in: $last_logged</div>
<div style='padding-left: 10px;'>Registered users: $registered_users</div>
<div style='padding-left: 10px;'>Registered modules: $reg_modules</div>
<div style='padding-left: 10px;'>Task manager started at: $taskm_started</div>
<div style='padding-left: 10px;'>Disk usage: $disk_usage</div>

</div>
</div>
</div>

<div class="rightpanel">
<div class="paneltitle"><span class="paneltitlerow">Local network host</span></div>
<div class="panelcontent">
<div class="panelcontentrow">

<table cellpadding=1 cellspacing=0 border=0 width=360 style="table-layout: fixed;">
__EOF

my $ips = &getIPs;
foreach (@$ips)	{
	my ($used, $nick, $ip, $name, $mac, $enabled) = ($_->{used}, $_->{dns_name}, $_->{ip}, $_->{full_name}, $_->{mac}, $_->{enabled});
	my $color = $enabled eq 1?"":"color: #880000;";	

	if ($used eq 1)	{
		print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff>
    <td nowrap style='padding-left: 5px;'><a href="user_dashboard.pl?ip=$ip" class=grid style="$color">$ip&nbsp;&nbsp;&nbsp;&nbsp;$nick&nbsp;(&nbsp;$name&nbsp;)</a></td>
</tr>
__EOF
	}
}

print <<__EOF;
</table>

</div>
</div>
</div>


</div>
__EOF

my @modules;
for (keys %modules)
{
	next if ($modules{$_}->{enabled} ne 'true');
	next unless (-e "$ck{twmfolder}modules/$_/dashboard.pl");
	populateCfromConfig($_);
	next if (!exists($C->{$_}->{dashboard}) || !$C->{$_}->{dashboard});
	my $order = exists($C->{$_}->{dashboard_number})?$C->{$_}->{dashboard_number}:100;
	push @modules, {'order' => $order, 'module' => $_};
}

@modules = sort {$a->{order} <=> $b->{order}} @modules;

my $left = 1;
for my $module (@modules)
{
	my $res = getData([run_twm_script("dashboard.pl", $module->{module})]);
	my $data = $res->{data};
	for my $row (@$data)
	{
		next if !$row;
		print qq|<div class="rowpanel">\n|;
		if ($res->{cfg}->{fullrow})
		{
			print qq|<div class="fullpanel">\n|;
			$left = 1;
		}
		else
		{
			print qq|<div class="|.($left?'leftpanel':'rightpanel').qq|">\n|;
			$left = $left?0:1;
		}
		print qq|$row\n</div>\n</div>\n|;
	}
}

print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>

<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img src="/logout-off.png" width=13 height=13 border=0></a></td></tr>
</tbody>
</table>
</div>

</body>
</html>
__EOF


sub getData
{
	my $is_data = 0;
	my $data = '';
	my @res;
	my %cfg;
	my $rows = shift;
	my $boundary = '';
	for (@$rows)
	{
		chomp;
		if ($_ && !$is_data)
		{
			$cfg{$1} = $2 if /(.+?)=(.+)/;
			$boundary = $2 if ($1 eq 'boundary');
		}
		elsif (!$_ && !$is_data)
		{
			$is_data = 1;
		}
		elsif ($is_data && $boundary && $_ && $_ eq $boundary)
		{
			push @res, $data if $data;
			$data = '';
		}
		else
		{
			$data .= $_;
		}
	}
	push @res, $data;
	return {'cfg'=>\%cfg, 'data'=>\@res};
}


sub get_directory_size
{
	use File::Find;
	my $directory = shift;
	if (! -d $directory) { die "Directory expected as parameter." }
	my $size_total = 0;

	find({ follow => 0, wanted => sub {
		$size_total += -s $File::Find::name || 0;
		}}, $directory);

	$size_total = $size_total/1024**2;  # Mb
	my $rounded = sprintf("%.2f", $size_total);
	return $rounded.' Mb';
}

sub get_version_info
{
	my %info;
	open(VFILE, "$ck{twmfolder}/version.conf") || toError("Can not open version file: $!");
	while (<VFILE>)
	{
		chomp;
		next if !$_ || /^#/;
		$info{$1} = $2 if (/(.+)?\=(.+)/);
	}
	close(VFILE);
	return \%info;
}



__END__
