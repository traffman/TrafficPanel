#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use TrafficRouting;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
my $trafficRounting = TrafficRouting->new();

print "Content-Type: text/html\n\n";

my $co = new CGI;
my $title = "Custom routing";
my $ip_list = &getIPs;
my $ips = get_ip_name_hash($ip_list);
my $shaping_cbq_code = 'shaping_cbq';

my ($resultString, $new_item_prefix, $isp_name_js, $isp_inf_js) = ('', 'new_', "''", "''");
my (@errors, %ips, %isp_name);
my $isp_list = &getISP;
for(keys %$isp_list)
{
	if ($isp_list->{$_}->{attributes}->{default} eq '0' && $isp_list->{$_}->{attributes}->{internal} eq '0')
	{
		$isp_name{$isp_list->{$_}->{inf}} = $isp_list->{$_}->{code};
		$isp_name_js .= ",'$isp_list->{$_}->{code}'";
		$isp_inf_js .= ",'$isp_list->{$_}->{inf}'";
	}
}

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link rel="stylesheet" href="/twm.css">
<script src="/twm.js"></script>
</head>
<body>
<script>
function getNumber()
{
	var f = document.forms.f1;
	f.new_number.value = parseInt(f.new_number.value) + 1;
	return f.new_number.value;
}

function formValidate()	
{
	var f = document.forms.f1;
	f.submit();
	return false;
}


function addItem()	
{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber();
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = '<a href="" class=grid onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a>';
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.textAlign = "center";
	var isp_inf_js = new Array($isp_inf_js);
	var isp_name_js = new Array($isp_name_js);
	var str = "<select name=new_interface_"+num+" style='width: 100px'>";
	for (var i=1; i<isp_inf_js.length; i++)
	{
		str += "<option value='"+isp_inf_js[i]+"'>"+isp_name_js[i]+"</option>";
	}
	str += "</select>";
	td.innerHTML = str;
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = "<input class=control type=text name=new_ip_"+num+" value='' style='width: 100px;'>";
	tr.appendChild(td);

	var td = document.createElement("TD");
    td.innerHTML = "&nbsp;";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.textAlign = "center";
	//td.innerHTML = "<input class=control type=text name=new_port_"+num+" value='' style='width: 130px;'>&nbsp;<a href='#' onClick='openDPorts(event, this); return false;'>?</a>";
	td.innerHTML = "<input class=control type=text name=new_port_"+num+" value='' style='width: 130px;'>&nbsp;<a href='#' onClick='openDPorts(event, this); return false;'></a>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.textAlign = "center";
	var protos_js = new Array('${\(join("','",@{$trafficRounting->{protos}}))}');
	var str = "<select name=new_proto_"+num+" style='width: 50px'>";
	for (var i=0; i<protos_js.length; i++)
	{
		str += "<option value='"+protos_js[i]+"'>"+protos_js[i]+"</option>";
	}
	str += "</select>";
	td.innerHTML = str;
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.textAlign = "center";
	td.innerHTML = "<input class=control type=text name=new_description_"+num+" value='' style='width: 180px;'>";
	tr.appendChild(td);

	obj.appendChild(tr);
}


var activeObject;
function openDPorts(e, obj)	
{
	if (!e)
		e = window.event;
	var d = document.getElementById("dports");
	d.style.left = parseInt(e.clientX) - parseInt(d.style.width);
	d.style.top = parseInt(e.clientY) + 15;
	d.style.display = 'inline';
	activeObject = obj.parentNode.childNodes[0];
}


function closeDPorts()	
{
	var d = document.getElementById("dports");
	d.style.display = 'none';
	activeObject = null;
}

function setPort(obj)	
{
	if (obj.name == "skype")	
	{
		activeObject.value = "1024:65535";
		activeObject.parentNode.parentNode.childNodes[4].childNodes[0].value = 'tcp';
		addPopulatedRow('*','udp');
	}
	else if (obj.name == "gt")	
	{
		activeObject.value = "80,443,5222,19294";
		activeObject.parentNode.parentNode.childNodes[4].childNodes[0].value = 'tcp';
		addPopulatedRow('*','udp');
	}
	closeDPorts();
}


function addPopulatedRow(p1,p2)	
{
	addItem();
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = obj.childNodes[obj.childNodes.length-1];
	tr.childNodes[1].childNodes[0].value = obj.childNodes[obj.childNodes.length-2].childNodes[1].childNodes[0].value;
	tr.childNodes[2].childNodes[0].value = obj.childNodes[obj.childNodes.length-2].childNodes[2].childNodes[0].value;
	tr.childNodes[3].childNodes[0].value = p1;
	tr.childNodes[4].childNodes[0].value = p2;
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF

if ($allowEdit && defined $co->param("max_number"))
{
	my $proto_str = $trafficRounting->get_proto_string();

	my (@run_string, $prefix);
	my $max_number = $co->param("max_number") || 0;
	my $new_number = $co->param("new_number") || 0;

	for (my $i=0; $i<=$max_number; $i++)
	{
		$prefix = '';
		my ($port, $proto, $if, $decs, $ip, $service) = ($co->param("${prefix}port_$i"), $co->param("${prefix}proto_$i"), $co->param("${prefix}interface_$i"), $co->param("${prefix}description_$i"), $co->param("${prefix}ip_$i"), $co->param("${prefix}service_$i"));
		if ($ip && $proto && $if && !exists($ips{"$port, $proto, $if, $ip"}))
		{
			$ips{"$port, $proto, $if, $ip"} = [$port, $proto, $if, $decs, $ip, $service];
		}
	}
	for (my $i=1; $i<=$new_number; $i++)
	{
		$prefix = $new_item_prefix;
		my ($port, $proto, $if, $decs, $ip) = ($co->param("${prefix}port_$i"), $co->param("${prefix}proto_$i"), $co->param("${prefix}interface_$i"), $co->param("${prefix}description_$i"), $co->param("${prefix}ip_$i"));
		next if ("$port$proto$if$decs$ip" eq '');

		push @errors, "Incorrect port number <b>$port</b>" if ($port && $port !~ /^[\d\:\*]+$/);
		push @errors, "Incorrect isp interface <b>$if</b>" if (!exists($isp_name{$if}));
		push @errors, "Dublicate row." if (exists($ips{"$port, $proto, $if, $ip"}));
		push @errors, "Incorret proto <b>$proto</b>" if ($proto && $proto !~ /$proto_str/);
		push @errors, "Incorret ip <b>$ip</b>" if ($ip !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);

		$ips{"$port, $proto, $if, $ip"} = [$port, $proto, $if, $decs, $ip, ''];
		push @run_string, "$cm{rule_processor} start $if $ip '$port' $proto";
	}

	if ($#errors == -1)
	{
		my $xml = readModuleConfigFile($cm{rules});
		my $list = (ref $xml->{rule} eq 'HASH')?[$xml->{rule}]:$xml->{rule};
		for (@$list)
		{
			if (!exists($ips{"$_->{port}, $_->{proto}, $_->{interface}, $_->{ip}"}))
			{
				push @run_string, "$cm{rule_processor} stop $_->{interface} $_->{ip} '$_->{port}' $_->{proto}";
			}
		}

		$xml = undef;
		for (keys %ips)
		{
			push @{$xml->{rule}}, getNewItem($ips{$_});
		}
		saveModuleConfigFile($cm{rules}, $xml);
		for (@run_string)
		{
			keepHistory($_, __FILE__);
			run_twm_script($_, $mc);
			$resultString .= getWebDebugLog(); 
		}
		%ips = ();
	}
	else
	{
		$resultString .= "<div style='padding-left: 10px;'>".join("<br>\n", @errors)."</div>";
	}

}

print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$resultString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=750>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
	<th width=110>ISP</th>
	<th width=110>IP</th>
	<th width=220>Name</th>
    <th width=150>Port</th>
    <th width=60>Proto</th>
    <th width=220>Description</th>
  </tr>
__EOF

my $ip_list = &getIPs;
my $ips = get_ip_name_hash($ip_list);

my $max_number = 0;
my $xml = readModuleConfigFile($cm{rules});
my $list = (ref $xml->{rule} eq 'HASH')?[$xml->{rule}]:$xml->{rule};

printRow($_, ++$max_number, '', $ips->{$_->{'ip'}}) for (@{sortIPs($list)});

my $new_number = 0;
printRow(getNewItem($ips{$_}), ++$new_number, $new_item_prefix, $ips->{$_->{'ip'}}) for keys %ips;

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
<input type=hidden name=max_number value="$max_number">
<input type=hidden name=new_number value="$new_number">
</form>

<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This page shows all defined traffic routing criteria and allows create new custom.
To create new one you need set
<li>ISP to go traffic through
<li>local network host IP that traffic will be routed
<li>port will be routed
<li>protocol will be routed
<li>description is not required. By default it is service name if criterion came from service.

</div>
</body>
</html>
__EOF

sub printRow
{
	my ($row, $i, $prefix, $name) = (shift, shift, shift, shift);

	$row->{service} = '' if ref $row->{service} eq 'HASH';
	$row->{description} = '' if ref $row->{description} eq 'HASH';
	my $description = ($row->{service} && !$row->{description})?"[Service: $row->{service}]":$row->{description};
	my ($txt_display, $input_display) = ('', 'none');
	($txt_display, $input_display) = ('none', '') if ($prefix);

	print <<__EOF;
<input type=hidden name=${prefix}service_$i value='$row->{service}'>
<tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$i"><td
 align=center><a href="" onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a></td><td
 align=center><span style="display: $txt_display;">$isp_name{$row->{interface}}</span><span style='display: $input_display;'>${\(getISPSelect($row->{interface}, "${prefix}interface_$i"))}</span></td><td
 align=center><span style="display: $txt_display;">$row->{ip}</span><span style='display: $input_display;'><input type=text name=${prefix}ip_$i class=control value="$row->{ip}" style="width: 100px;"></span></td><td
 align=left><span style="display: $txt_display;">&nbsp;$name</span><span style='display: $input_display;'></span></td><td
 align=center><span style="display: $txt_display;">$row->{port}</span><span style='display: $input_display;'><input type=text name=${prefix}port_$i class=control value="$row->{port}" style="width: 130px;"></span></td><td
 align=center><span style="display: $txt_display;">$row->{proto}</span><span style='display: $input_display;'>${\($trafficRounting->getProtosSelect($row->{proto}, "${prefix}proto_$i"))}</span></td><td
 align=center><span style="display: $txt_display;">$description</span><span style="display: $input_display;"><input class=control type=text name=${prefix}description_$i value='$row->{description}' style='width: 180px;'></span></td></tr>
__EOF

}

sub getISPSelect
{
	my ($inf, $name) = (shift, shift);
	my $str = "<select style='width: 100px;' name=$name class=control>";
	foreach (keys %isp_name)
	{
		$str .= "<option value='$_' ${\(setSelected($inf, $_))}>".$isp_name{$_};
	}
	$str .= '</select>';
	$str;
}

sub getNewItem
{
	return {
		'port' => $_[0]->[0],
		'proto' => $_[0]->[1],
		'interface' => $_[0]->[2],
		'description' => $_[0]->[3],
		'ip' => $_[0]->[4],
		'service' => $_[0]->[5]
	};
}

__END__
