#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use IPLimit;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

my $objIPLimit = IPLimit->new();
my $allowEdit = &hasManagerAccess;
print "Content-Type: text/html\n\n";
my $co = new CGI;
my $title = "Current State";
my $ip_list = &getIPs;
my $ips = get_ip_name_hash($ip_list);
my $doneString = '';

if ($co->param('clear') && $co->param('clear') eq 'Clear log')
{
	run_twm_script("$cm{daemon} clear",$mc);
	$doneString .= 'HTTP amount log will be cleared in few seconds.'.getWebDebugLog();
	keepHistory("HTTP amount log is cleared");
}

my $status = join("", run_script("$ck{ps} ax | $ck{grep} 'httpr_sl.pl' | $ck{grep} -v grep | $ck{wc} -l"));
chomp $status;
$status = $status?'':'<br><b><font size=3 color=#FF0000>Daemon is down. "Clear log" to start it.</font></b><br><br>';


print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
<script src="/http_post.js"></script>
<script>
function customOvrMouse(obj)
{
	obj.childNodes[4].childNodes[1].style.visibility = "visible";
}
function customOutMouse(obj)
{
	obj.childNodes[4].childNodes[1].style.visibility = "hidden";
}

function resetItem(obj, ip)
{
	var statusObj = obj.parentNode.childNodes[0];
	var httpp = new HTTPPost();
	httpp.postData('reset_ip.pl', 'ip='+ip, checkedHandler);

	function checkedHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status != 'true')
				{
					obj.checked = !obj.checked;
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
				else
				{
					statusObj.innerHTML = '';
					statusObj.parentNode.parentNode.childNodes[3].innerHTML = '0.0';
				}
			}
		}
	}
}
</script>

<script src="/http_post.js"></script>
<script>
function restartSquid()
{
	if (!confirm("Squid restarting takes up to few minutes. Continue?"))
		return
	var httpp = new HTTPPost();
	httpp.postData('../http_logging/squid.pl', '', checkedHandler);
	function checkedHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status != 'true')
				{
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
				else
				{
					alert('Squid has been restarted');
				}
			}
		}
	}
}
</script>

</head>
<body>
<form>
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
$status
<p>
Default amount size: ${\$cm{default_amount}} Mb
<input type=submit name="clear" value="Clear log" class=control style="margin-left: 10px; margin-right: 276px;">
<input type=button name=restart_squid value="Restart Squid" class=control style='width: 100px;' onclick="restartSquid();">
</p>
<p><small>$doneString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=400>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=145>IP</th>
    <th width=190>Name</th>
    <th width=90>Available (Mb)</th>
    <th width=65>Used (Mb)</th>
    <th width=65>Blocked</th>
  </tr>
__EOF

my $blockedlist = $objIPLimit->get_blocked_list();

my $xml = &readModuleConfigFile($cm{restriction_file});
my $areas = $xml->{'pc'};
$areas = [$areas] if ref $areas eq 'HASH';

my %usedTraffic = %{$objIPLimit->load_total()};

for (@$ip_list) 
{
	print_row($_->{ip}, $usedTraffic{$_->{ip}}) if $usedTraffic{$_->{ip}};
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see the current http traffic amount state per ip and the blocked state. A blocked ip means disabled http traffic.
To unblock the ip and enable http traffic you need to set http traffic limit as exceeding the amount. Just enabling http traffic does not make any sense because traffic amount will still exceed the limit and the next http request will disable it again.
</div>

</form>
</body>
</html>
__EOF


sub print_row
{
	my $available = get_available_value($areas, $_[0]);
	my ($trcolor, $status) = ("ffffff", '');
	($trcolor, $status) = ("f5f5f5", 'Yes') if in_array($blockedlist,$_[0]);
	my $reset_str = $allowEdit?qq|<a href="" class=grid onClick='resetItem(this,"$_[0]");return false' style="padding-left: 5px; visibility: hidden;">Reset</a>|:'';
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this); customOvrMouse(this);" onmouseout="outMouse(this); customOutMouse(this);" bgcolor=#$trcolor
    ><td>&nbsp;$_[0]</td
    ><td>&nbsp;$ips->{$_[0]}</td
    ><td align=right>&nbsp;$available</td
    ><td align=right>${\getHumanTrafficNumber($_[1], 'm')}</td
    ><td align=center><span>$status</span>$reset_str</td>
  </tr>
__EOF
}


sub get_available_value
{
	foreach (@{$_[0]})
	{
		return $_->{size} if ($_->{ip} eq $_[1]);
	}
	return $cm{default_amount};
}
