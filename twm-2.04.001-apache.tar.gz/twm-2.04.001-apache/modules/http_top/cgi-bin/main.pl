#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
    unshift(@INC, $file);
}

use strict;
use TWM;
use CGI;
use Switch 'fallthrough';
use Logging;

if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}
&checkAuthorization;
my $logging = new Logging;
my $co = new CGI;

populateCfromConfig($logging->{this_module_code});
my $squids = $logging->getSquidsSettings();
my $squid = $co->param('squid')||[values %$squids]->[0]->{isp};
my $description = &getModuleInfo->{name};
my $http_logging = "http_logging";

print "Content-Type: text/html\n\n";

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<div id='logsSelector' style='padding-left: 10px; padding-top: 10px; height: 50px;' >
<table cellpadding=0 cellspacing=0 border=0 width=90%>
<tbody>
  <tr>
    <td class=titlepage>$description</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
Show report for: <select name=squid class=control onChange="document.location.replace('main.pl?squid='+this.value);">
__EOF

for my $v (values %$squids)
{
	print "<option value=$v->{isp} ${\(setSelected($v->{isp}, $squid))}>$v->{isp}</option>\n";
}

print <<__EOF;
</select>  <select id='logs' name='logs' onChange='onChangeLogs(this)' class=control>
__EOF

my ($lastValue, $existfiles);
my @logdirs = map {s/\.\.\/logs\/$squid\///; $_;} <../logs/$squid/*>;

if (scalar(@logdirs))	{
	foreach (@logdirs)
	{
		if (/^(\d{4})(\w{3})(\d{2})-(\d{4})(\w{3})(\d{2})$/)
		{
			$existfiles .= $_."|";
			$lastValue = "sarg_rpt.pl?squid=$squid&dt=$_" if (!$lastValue);
			print "<option value='sarg_rpt.pl?squid=$squid&dt=$_'>$3 $2 $1-$6 $5 $4</option>";
	    }
	}
}
else	{
	my $dtstart = `/bin/date +%Y-%b-%d`;
	chomp $dtstart;
	$lastValue = "sarg_rpt.pl?squid=$squid&dt=$dtstart-$dtstart" if (!$lastValue);
}

print "$existfiles|";

my @files = glob $ck{twmfolder}."modules/http_top/logs/*.tgz";
foreach my $file (@files)
{
	if($file =~ /\/logs\/$squid\/(.+)\.tgz/)
	{
		my $tmpfilename = $1;
		if ($existfiles !~/$1/ && $1 =~ /^(\d{4})(\w{3})(\d{2})-(\d{4})(\w{3})(\d{2})$/)
		{
			$existfiles .= $tmpfilename."|";
			print "<option style='color:Red;' value='sarg_rpt.pl?squid=$squid&dt=${\$tmpfilename}.tgz'>$3 $2 $1-$6 $5 $4</option>";
		}
	}
}

print <<__EOF;
</select>
</div>
<script>
function onChangeLogs(item)
{ 
  var frame=document.getElementById('content'); 
  if (frame != null)
  { 
    frame.src=item.value;
  }
}

function setSize()
{
	var c = document.getElementById("content");
	c.style.height = (document.body.clientHeight - document.getElementById("logsSelector").clientHeight)+'px';
	c.style.width = (document.body.clientWidth - 5)+'px';
	c.style.display = 'block';
}

window.onresize = setSize;
window.onload = setSize;
</script>
<iframe id='content' name='content' src='$lastValue'  marginheight=0 scrolling=auto marginwidth=0 frameborder=0  style='z-index:999; width:100%; height:100%; display: none;'></iframe>

<div class=help style="width: 400px; height: 110px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see top $cm{top_sites} popularity web resources based on traffic through proxy server per ISP and specified period.
</div>

</body>
</html>
__EOF

sub month_switch 
{
  return 'December' if ($_[0] eq 'Dec');
  return 'November' if ($_[0] eq 'Nov');
  return 'October' if ($_[0] eq 'Oct');
  return 'September' if ($_[0] eq 'Sep');
  return 'August' if ($_[0] eq 'Aug');
  return 'July' if ($_[0] eq 'Jul');
  return 'June' if ($_[0] eq 'Jun');
  return 'May' if ($_[0] eq 'May');
  return 'April' if ($_[0] eq 'Apr');
  return 'March' if ($_[0] eq 'Mar');
  return 'February' if ($_[0] eq 'Feb');
  return 'January' if ($_[0] eq 'Jan');
}

__END__
