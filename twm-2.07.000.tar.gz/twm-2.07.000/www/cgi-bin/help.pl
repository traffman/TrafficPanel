#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
    unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}
my $twm_cgi = '/cgi-bin';

&checkAuthorization;
my $allowEdit = &hasAdminAccess;

print "Content-Type: text/html\n\n";
my $co = new CGI;
my $module_name = $co->param('module') || "";
my $context = $co->param('context') || "help";
my $file = "$ck{cgfolder}$context";
$file = "$ck{twmfolder}modules/$module_name/$context" if ($module_name);
my $text = "Could not find '$context' file";

if (-e "$file.txt")
{
	open(FILE, "$file.txt") or die "Can not open file $file.txt: $!";
	$text = "<pre>".join("",<FILE>)."</pre>";
	close(FILE);
}
elsif (-e "$file.html")
{
	open(FILE, "$file.html") or die "Can not open file $file.html: $!";
	$text = join("",<FILE>);
	close(FILE);
}
elsif (-e "$file.htm")
{
	open(FILE, "$file.htm") or die "Can not open file $file.htm: $!";
	$text = join("",<FILE>);
	close(FILE);
}

if ($text =~ /\[__pages__\]/)
{
	my $pages = '';
	my $xml = getModuleInfo($module_name);
	my $branch = $xml->{html_tree};
	if (exists($branch->{branch}))
	{
		$branch = getLastBranch($branch);
	}
	if (ref $branch->{items} eq 'HASH')
	{
		my $items = getBranch($branch->{items}->{item});
		foreach (@$items)
		{
			my $d = $_->{description} && $_->{description} ne 'HASH'?" - $_->{description}":'';
			$pages .= "<li><a href='$twm_cgi/modules/$module_name/$_->{script}'>$_->{label}</a> $d</li>\n";
		}
	}
	$pages = "<ul>\n$pages</ul>\n";
	$text =~ s/\[__pages__\]/$pages/;
}

$context =~ s/\b(\w)(\w*)/\U$1\L$2/g;

print <<__EOF;
<html>
<head>
<title></title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<form name=f1 action="" method=post>
<input type=hidden name=module value='$module_name'>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<div class=titlepage>$context</div>
<br>
<div>
$text
</div>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
__EOF


sub getBranch
{
	my $items = shift;
	return [sort {$a->{ordering}<=>$b->{ordering}} @{$items}];
}

sub getLastBranch
{
	my $b = shift;
	if (ref $b->{items} ne 'HASH')
	{
		$b = getLastBranch($b->{branch});
	}
	return $b;
}