#!/usr/bin/perl -w

# this script used to set total tcp traffic restriction

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use TrafficLogging;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $trafficLogging = TrafficLogging->new();
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
my $title = "TCP traffic restriction by size";

print "Content-Type: text/html\n\n";

my $ip_list = &getIPs;
my $isblocked = $trafficLogging->get_blocked($ip_list);

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
<script src="/http_post.js"></script>
</head>
<body>
<script>
function formValidate() {
  deleteMarkedRows();
  var f = document.forms.f1;
  var obj = document.getElementsByTagName("INPUT");
  f.values.value = "";
  for (var i=0; i<obj.length; i++)  {
    if (obj[i].getAttribute("name") == "fld1")  {
      f.values.value += "|"+obj[i].value;
    }
    if (obj[i].getAttribute("name") == "fld2")  {
      f.values.value += "*"+obj[i].value;
    }
  }
  f.submit();
  return false;
}

function addItem()  
{
  var obj = document.getElementById("cTable").tBodies[0];
  var tr = document.createElement("TR");
  tr.height = 22;
  tr.style.backgroundColor = "#ffffcc";
  tr.onmouseover = function() {ovrMouse(this);};
  tr.onmouseout = function()  {outMouse(this);};
  var td = document.createElement("TD");
  td.allign = "middle";
  td.innerHTML = "<a href='' onClick='delItem(this); return false'><img src='/delete.gif' border=0/></a>";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.innerHTML = "<input class=control type=text name=fld1 value='' style='width: 135px;'>";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;<input class=control style='text-align: right; width: 54px;' type=text name=fld2 value=''>&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);
  var td = document.createElement("TD");
  td.align = "right";
  td.innerHTML = "&nbsp;";
  tr.appendChild(td);

  obj.appendChild(tr);
  tr.childNodes[1].childNodes[0].focus();
 
}

function openItem(obj)  {
  obj.parentNode.parentNode.parentNode.childNodes[3].childNodes[1].style.display = "none";
  obj.parentNode.parentNode.parentNode.childNodes[3].childNodes[2].style.display = "inline";
  obj.parentNode.parentNode.parentNode.childNodes[7].childNodes[1].style.display = "none";
  obj.parentNode.parentNode.parentNode.childNodes[7].childNodes[2].style.display = "inline";
}


function customOvrMouse(obj)
{
	obj.childNodes[11].childNodes[1].style.visibility = "visible";
}
function customOutMouse(obj)
{
	obj.childNodes[11].childNodes[1].style.visibility = "hidden";
}

function resetItem(obj, ip)
{
	var statusObj = obj.parentNode.childNodes[0];
	var httpp = new HTTPPost();
	httpp.postData('reset_ip.pl', 'ip='+ip, checkedHandler);

	function checkedHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status != 'true')
				{
					obj.checked = !obj.checked;
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
				else
				{
					statusObj.innerHTML = '';
					statusObj.parentNode.parentNode.childNodes[9].innerHTML = '0.0';
				}
			}
		}
	}
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=values value="">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF

my $doneString = "";

if ($allowEdit && defined $co->param("values"))
{
	my @value = split /\|/, $co->param("values");
	my $ips;
	for (@value)  
	{
		next if ! $_;
		if (/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\*(\d+)/)  
		{
			my ($ip, $size) = ($1, $2);
			my $isexist = 0;
			foreach($ips->{pc})
			{
				$isexist = 1 if ($_ && $_->[0]->{ip} eq $ip);
			}
			if ($isexist eq 1)  
			{
				$doneString .= "<br>Duplicate IP: $ip. Ignore second data.";
			}
			else 
			{
				push @{$ips->{pc}}, {ip=>$ip, size=>$size};
			}
		}
		else 
		{
			$doneString .= "<br> Incorrect data: $_";
		}
	}
	saveModuleConfigFile($cm{tcp_limit}, $ips);
	$doneString = "Data are saved.$doneString";
	keepHistory($title);
}

  print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>TCP limits</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
Default restriction size : ${\$cm{default_size}} Mb
<p><small>$doneString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=500>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=145>IP</th>
    <th width=180>Name</th>
    <th width=90>Available (Mb)</th>
    <th width=100>Used (Mb)</th>
    <th width=65>&nbsp;</th>
  </tr>
__EOF

my $interfaces = $trafficLogging->get_ext_interfaces();
my $report_file = $trafficLogging->get_report_filename();
my $dtstart = "$1$2$3" if $report_file =~ /(\d{4})(\d\d)(\d\d)/;
$trafficLogging->populate_report($dtstart, $dtstart, $report_file);

my $ips = get_ip_name_hash($ip_list);
my $xml = readModuleConfigFile($cm{tcp_limit});
my $areas = $xml->{'pc'};
$areas = [$areas] if $areas && ref $areas ne 'ARRAY';
$areas = sortIPs($areas);

foreach (@$areas)
{
	my $total = $trafficLogging->traffic_count(0, $interfaces, $_->{ip}, '');
	print_row($_, $ips->{$_->{ip}}, $isblocked->{$_->{ip}}, $total);
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
}
print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can set a total daily amount of available tcp traffic per ip to/from Internet. You can set the default value of available traffic in the configuration module.  
For unlimited tcp traffic just set a high value, for example 100 000 (100Gb).
Every midnight the amount of used tcp traffic is set to zero and calculation starts again.
</div>


</body>
</html>
__EOF


sub print_row
{
	my ($trcolor, $status) = ("ffffff","");
	($trcolor, $status) = ("f5f5f5", 'Blocked') if ($_[2] && $_[2] eq 1);
	my $reset_str = $allowEdit?qq|<a href="" class=grid onClick='resetItem(this,"$_[0]->{ip}");return false' style="padding-left: 5px; visibility: hidden;">Reset</a>|:'';
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this); customOvrMouse(this);" onmouseout="outMouse(this); customOutMouse(this);" bgcolor=#$trcolor >
    <td align=middle width=10><a href="" onClick='mark2DelItem(this);return false' style="visibility: hidden;"><img src="/delete.gif" border=0/></a></td>
    <td>&nbsp;<span><a href="" class=grid onClick="openItem(this); return false;">$_[0]->{ip}</a></span><span style="display: none;"><input  class=control type=text name=fld1 value='$_[0]->{ip}' style='width: 135px;'></span></td>
    <td>&nbsp;${\($_[1] || '')}</td>
    <td align=right>&nbsp;<span><a href="" class=grid onClick="openItem(this); return false;">$_->{size}</a></span><span style="display: none;"><input  class=control style="text-align: right; width: 54px;" type=text name=fld2 value='$_[0]->{size}'></span>&nbsp;</td>
    <td align=right>${\(getHumanTrafficNumber($_[3], 'm'))}&nbsp;</td>
    <td align=center><span>$status</span>$reset_str</td>
  </tr>
__EOF
}
