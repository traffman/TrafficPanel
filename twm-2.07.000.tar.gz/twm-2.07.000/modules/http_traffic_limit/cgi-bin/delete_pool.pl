#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
print "Content-Type: text/xml\n\n";
my $co = new CGI;
my $name = $co->param('name');

my $allowEdit = &hasAdminAccess;
my $xml = &readModuleConfigFile($cm{pool});
my ($status, $message) = ('true', '');
if ($allowEdit && ref $xml->{pool} eq 'HASH')
{
	if (exists($xml->{pool}->{name}) && $name eq $xml->{pool}->{name})
	{
		$xml->{pool} = ();
	}
	else
	{
		if (exists($xml->{pool}->{$name}))
		{
			delete $xml->{pool}->{$name};
		}
		else
		{
			($status, $message) = ('false', 'Pool file was not found');
		}
	}
}
elsif (!$allowEdit)
{
	($status, $message) = ('false', 'Access denied');
}
else
{
	($status, $message) = ('false', 'Pool list is empty');
}

if ($status eq 'true')
{
	saveModuleConfigFile($cm{pool}, $xml);
	keepHistory("Deleted pool $name");
	run_twm_script($cm{db_compiler}, $mc, 1);
}

print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
