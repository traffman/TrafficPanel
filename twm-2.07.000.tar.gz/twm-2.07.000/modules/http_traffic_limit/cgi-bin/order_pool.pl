#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
use TrafficLimit;
$ck{print_stdout} = 0;
&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $objTrafficLimit = TrafficLimit->new();
print "Content-Type: text/xml\n\n";
my $co = new CGI;
my $name = $co->param('name');
my $up = $co->param('up');
my $down = $co->param('down');

my $xml = &readModuleConfigFile($cm{pool});
my @sorted = $objTrafficLimit->convertPool2Array($xml);

my ($status, $message) = ('true', '');
my $found = 0;
if ($allowEdit)
{
	for (my $i=0; $i<=$#sorted; $i++)
	{
		if ($sorted[$i]->{name} eq $name)
		{
			$found = 1;
			if ($up)
			{
				if ($i == 0)
				{
					($status, $message) = ('false', 'It is first already');
					last;
				}
				my $order = $sorted[$i]->{order};
				$sorted[$i]->{order} = $sorted[$i-1]->{order};
				$sorted[$i-1]->{order} = $order;
			}
			elsif ($down)
			{
				if ($i == $#sorted)
				{
					($status, $message) = ('false', 'It is last already');
					last;
				}
				my $order = $sorted[$i]->{order};
				$sorted[$i]->{order} = $sorted[$i+1]->{order};
				$sorted[$i+1]->{order} = $order;
			}
			last;
		}
	}

	if (!$found)
	{
		($status, $message) = ('false', 'Item was not found');
	}
}
else
{
		($status, $message) = ('false', 'Access denied');
}

if ($status eq 'true')
{
	$xml->{pool} = \@sorted;
	saveModuleConfigFile($cm{pool}, $xml);
	keepHistory("Reordered pools $name");
	run_twm_script($cm{db_compiler}, $mc, 1);
}

print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
