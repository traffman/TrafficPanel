#!/usr/bin/perl -w

BEGIN	
{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use TWM;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
print "Content-Type: text/html\n\n";
my $twm_htdocs_folder = "";
my $twm_cgi = "/cgi-bin";
my %modules = &getModules();

print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/http_post.js"></script>
<script>
function checkedItem(obj)
{
	var httpp = new HTTPPost();
	httpp.postData('enable_module.pl', 'code='+obj.parentNode.parentNode.getAttribute("module")+'&enable='+(obj.checked?1:0), checkedHandler);

	function checkedHandler(req)
	{
		if (req.readyState == 4)	
		{
			if (req.status && req.status == 200 && req.responseXML && req.responseXML.documentElement)
			{
				var status = getXMLData(req.responseXML.documentElement.getElementsByTagName('status'));
				if (status != 'true')
				{
					obj.checked = !obj.checked;
					alert(getXMLData(req.responseXML.documentElement.getElementsByTagName('message')));
				}
			}
		}
	}
}
</script>
</head>
<body>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="padding: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=700>
<tbody>
  <tr height=30>
    <td class=titlepage>Modules</td>
    <td align=right><a class=help href="" onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<br>
<table cellspacing=0 cellpadding=0 width=700>
  <tr class=tableborder>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th>Code</th>
    <th>Name</th>
    <th>Full Name</th>
    <th width=50>Enabled</th>
  </tr>
__EOF

my $i = 0;
for (sort keys %modules)
{
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff module="$_">
    <td>&nbsp;$_</td>
    <td>&nbsp;$modules{$_}->{name}</td>
    <td>&nbsp;$modules{$_}->{full_name}</td>
__EOF

if ($allowEdit)
{
	print <<__EOF;
    <td align=middle><input type=checkbox name=chk value=0 ${\($modules{$_}->{enabled} eq 'true'?'checked':'')} onclick="checkedItem(this);"></td>
__EOF
}
else
{
	print <<__EOF;
    <td align=middle>${\($modules{$_}->{enabled} eq 'true'?'yes':'no')}</td>
__EOF
}
	print <<__EOF;
  </tr>
__EOF
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>

<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see list of installed modules. Module can be disabled with unchecking "Enabled".
</div>


</body>
</html>
__EOF
