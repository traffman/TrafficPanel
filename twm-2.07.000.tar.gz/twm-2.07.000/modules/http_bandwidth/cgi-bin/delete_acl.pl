#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
use Bandwidth;
$ck{print_stdout} = 0;

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
my $name = $co->param('name');
my $objBandWidth = Bandwidth->new();

print "Content-Type: text/xml\n\n";
my $xml = &readModuleConfigFile($cm{classes_config});

my ($status, $message) = ('true', '');
if ($allowEdit && ref $xml->{acl} eq 'HASH')
{
	if (exists($xml->{acl}->{name}) && $name eq $xml->{acl}->{name})
	{
		if ($xml->{acl}->{readonly} eq 'false')
		{
			deleteACLFromPool($name);
			$xml->{acl} = ();
		}
		else
		{
			($status, $message) = ('false', 'You can not remove readonly acl class');
		}
	}
	else
	{
		if (exists($xml->{acl}->{$name}))
		{
			if ($xml->{acl}->{$name}->{readonly} eq 'false')
			{
				deleteACLFromPool($name);
				delete $xml->{acl}->{$name};
			}
			else
			{
				($status, $message) = ('false', 'You can not remove readonly acl class');
			}
		}
		else
		{
			($status, $message) = ('false', 'ACL file was not found');
		}
	}
}
elsif (!$allowEdit)
{
	($status, $message) = ('false', 'Access denied');
}
else
{
	($status, $message) = ('false', 'ACL list is empty');
}

if ($status eq 'true')
{
	$objBandWidth->saveClass($xml, 1);
	keepHistory("Deleted $name:\n".Dumper($xml));
}

print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF


sub deleteACLFromPool
{
	my $xml = &readModuleConfigFile($cm{pools_config});
	if (ref $xml->{pool} eq 'HASH')
	{
		if (exists($xml->{pool}->{name}))
		{
			my $content = $xml->{pool}->{content};
			deleteACLFromContent($xml->{pool}->{content}, $_[0]);
		}
		else
		{
			for my $key (keys %{$xml->{pool}})
			{
				deleteACLFromContent($xml->{pool}->{$key}->{content}, $_[0]);
			}
		}
	}
#print Dumper $xml;
	$objBandWidth->savePool($xml, 1);
}

sub deleteACLFromContent
{
	if (exists($_[0]->{name}))
	{
		$_[0] = {} if ($_[0]->{name} eq $_[1]);
	}
	else
	{
		for my $key (keys %{$_[0]})
		{
			delete $_[0]->{$key} if ($key eq $_[1]);
		}
	}
}
