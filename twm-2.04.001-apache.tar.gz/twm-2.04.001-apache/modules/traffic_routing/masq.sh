#!/bin/sh

masquearading="$TWMFOLDER/modules/traffic_routing/masquearading.sh"
if [ -e $masquearading ]; then
	rm $masquearading
fi

perl $TWMFOLDER/modules/traffic_routing/masq.pl
if [ -e $masquearading ]; then
	$masquearading
fi

