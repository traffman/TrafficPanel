#!/usr/bin/perl -w

# this script used to set total tcp traffic restriction

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use Data::Dumper;
use TrafficRouting;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
&checkAuthorization;
my $trafficRounting = TrafficRouting->new();
my $allowEdit = &hasAdminAccess;
my $co = new CGI;
my $title = "Services Confiruration";
my $resultString = "";
my (%list, @errors);

print "Content-Type: text/html\n\n";

if ($allowEdit && defined $co->param("max_number"))
{
	my $proto_str = $trafficRounting->get_proto_string();
	my $max_number = $co->param("max_number") || 0;
	for (my $i=1; $i<=$max_number; $i++)
	{
		my ($name, $proto, $port, $shaper_class) = ($co->param("name_$i"), $co->param("proto_$i"), $co->param("port_$i"), $co->param("shaper_class_$i"));
		push @errors, "Incorrect port number <b>$port</b>" if ($port && $port !~ /^[\d\:\*\,\s]+$/);
		push @errors, "Incorret proto <b>$proto</b>" if ($proto && $proto !~ /$proto_str/);
		if ($#errors == -1 && $name && $proto && $port)
		{
			push @{$list{$name}}, [$name, $proto, $port, $shaper_class];
		}	
	}

	my $new_number = $co->param("new_number") || 0;
	for (my $i=1; $i<=$new_number; $i++)
	{
		my ($name, $proto, $port, $shaper_class) = ($co->param("new_name_$i"), $co->param("new_proto_$i"), $co->param("new_port_$i"), $co->param("new_shaper_class_$i"));
		push @errors, "Incorrect port number <b>$port</b>" if ($port && $port !~ /^[\d\:\*\,\s]+$/);
		push @errors, "Incorret proto <b>$proto</b>" if ($proto && $proto !~ /$proto_str/);
		if ($#errors == -1 && $name && $proto && $port)
		{
			push @{$list{$name}}, [$name, $proto, $port, $shaper_class];
		}	
	}
	if ($#errors == -1)
	{
		my $xml = undef;
		for (keys %list)
		{
			push @{$xml->{service}}, getNewItem($list{$_});
		}
		saveModuleConfigFile($cm{services_conf}, $xml);
		keepHistory($title);
		$resultString .= 'Data are saved.';
	}
	$resultString .= "<div style='padding-left: 10px;'>".join("<br>\n", @errors)."</div>";
}

print <<__EOF;
<html>
<head>
<title>Services Confiruration</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<script>
function formValidate() {
  var f = document.forms.f1;
  f.submit();
  return false;
}

function addItem()  
{
	var n = parseInt(document.getElementById("new_number").value) + 1;
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	tr.height = 22;
	tr.style.backgroundColor = "#ffffcc";
	tr.onmouseover = function() {ovrMouse(this);};
	tr.onmouseout = function()  {outMouse(this);};
	var td = document.createElement("TD");
	td.allign = "middle";
	td.innerHTML = "<a href='' onClick='delItem(this); return false'><img src='/delete.gif' border=0/></a>";
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	td.innerHTML = "<input class=control type=text name=new_name_"+n+" value='' style='width: 135px;'>";
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.align = "middle";
	var protos_js = new Array('${\(join("','",@{$trafficRounting->{protos}}))}');
	var str = "<select name=new_proto_"+n+" style='width: 50px'>";
	for (var i=0; i<protos_js.length; i++)
	{
		str += "<option value='"+protos_js[i]+"'>"+protos_js[i]+"</option>";
	}
	str += "</select>";
	td.innerHTML = str;
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.align = "middle";
	td.innerHTML = "<input class=control type=text name=new_port_"+n+" value='' style='width: 130px;'>";
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.align = "middle";
	td.innerHTML = "<input class=control type=text name=new_shaper_class_"+n+" value='' style='width: 100px;'>";
	tr.appendChild(td);

	obj.appendChild(tr);
	document.getElementById("new_number").value = n;
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=values value="">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$resultString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=450>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=150>Name</th>
    <th width=50>Proto</th>
    <th width=140>Port</th>
__EOF
if ($cm{enable_shaping})
{
	print "<th width=100>Shaper Class</th>";
}
print <<__EOF;
  </tr>
__EOF
my ($max_number, $new_number) = (0, 0);
my $list = $trafficRounting->get_services();

for (keys %$list)
{
	my $data = $list->{$_}{'data'};
	$data = [$data] if ref $data eq 'HASH';
	for my $item (@$data)
	{
		print_row($item, $_, ++$max_number, $list->{$_}->{shaper_class});
	}
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=3>&nbsp;</td></tr>
  <tr>
    <td colspan=3>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false;">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
}
print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
<input type=hidden name=max_number id=max_number value=$max_number>
<input type=hidden name=new_number id=new_number value=$new_number>
</form>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></td></tr>
</tbody>
</table>
This page allows you create service with some criteria which will be used as traffic routing criteria.
One table row is one criterion. If your service requires few criteria then need create few rows with the same name.
<li>Name is some friendly service name
<li>Proto is required protocol
<li>Port is required port
<br><br>
For example Skype service consist of two criteria and takes two rows in the table. First row defines tcp traffic 
and second udp traffic.
</div>
</body>
</html>
__EOF


sub print_row
{
	my ($item, $key, $n, $shaper_class) = (shift, shift, shift, shift);
	$shaper_class = '' if ref $shaper_class eq 'HASH';
	my ($trcolor) = ("ffffff");
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#$trcolor ><td
  align=middle width=10><a href="" onClick='delItem(this); return false' style="visibility: hidden;"><img src="/delete.gif" border=0/></a></td><td
  style='padding-left: 5px;'><span><a href="" class=grid onClick="openItem(this); return false;">$key</a></span><span style="display: none;"><input class=control type=text name=name_$n value='$key' style='width: 140px;'></span
></td><td align=middle><span><a href="" class=grid onClick="openItem(this); return false;">$item->{proto}</a></span><span style="display: none;">${\($trafficRounting->getProtosSelect($item->{proto}, "proto_$n"))}</span
></td><td align=middle><span><a href="" class=grid onClick="openItem(this); return false;">$item->{port}</a></span><span style="display: none;"><input class=control type=text name=port_$n value='$item->{port}' style='width: 130px;'></span
__EOF
if ($cm{enable_shaping})
{
	print qq|></td><td align=middle><span><a href="" class=grid onClick="openItem(this); return false;">$shaper_class</a></span><span style="display: none;"><input class=control type=text name=shaper_class_$n value='$shaper_class' style='width: 100px;'></span|;
}
print <<__EOF;
></td></tr>
__EOF
	if (!$cm{enable_shaping})
	{
		print qq|<input type=hidden name=shaper_class_$n value='$shaper_class' style='width: 100px;'>|;
	}
}


sub getNewItem
{
	my $list = shift;
	my $c = [];
	for (@$list)
	{
		push @$c, {
			'port' => $_->[2],
			'proto' => $_->[1],
		};
	}
	return {
		'name' => $list->[0]->[0],
		'shaper_class' => $list->[0]->[3],
		'data' => $c
	};
}


__END__
