#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use Bandwidth;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $objBandWidth = Bandwidth->new();
print "Content-Type: text/html\n\n";
my $xml = &readModuleConfigFile($cm{pools_config});
my $classes = &readModuleConfigFile($cm{classes_config});

my $co = new CGI;
my $name = $co->param("fl") || '';
my $new = $co->param("new") || '0';

my $pool = ($new eq '1')?addNewPool($name, $xml):getPool($name, $xml);
print "Pool is not specified." if (!$pool);
$name = $pool->{name} if !$name;
my $title = $pool->{label}?'Edit pool: '.$pool->{label} : 'Add new pool';

my $doneString = "";
if ($allowEdit && defined $co->param("max_number"))
{
	my @items;
	$pool->{description} = $co->param("description")||'';
	$pool->{label} = $co->param("label")||'';
	$pool->{speed} = $co->param("speed");
	$pool->{content} = ();
	if ($pool->{order} == -1)
	{
		$pool->{order} = getMaxOrderNumber($xml)+1;
	}
	my $max_number = $co->param("max_number") || 0;
	for (my $i=0; $i<=$max_number; $i++)
	{
		my $value = $co->param("fld_$i");
		if ($value)
		{
			$pool->{content}->{$value}->{allow} = 'true';
		}
	}
	$doneString = 'Label can not be empty' if ($pool->{label} eq '');
	$doneString = 'Content can not be empty' if (ref $pool->{content} ne 'HASH');
	if ($doneString eq '')
	{
		$objBandWidth->savePool($xml);
		$doneString = "Data is saved successfully";
		keepHistory("$title\n".Dumper($xml));
		$new = '';
	}
}

print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
var acl_class = new Array();
__EOF

if (exists($classes->{acl}->{name}))
{
	print "acl_class[acl_class.length] = {name:\'".$classes->{acl}->{name}."\', label:\'".$classes->{acl}->{label}."\'};\n";
}
else
{
	for (keys %{$classes->{acl}})
	{
		print "acl_class[acl_class.length] = {name:\'".$_."\', label:\'".$classes->{acl}->{$_}->{label}."\'};\n";
	}
}

print <<__EOF;
function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}

function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return 0;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}


function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.align = "middle";
	td.innerHTML = "<a href='' onClick='delItem(this); return false' style='visibility: hidden;'><img src='/delete.gif' border=0></a>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	var s = "<select class=control name=fld_"+num+">";
	for (var i=0; i<acl_class.length; i++)
	{
		if (!ExistsName(acl_class[i].name))
		{
			s += "<option value='"+acl_class[i].name+"'>"+acl_class[i].label+"</option>";
		}
	}
	td.innerHTML = s+"</select>";
	tr.appendChild(td);

	obj.appendChild(tr);
}

function ExistsName(name)
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	for (var i=0; i<rows.length; i++)
	{
		if (rows[i].cells[1].childNodes[0].value == name)
		{
			return true;
		}
	}
	return false;
}
</script>
</head>
<body>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=fl value="$name">
<input type=hidden name=new value="$new">
<input type=hidden name=max_number value="0">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF

if ($pool)	{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td style="padding-top: 20px;"><a href="pools.pl" class=control>Back</a></td>
    <td align=right>&nbsp;</td>
  </tr>
</tbody>
</table>
<p class=donestring>$doneString</p>
<table cellpadding=2 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td width=60>* Label:</td>
    <td><input type=text name=label value="$pool->{label}" class=control size=25></td>
  </tr>
  <tr>
    <td>Description:</td>
    <td><input type=text name=description value="$pool->{description}" class=control size=45></td>
  </tr>
  <tr>
    <td>Speed:</td>
    <td>
__EOF
	if ($pool->{readonly} eq 'true')
	{
		print <<__EOF;
$pool->{speed}&nbsp;Kb/s
<input type=hidden name=speed value="$pool->{speed}" class=control size=5>
__EOF
	}
	else
	{
		print <<__EOF;
<input type=text name=speed value="$pool->{speed}" class=control size=5>&nbsp;Kb/s <small style='padding-left: 10px;'>(set -1 for unlimited speed)</small>
__EOF
	}
	print <<__EOF;
    </td>
  </tr>
  <tr><td colspan=2>* Conditions:</td></tr>
</tbody>
</table>
<table cellspacing=1 cellpadding=1 border=0 width=250>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th>Class</th>
  </tr>
__EOF
	my $i = 0;
	if (ref $pool->{content} eq 'HASH')
	{
		if (exists($pool->{content}->{name}))
		{
			PrintClassesGrid($pool->{content}->{name}, $pool->{content}->{allow}, $classes, $i, $pool->{readonly});
		}
		else
		{
			for (keys %{$pool->{content}})	{
				PrintClassesGrid($_, $pool->{content}->{$_}->{'allow'}, $classes, $i, $pool->{readonly});
				$i++;
			}
		}
	}
	print <<__EOF;
</tbody>
</table>
</tbody>
</table>
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
__EOF
	if ($pool->{readonly} eq 'false')
	{
		print <<__EOF;
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
      <span style="width: 8px;">&nbsp;</span>
__EOF
	}
	if ($allowEdit)
	{
		print <<__EOF;
      <input class=control type=submit name=todo value=Save>
__EOF
	}
	print <<__EOF;
    </td>
  </tr>
</tbody>
</table>
__EOF
}

print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
<li>Label and Description are any friendly info
<li>Speed is http connect speed if the request url coincides with any class condition listed in the grid bellow
</div>


</body>
</html>
__EOF



sub PrintClassesGrid
{
	my $acl = $objBandWidth->getClassName($_[2], $_[0]);
	if ($_[4] eq 'true')
	{
		print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[3]">
    <td align=middle><a href='' onClick='return false' style="display: none;"><img src="/delete.gif" border=0></a></td>
    <td style='padding-left: 5px;'><input type=hidden name=fld_$_[3] value="$acl->[0]"><span>$acl->[1]</span></td>
  </tr>
__EOF
	}
	else
	{
		print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[3]">
    <td align=middle><a href='' onClick='delItem(this); return false' style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td style='padding-left: 5px;'><input type=hidden name=fld_$_[3] value="$acl->[0]"><span>$acl->[1]</span></td>
  </tr>
__EOF
	}
}



sub getPool
{
	if ($_[0])
	{
		if (ref $_[1]->{pool}->{$_[0]} eq 'HASH')
		{
			return $_[1]->{pool}->{$_[0]};
		}
		elsif ($_[1]->{pool}->{name} eq $_[0])
		{
			return $_[1]->{pool};
		}
	}
	return ();
}



sub getNewPool
{
	return {
		'name' => ${\($_[0] eq ''?&getRandomString(15):$_[0])},
		'content' => '',
		'description' => '',
		'label' => '',
		'speed' => '0',
		'readonly' => 'false',
		'order' => -1
	};
}



sub addNewPool
{
	my ($pool, $xml) = @_;
	if (exists($xml->{pool}->{name}))
	{
		my $name = $xml->{pool}->{name};
		my $h;
		$h->{$_} = $xml->{pool}->{$_} for (keys %{$xml->{pool}});
		$xml->{pool}->{$name} = $h;
		for (keys %{$xml->{pool}})
		{
			delete $xml->{pool}->{$_} if ($_ ne $name);
		}
	}
	my $new = getNewPool($pool);
	$xml->{pool}->{$new->{name}} = $new;
	return $new;
}


sub getMaxOrderNumber
{
	my @sorted = $objBandWidth->convertPool2Array($_[0]);
	return $sorted[$#sorted]->{order};
}
