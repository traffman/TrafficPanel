#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
	unshift(@INC, $file.'modules/http_bandwidth/');
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
use Bandwidth;

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
my $objBandWidth = Bandwidth->new();
print "Content-Type: text/html\n\n";
my $title = 'Edit ignore list';
my $http_bandwidth_code = 'http_bandwidth';
populateCfromConfig($http_bandwidth_code);
my $classes = &readModuleConfigFile($C->{$http_bandwidth_code}->{classes_config}, $http_bandwidth_code);

my $co = new CGI;
my $name = $co->param("fl") || '';
my $new = $co->param("new") || '0';

my $doneString = "";
if ($allowEdit && defined $co->param("max_number"))
{
	my $xml;
	my $max_number = $co->param("max_number") || 0;
	for (my $i=0; $i<=$max_number; $i++)
	{
		my $value = $co->param("fld_$i");
		if ($value)
		{
			push @{$xml->{acl}->{name}}, $value;
		}
	}
	saveModuleConfigFile($cm{ignore_classes}, $xml);
	$doneString = "Data is saved successfully";
	keepHistory("$title\n".Dumper($xml));
	$new = '';
}

print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
var acl_class = new Array();
__EOF

if (exists($classes->{acl}->{name}))
{
	print "acl_class[acl_class.length] = {name:\'".$classes->{acl}->{name}."\', label:\'".$classes->{acl}->{label}."\'};\n";
}
else
{
	for (keys %{$classes->{acl}})
	{
		print "acl_class[acl_class.length] = {name:\'".$_."\', label:\'".$classes->{acl}->{$_}->{label}."\'};\n";
	}
}

print <<__EOF;
function formValidate()	{
	var f = document.forms.f1;
	f1.max_number.value = getNumber();
	f.submit();
	return false;
}

function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return 0;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}


function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.align = "middle";
	td.innerHTML = "<a href='' onClick='delItem(this); return false' style='visibility: hidden;'><img src='/delete.gif' border=0></a>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	var s = "<select class=control name=fld_"+num+">";
	for (var i=0; i<acl_class.length; i++)
	{
		if (!ExistsName(acl_class[i].name))
		{
			s += "<option value='"+acl_class[i].name+"'>"+acl_class[i].label+"</option>";
		}
	}
	td.innerHTML = s+"</select>";
	tr.appendChild(td);

	obj.appendChild(tr);
}

function ExistsName(name)
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	for (var i=0; i<rows.length; i++)
	{
		if (rows[i].cells[1].childNodes[0].value == name)
		{
			return true;
		}
	}
	return false;
}
</script>
</head>
<body>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=max_number value="0">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p class=donestring>$doneString</p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=250>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th>Class</th>
  </tr>
__EOF
	my $xml = &readModuleConfigFile($cm{ignore_classes});
	my $i = 0;
	if (ref $xml->{acl}->{name} eq 'ARRAY')
	{
		for (@{$xml->{acl}->{name}})	{
			print_row($_, $classes, $i);
			$i++;
		}
	}
	else
	{
		print_row($xml->{acl}->{name}, $classes, $i);
	}
	print <<__EOF;
</tbody>
</table>
</tbody>
</table>
__EOF
if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
}

print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can manage list of "HTTP Speed" classes which will be ignored in the http traffic calculation. These classes should have 
a list of local hosts ip.
</div>


</body>
</html>
__EOF



sub print_row
{
	my $acl = $objBandWidth->getClassName($_[1], $_[0]);
	if (ref $acl eq 'ARRAY')
	{
		print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[2]">
    <td align=middle><a href='' onClick='delItem(this); return false' style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td style='padding-left: 5px;'><input type=hidden name=fld_$_[2] value="$acl->[0]"><span>$acl->[1]</span></td>
  </tr>
__EOF
	}
}
