#!/bin/bash

COMMON_VARIABLES=(`perl $TWMFOLDER/bin/get_varMultipleValue.pl rm tar sed date _DEFAULT_`)
rm=${COMMON_VARIABLES[0]}
tar=${COMMON_VARIABLES[1]}
sed=${COMMON_VARIABLES[2]}
date=${COMMON_VARIABLES[3]}

SQUIDS=(`perl $TWMFOLDER/modules/http_logging/get_squid_data.pl`)

for item in ${SQUIDS[*]}
do
	SQUID_SETTINGS=(`echo $item | $sed -e "s/:/ /g"`)
	log_dir="$TWMFOLDER/modules/http_logging/logs/${SQUID_SETTINGS[4]}"

	m1=`$date +%m`
	y1=`$date +%Y`
	aM=( AAA Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec )

	months_number=`perl $TWMFOLDER/bin/get_varValue.pl backup_in_months http_logging`
	m1=`expr $m1 - $months_number`
	if [ $m1 -le 0 ]; then
		m1=`expr 12 + $m1`
		y1=`expr $y1 - 1`
	fi

	m2=`expr ${aM[$m1]}`

	cd $log_dir
	$tar -czf "$y1$m2.tz" ./$y1$m2??-$y1$m2??* > /dev/null 2>&1
	$rm -Rf ./$y1$m2??-$y1$m2??*

done

exit 0
