#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use TrafficLimit;
use Data::Dumper;

if (isDebug()) {use CGI::Carp qw(fatalsToBrowser)};

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
my $objTrafficLimit = TrafficLimit->new();
my $m_ip = &getInternalIP;
my $xml = &readModuleConfigFile($cm{pool});
my $ip_list = &getIPList;
my (%received,%used,%received_used);
my $network_info = &getNetworkInfo;

push @{$ip_list}, ['','-- All --',$network_info->{network}.'/'.$network_info->{cidr},'-- All --'];

print "Content-Type: text/html\n\n";
my %ip_hash;
foreach (@{$ip_list})
{
	$ip_hash{$_->[2]} = $_;
}

my $co = new CGI;
my $name = $co->param("fl") || '';
my $new = $co->param("new") || '0';

my $pool = ($new eq '1')?addNewPool($name, $xml):getPool($name, $xml);
print "Pool is not specified." if (!$pool);
$name = $pool->{name} if !$name;
my $title = $pool->{label}?"Edit pool: $pool->{label}" : 'Add new pool';

my $doneString = "";
if ($allowEdit && defined $co->param("max_number"))
{
	my @items;
	$pool->{description} = $co->param("description")||'';
	$pool->{label} = $co->param("label")||'';
	$pool->{order} = $co->param("order")||'1';
	if ($pool->{order} == -1)
	{
		$pool->{order} = getMaxOrderNumber($xml)+1;
	}
	$pool->{disable} = ();
	push @{$pool->{disable}->{destination}}, $co->param("dest");
	$pool->{content} = ();
	my $max_number = $co->param("max_number") || 0;

	if ($max_number ne '0') {
		for (values %{$xml->{pool}}) {
			$used{$_->{'label'}} = $_->{'content'}{'ip'};
		}
	}

	for (my $i=0; $i<=$max_number; $i++)
	{
		my $value = $co->param("fld_$i");
		if ($value)
		{
			push @{$pool->{content}->{ip}}, $value;
		}
	}
	$doneString = 'Label field is required.' if ($pool->{label} eq '');
	$doneString = 'IP list can\'t be empty.' if (!exists($pool->{content}->{ip}));

	if ($max_number ne '0') {
	if (ref $pool->{content}{ip} eq 'ARRAY') {
		foreach(@{$pool->{content}{ip}}) {$received{$_} = '1'}
	}
	else {$received{$pool->{content}{ip}} = '1'}

	while(my ($pool_label, $ip_list) = each(%used)) {
		if (ref $ip_list eq 'ARRAY') {
			foreach(@{$ip_list}) {
				if (exists $received{$_}) { $doneString .= "IP $_ already used in pool $pool_label. Remove it first, then try again.<br>" }
				$received_used{$_} = '1';
			}
		}
		else {
 			if (exists $received{$ip_list}) { $doneString .= "IP $ip_list already used in pool $pool_label. Remove it first, then try again.<br>" }
				$received_used{$ip_list} = '1';
		}
	}

}

	if ($doneString eq '')
	{
		saveModuleConfigFile($cm{pool}, $xml);
		run_twm_script($cm{db_compiler}, $mc);
		$doneString = "Data is saved successfully.";
		keepHistory("$title:\n".Dumper($xml));
		$new = '';
	}
}

print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<script>
var ip_list = new Array();
__EOF

foreach (@{$ip_list}) {
	print "ip_list[ip_list.length] = {ip:\'".$_->[2]."\', user:\'".jsEncode($_->[1])."\', name:\'".jsEncode($_->[3])."\'};\n" 
}

print <<__EOF;
function formValidate()	{
	deleteMarkedRows();
	var f = document.forms.f1;
	f.max_number.value = getNumber();
	f.submit();
	return false;
}

function getNumber()
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	if (rows.length == 1)
		return 0;
	return parseInt(rows[rows.length-1].getAttribute("num"));
}

function addItem(o)	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	var num = getNumber()+1;
	tr.setAttribute("num", num);
	tr.height = 22;
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.align = "middle";
	td.innerHTML = "<a href='' onClick='delItem(this); return false' style='visibility: hidden;'><img src='/delete.gif' border=0></a>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	var s = "<select class=control name=fld_"+num+" onChange='chgItem(this)'>";
	var firstItem;
	for (var i=0; i<ip_list.length; i++)
	{
		if (!ExistsName(ip_list[i].ip))
		{
			if (!firstItem)
			{
				firstItem = ip_list[i];
			}
			s += "<option value='"+ip_list[i].ip+"'>"+ip_list[i].ip+"</option>";
		}
	}
	td.innerHTML = s+"</select>";
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	td.innerHTML = firstItem.user;
	tr.appendChild(td);

	var td = document.createElement("TD");
	td.style.paddingLeft = '5px';
	td.innerHTML = firstItem.name;
	tr.appendChild(td);

	obj.appendChild(tr);
}


function chgItem(obj)
{
	var item = getItem(obj.options[obj.selectedIndex].value);
	obj.parentNode.parentNode.cells[2].innerHTML = item.user;
	obj.parentNode.parentNode.cells[3].innerHTML = item.name;
}


function getItem(ip)
{
	for (var i=0; i<ip_list.length; i++)
	{
		if (ip_list[i].ip == ip)
		{
			return ip_list[i];
		}
	}
	return {};
}


function ExistsName(ip)
{
	var rows = document.getElementById("cTable").tBodies[0].rows;
	for (var i=0; i<rows.length; i++)
	{
		if (rows[i].cells[1].childNodes[0].value == ip)
		{
			return true;
		}
	}
	return false;
}
</script>
</head>
<body>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=fl value="$name">
<input type=hidden name=new value="$new">
<input type=hidden name=max_number value="0">
<input type=hidden name=order value="$pool->{order}">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF

if ($pool)	{
	print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td style="padding-top: 20px;"><a class=control href="pools.pl">Back</a></td>
    <td align=right>&nbsp;</td>
  </tr>
</tbody>
</table>
<p class=donestring>$doneString</p>
<table cellpadding=2 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td width=100>* Label:</td>
    <td><input type=text name=label value="$pool->{label}" class=control size=25></td>
  </tr>
  <tr>
    <td>Description:</td>
    <td><input type=text name=description value="${\(ref $pool->{description} eq 'HASH'?'':$pool->{description})}" class=control size=45></td>
  </tr>
  <tr>
    <td>Disabled resources:</td>
    <td>
      <select name=dest multiple size=5>
__EOF

my @dest = $objTrafficLimit->get_dest_list();
foreach (@dest)
{
	print <<__EOF if $_;
        <option value="$_" ${\(get_selected($_, $pool->{disable}->{destination}))}>$_
__EOF
}

print <<__EOF;
      </select>
    </td>
  </tr>
  <tr><td colspan=2>* IPs:</td></tr>
</tbody>
</table>
<table cellspacing=1 cellpadding=1 border=0 width=450>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100%>
<tbody>
  <tr height=25>
    <th width=10>&nbsp;</th>
    <th width=120>IP</th>
    <th width=120>User</th>
    <th>Name</th>
  </tr>
__EOF

	my $i = 0;
	if (ref $pool->{content} eq 'HASH')
	{
		if (ref $pool->{content}->{ip} ne 'ARRAY' && exists($pool->{content}->{ip}))
		{
			if (! exists $received_used{$pool->{content}->{ip}}) {
					PrintGrid($pool->{content}->{ip}, $ip_hash{$pool->{content}->{ip}}, $i);
				}
		}
		else
		{
			foreach (@{$pool->{content}->{ip}})	{
				if (! exists $received_used{$_}) {
					PrintGrid($_, $ip_hash{$_}, $i);
					$i++;
				}
			}
		}
	}

print <<__EOF;
</tbody>
</table>
</tbody>
</table>
__EOF

	if ($allowEdit)
	{
		print <<__EOF;
<table cellpadding=1 cellspacing=1 border=0>
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name=todo value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
	}
}

print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>

<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Here is list of specified squid pool conditions.
</div>

</body>
</html>
__EOF

sub PrintGrid
{
	print <<__EOF;
  <tr height=25 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff num="$_[2]">
    <td align=middle><a href='' onClick='mark2DelItem(this); return false' style="visibility: hidden;"><img src="/delete.gif" border=0></a></td>
    <td style='padding-left: 5px;'><input type=hidden name=fld_$_[2] value="$_[0]"><span>$_[0]</span></td>
    <!--td style='padding-left: 5px;'><span>$_[1]->[1]</span></td-->
    <td style='padding-left: 5px;'><span>$_[1]->[3]</span></td>
  </tr>
__EOF
}

sub getPool
{
	if ($_[0])
	{
		if (ref $_[1]->{pool}->{$_[0]} eq 'HASH')
		{
			return $_[1]->{pool}->{$_[0]};
		}
		elsif ($_[1]->{pool}->{name} eq $_[0])
		{
			return $_[1]->{pool};
		}
	}
	return ();
}

sub getNewPool
{
	return {
		'name' => ${\($_[0] eq ''?&getRandomString(15):$_[0])},
		'content' => '',
		'description' => '',
		'label' => '',
		'order' => -1,

	};
}

sub addNewPool
{
	my ($pool, $xml) = @_;
	if (exists($xml->{pool}->{name}))
	{
		my $name = $xml->{pool}->{name};
		my $h;
		$h->{$_} = $xml->{pool}->{$_} for (keys %{$xml->{pool}});
		$xml->{pool}->{$name} = $h;
		for (keys %{$xml->{pool}})
		{
			delete $xml->{pool}->{$_} if ($_ ne $name);
		}
	}
	my $new = getNewPool($pool);
	$xml->{pool}->{$new->{name}} = $new;
	return $new;
}

sub get_selected
{
	if (ref $_[1] eq 'ARRAY')
	{
		foreach (@{$_[1]})
		{
			return 'selected' if ($_[0] eq $_);
		}
	}
	elsif ($_[1] eq $_[0])
	{
		return 'selected';
	}
	return '';
}

sub getMaxOrderNumber
{
	my @sorted = $objTrafficLimit->convertPool2Array($_[0]);
	return $sorted[$#sorted]->{order};
}

sub getIPList	{
	my @ip_list;
	my $ips = &getIPs;
	foreach (@{$ips})
	{
		push @ip_list, [$_->{used}, $_->{dns_name}, $_->{ip}, $_->{full_name}, $_->{mac}];
	}
	return \@ip_list;
}


__END__
