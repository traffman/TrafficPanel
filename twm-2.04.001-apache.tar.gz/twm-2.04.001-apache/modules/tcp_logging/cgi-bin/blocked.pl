#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

# this script used to set total http traffic restriction
# after total amount is set then script sends SIGUSR1 to httpr_sl daemon

use strict;
use CGI;
use TWM;
use TrafficLogging;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $trafficLogging = TrafficLogging->new();
my $co = new CGI;
my $title = "Blocked ip list";            
my $doneString = '';

print "Content-Type: text/html\n\n";

my $ip_list = &getIPs;

print <<__EOF;
<html>
<head>
<title>Total HTTP Traffic Amount</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=values value="">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=600>
<tbody>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$doneString</small></p>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=400>
  <tr bgcolor=#dddddd>
    <td>
<table id=cTable cellpadding=1 cellspacing=1 border=0 width=100% style="table-layout: fixed;">
<tbody>
  <tr height=25>
    <th width=145>IP</th>
    <th width=180>Name</th>
    <th width=90>Available (Mb)</th>
    <th width=65>Used (Mb)</th>
  </tr>
__EOF

my (@blockedlist, %specific_limits);

my $interfaces = $trafficLogging->get_ext_interfaces();
my $report_file = $trafficLogging->get_report_filename();
my $dtstart = "$1$2$3" if $report_file =~ /(\d{4})(\d\d)(\d\d)/;

$trafficLogging->populate_report($dtstart, $dtstart, $report_file);

my $ips = get_ip_name_hash($ip_list);

my $xml = readModuleConfigFile($cm{tcp_limit});

my $areas = $xml->{'pc'};
if (ref $areas eq 'HASH')
{
	$specific_limits{$areas->{ip}} = $areas->{size}
}
else
{
    foreach (@$areas)
    {
        $specific_limits{$_->{ip}} = $_->{size}
    }
}

for (@$ip_list)	{

	unless ($_->{enabled}) {

		my $total = $trafficLogging->traffic_count(0, $interfaces, $_->{ip}, '');

		$total = getHumanTrafficNumber($total, 'm');

		next if $total < 0.1;

		my $item = $_->{ip}.'|'.$total;

		if (exists($specific_limits{$_->{ip}})) {
			if ($total >= $specific_limits{$_->{ip}}) {
				$item .= '|'.$specific_limits{$_->{ip}};
				push(@blockedlist, $item);
			}
		}
		else {
			if ($total >= $cm{default_size}) {
				$item .= '|'.$cm{default_size};
				push(@blockedlist, $item);
			}
		}

	}

}

foreach (@blockedlist)
{
	/(.+)\|([\d\.]+)\|([\d\.]+)/;
	my($ip, $used, $avail) = ($1, $2, $3);
	print <<__EOF;
  <tr height=22 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff >
    <td>&nbsp;$ip</td>
    <td>&nbsp;$ips->{$ip}</td>
    <td align=right>$avail&nbsp;</td>
    <td align=right>$used&nbsp;</td>
  </tr>
__EOF
}

print <<__EOF;
</tbody>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>

<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
Here is list of blocked ip of http traffic. To unblock need set avalable http traffic more then used.
</div>

</body>
</html>
__EOF

sub get_size
{
	if (ref $_[1] eq 'HASH')
	{
		return $_[1]->{size} if ($_[1]->{ip} eq $_[0]);
	}
	else
	{
		foreach (@{$_[1]})
		{
			return $_->{size} if ($_->{ip} eq $_[0]);
		}
	}
}

__END__
