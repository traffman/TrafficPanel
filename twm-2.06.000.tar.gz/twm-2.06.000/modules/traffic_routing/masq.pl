#!/usr/bin/perl -w

BEGIN	
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/(\/?modules)?(\/?traffic_routing)?\/?\w+\.pl$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
}

use strict;
use CGI;
use TWM;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

my $xml = readModuleConfigFile($cm{rules});
my $list = (ref $xml->{rule} eq 'HASH')?[$xml->{rule}]:$xml->{rule};

for (@$list)
{
	my @res = run_twm_script("$cm{rule_processor} masq start $_->{interface} $_->{ip} '$_->{port}' $_->{proto}", $mc);
}

__END__
