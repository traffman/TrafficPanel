// show root item
var showRootItem = true;
// keep temporary backgroun color for mouseOver/Out action over cell
var tmpcolor;
var isItIE = true;
var isItIEforTree = ( (new String(navigator.userAgent)).indexOf("MSIE") != -1 );
var treeRoot, treeDeep, a32;
var cross = 1;
var icons = 1;
var checkbox = 1;
var bgColor = "#f3f3f3";
var sColor = "#D6D6D6";
var imgBase = "";
var onSelectNode = function zagl() {return true};
var onCheckNode = function zagl1() {return true};
//var onCross = function zagl2() {return true};
var onLoadChilds = function zagl3() {return true};
var selectedNode = null;
var canCheckHierarchical = false;
var canDynamicalLoad = false;
var dynamicLoadAutoOpen = true;
var DHTMLlayer;


function Node(id, labelName, hasCheckbox, imgC, imgO)
{
    this.id = id;
    this.level = 0;
    this.idx = -1;

    this.label = labelName;
    this.imgC = ( imgC != null ? imgC : imgO );
    this.imgO = ( imgO != null ? imgO : imgC );

    this.parent = null;
    this.childs = new Array();

    this.isOpen = false;
    this.hasCheckbox = ( hasCheckbox && ( checkbox == 1 ) );
    this.isChecked = false;

    this.hasUnloadedChild = canDynamicalLoad;

    this.addChild = addChild;
    this.getDeep = getDeep;
    this.setLabel = setNodeLabel;
}
function addChild(child)
{
    this.childs[this.childs.length] = child;
    child.parent = this;
    child.idx = this.childs.length - 1;
    child.level = this.level + 1;
}
function setNodeLabel(newLabel)
{
    this.label = newLabel;
    if ( isItIE )
    {
        var al = document.getElementById("a"+this.id);
        if ( al != null ) al.innerHTML = newLabel;
    }
    else
        repaintTree();
}
function getDeep()
{
    var d = 0;
    if ( this.childs.length != 0 )
    {
        for (var i=0; i < this.childs.length; i++)
        {
            var cd = this.childs[i].getDeep();
            if ( cd > d ) d = cd;
        }
        d++;
    }
    return d;
}

function showTree(timeout)	{
	if ( isItIE )
		repaintTree();
    else	{
		timeout = ( timeout == null ? 1000 : timeout );
		setTimeout("repaintTree()", timeout);
	}
}


function repaintTree()	{
    treeDeep = treeRoot.getDeep();
    a32 = new Array();
    var dest;

    dest = document;

    // dispay header
//    dest.write("<form name='tree_form'>")
    dest.write("<div id=tree_limit class=mContent><table width=100% id='tree_table' border=0 cellspacing=0 cellpadding=0 bgcolor='"+bgColor+"'>");
    dest.write("</tr>");

    // display items
    showItem(treeRoot, showRootItem, dest);

    // display footer
    dest.write("</table></div>");
//    dest.write("</form>");
}


function showItem(node, isVisible, dest)	{
    // display node row
    dest.write("<tr id='i"+node.id+"' style='display:"+(isVisible?"":"none")+"'>"+getNodeRow(node)+"</tr>");

    // display childs
    if ( node.childs != null && ( isItIE || node.isOpen ) )
        for (var i=0; i < node.childs.length; i++)
            showItem(node.childs[i], ( isVisible && node.isOpen ), dest);
}


function getNodeRow(node)	{
    var rowStr, tdCounter;

    if ( node.level != 0 )
    {
        var rowStr = "<td width=1%><img src='"+imgBase+"dt_blank.gif' border=0></td>";
        var tdCounter = 1;
    }
    else
    {
        rowStr = "";
        tdCounter = 0;
    }

	for (var i=0; i < node.level-1; i++)
		if ( a32[i].childs.length != 0 )	{
			var vs = ( ( a32[i+1].idx < a32[i].childs.length-1 )
                       ? "dt_vertline.gif" : "dt_blank.gif" );
            rowStr += "<td width=1%><img src='"+imgBase+""+vs+"' border=0></td>";
            tdCounter++;
        }

	if ( node.childs.length != 0 || node.hasUnloadedChild )	{
        var crossImg = ( node.parent != null && ( node.idx < node.parent.childs.length-1 )
                         ? "dt_"+( node.isOpen ? "m" : "p" )+"node.gif" : "dt_"+( node.isOpen ? "m" : "p" )+"lastnode.gif" );

        rowStr += "<td width=1%><a onClick='return clickCross(\""+node.id+"\");' href='javascript:void(0);' onFocus='blur();'>"+
                        "<img id='cr"+node.id+"' src='"+imgBase+""+crossImg+"' border=0></a></td>";
        tdCounter++;

        rowStr += "<td width=1%><img id='f"+node.id+"' src='"+imgBase+
                  ( node.isOpen
                    ? ( node.imgO == null ? "dt_folderopen.gif" : node.imgO )
                    : ( node.imgC == null ? "dt_folderclosed.gif" : node.imgC ) )+"' border=0></td>";
        tdCounter++;
    }
    else
    {
        var vs = ( node.parent != null && ( node.idx < node.parent.childs.length-1 )
                         ? "dt_node.gif" : "dt_lastnode.gif" );

        rowStr += "<td width=1%><img id='cr"+node.id+"' src='"+imgBase+""+vs+"' border=0></td>";
        tdCounter++;

        rowStr += "<td width=1%><img id='f"+node.id+"' src='"+imgBase+( node.imgC == null
                                                                        ? "dt_doc.gif"
                                                                        : node.imgC )+"' border=0></td>";
        tdCounter++;
    }

    if ( checkbox == 1 && node.hasCheckbox )
    {
        rowStr += "<td width=1% align=center valign=middle>"+
                    "<input name='cb"+node.id+"' type=checkbox"+
                          " onClick='return clickCheck(\""+node.id+"\", this.checked)' onFocus='blur();'"+
                          ( node.isChecked ? " checked" : "" )+"></td>";
        tdCounter++;
    }

    rowStr += "<td nowrap colspan="+(treeDeep+cross+icons+checkbox-tdCounter+1)+( !isItIE && selectedNode!=null && node.id==selectedNode.id ? " bgcolor='"+sColor+"'" : "" )+">"+
                "&nbsp;<a id='a"+node.id+"' class='label' href='javascript:void(0)'"+
                          ( isItIE && selectedNode!=null && node.id == selectedNode.id ? " style='background-color:"+sColor+"'": "" )+" onClick='return clickNode(\""+node.id+"\",this);'>"+node.label+"</a></td>";

    a32[node.level] = node;
    a32.length = node.level+1;

    return rowStr;
}

function enlargeDeep()
{
    treeDeep++;
    var r = document.getElementById("tree_table").rows;
    for (var i=0; i < r.length; i++)
    {
        var c = r[i].cells;
        c[c.length-1].colSpan++;
    }
}

function getAllCheckedItems()
{
    return getCheckedItems(treeRoot);
}
function getCheckedItems(node)
{
    var aIds = new Array();

    if ( node.hasCheckbox && node.isChecked )
        aIds[0] = node.id;
    for (var i=0; i < node.childs.length; i++)
    {
        var aCIds = getCheckedItems(node.childs[i]);
        for (var j=0; j < aCIds.length; j++)
            aIds[aIds.length] = aCIds[j];
    }
    return aIds;
}

function getTreeItemFrom(fromItem, id)
{
    if ( fromItem.id == id )
        return fromItem;
    else
        for (var i=0; i < fromItem.childs.length; i++)
        {
            var ci = getTreeItemFrom(fromItem.childs[i], id);
            if ( ci != null ) return ci;
        }

    return null;
}
function getTreeItem(id)
{
    return getTreeItemFrom(treeRoot, id);
}


function clickNode(id, a)	{
    if (onSelectNode(id))	{
		var tmp = getTreeItem(id);
		if (isItIE && selectedNode != null )	{
			document.getElementById("a"+selectedNode.id).parentNode.style.backgroundColor = bgColor;
//			document.getElementById("a"+selectedNode.id).style.backgroundColor = bgColor;
			if (document.getElementById("af"+selectedNode.id).color == "#000000")
				document.getElementById("af"+selectedNode.id).className = "label";
			else
				document.getElementById("af"+selectedNode.id).className = "labelred";
		}
		selectedNode = tmp;
		if (isItIE)	{
			tmpcolor = sColor;
			document.getElementById("a"+selectedNode.id).parentNode.style.backgroundColor = sColor;
//			a.style.backgroundColor = sColor;
			a.hideFocus = true;
			a.firstChild.className = "slabel";
		}else
			repaintTree();

		onTreeSelect(id);
    }
	return false;
}


function selectTreeNode(id)	{
	var tmp = getTreeItem(id);
	if ( isItIE && selectedNode != null )	{
		document.getElementById("a"+selectedNode.id).parentNode.style.backgroundColor = bgColor;
//		document.getElementById("a"+selectedNode.id).style.backgroundColor = bgColor;
		if (document.getElementById("af"+selectedNode.id).color == "#000000")
			document.getElementById("af"+selectedNode.id).className = "label";
		else
			document.getElementById("af"+selectedNode.id).className = "labelred";
	}
	selectedNode = tmp;
	if ( isItIE )	{
		document.getElementById("a"+selectedNode.id).parentNode.style.backgroundColor = sColor;
//		document.getElementById("a"+selectedNode.id).style.backgroundColor = sColor;
		document.getElementById("af"+selectedNode.id).className = "slabel";
	}else
		repaintTree();
}


function unselectTreeNode(id)	{
	if ( selectedNode != null )	{
		if ( isItIE )	{
			document.getElementById("a"+selectedNode.id).parentNode.style.backgroundColor = bgColor;
//			document.getElementById("a"+selectedNode.id).style.backgroundColor = bgColor;
			if (document.getElementById("af"+selectedNode.id).color == "#000000")
				document.getElementById("af"+selectedNode.id).className = "label";
			else
				document.getElementById("af"+selectedNode.id).className = "labelred";
		}
		selectedNode = null;
		if ( ! isItIE )
			repaintTree();
		else
			document.getElementById("a"+selectedNode.id).parentNode.style.backgroundColor = sColor;

    }
}

function clickCheck(id, isCheck)
{
    var node = getTreeItem(id);
    var checkResult = onCheckNode(id, isCheck);
    if ( checkResult )
        setCheck(node, isCheck);
    return checkResult;
}

function setCheck(node, isCheck)
{
    if ( node.hasCheckbox )
    {
        node.isChecked = isCheck;
        if ( document.getElementById("tree_table") != null )
        {
            if ( isItIE && document.forms.tree_form.elements["cb"+node.id] != null )
                document.forms.tree_form.elements["cb"+node.id].checked = isCheck;
            else if ( !isItIE && DHTMLlayer.document.forms.tree_form.elements["cb"+node.id] != null )
                DHTMLlayer.document.forms.tree_form.elements["cb"+node.id].checked = isCheck;
        }
    }

    if ( canCheckHierarchical )
        for (var i=0; i < node.childs.length; i++)
            setCheck(node.childs[i], isCheck);
}

function openNode(id)
{
    var node = getTreeItem(id);
    node.isOpen = true;
    if ( !isItIE )
        repaintTree();
    else
        expandNode(node);
}
function clickCross(id)	{
	var node = getTreeItem(id);
	if (!onCross(node))
		return false;

	if (node.isOpen)	{
        node.isOpen = false;
        if ( !isItIE )
            repaintTree();
        else
            collapseNode(node);
//    }else if ( node.hasUnloadedChild && canDynamicalLoad )	{
//        document.getElementById("tree_table").style.cursor = "wait";
//        top.window.status = "Loading...";
    }else	{
        node.isOpen = true;
        if ( !isItIE )
            repaintTree();
        else	{
            expandNode(node);
		}
    }
    return false;
}


function collapseNode(node)
{
    for (var i=node.childs.length-1; i >= 0; i--)
    {
        if ( node.childs[i].isOpen )
            collapseNode(node.childs[i]);
        document.getElementById("i"+node.childs[i].id).style.display = "none";
    }
    document.getElementById("f"+node.id).src = imgBase+( node.imgC == null ? "dt_folderclosed.gif" : node.imgC );
    if ( node.childs.length > 0 )
    {
        document.getElementById("cr"+node.id).src = imgBase+( node.parent != null && node.idx < node.parent.childs.length-1
                                              ? "dt_pnode.gif" : "dt_plastnode.gif" )
    }
}
function expandNode(node)
{
    for (var i = 0;  i < node.childs.length; i++)
    {
        document.getElementById("i"+node.childs[i].id).style.display = "";
        if ( node.childs[i].isOpen && node.childs[i].childs.length > 0 )
            expandNode(node.childs[i]);
    }
    if ( node.childs.length > 0 &&  node.isOpen )
    {
        document.getElementById("f"+node.id).src = imgBase+( node.imgO == null ? "dt_folderopen.gif" : node.imgO );
        document.getElementById("cr"+node.id).src = imgBase+( node.parent != null && node.idx < node.parent.childs.length-1
                                              ? "dt_mnode.gif" : "dt_mlastnode.gif" )
    }
}

function changeNodeIcon(node, imgC, imgO)
{
    if ( node == null ) return;
    node.imgC = ( imgC != null ? imgC : imgO );
    node.imgO = ( imgO != null ? imgO : imgC );
    if ( isItIE )
    {
        var c = document.getElementById("i"+node.id).cells[node.level+1];
        c.innerHTML = "<img id='f"+node.id+"' src='"+imgBase+
                        ( node.isOpen
                          ? ( node.imgO == null ? "dt_folderclosed.gif" : node.imgO )
                          : ( node.imgC != null
                              ? node.imgC
                              : ( node.hasUnloadedChild || node.childs.length > 0
                                  ? "dt_folderclosed.gif" : "dt_doc.gif" ) ) )+"' border=0>";
    }
    else
        repaintTree();
}


function changeNodeLabel(node, label)	{
    if (node == null || label == null || label == "")
		return false;
    if (isItIE)	{
        document.getElementById("af"+node).innerText = label;
    }
    else
        repaintTree();
	return false;
}


function insertRootImg(id, label, imgC, imgO)
{
    return insertRoot(id, label, null, imgC, imgO);
}
function insertRootCBox(id, label, hasCheckbox)
{
    return insertRoot(id, label, hasCheckbox, null, null);
}
function insertRoot(id, label, hasCheckbox, imgC, imgO)
{
    a32 = new Array();
    treeRoot = new Node(id, label, hasCheckbox, imgC, imgO);
    treeRoot.isOpen = true;
    a32[0] = treeRoot;
    return treeRoot;
}
function addNodeImg(id, label, level, imgC, imgO)
{
    return addNode(id, label, level, null, imgC, imgO);
}
function addNodeCBox(id, label, level, hasCheckbox)
{
    return addNode(id, label, level, hasCheckbox, null, null);
}
function addNode(id, label, level, hasCheckbox, imgC, imgO)
{
    var node = new Node(id, label, hasCheckbox, imgC, imgO);
    if ( level > 0 && a32[level-1] != null )
    {
        a32[level-1].addChild(node);
        a32[level] = node;
        a32.length = level+1;
    }
    return node;
}
function addChildNodeImg(parentId, id, label, imgC, imgO)
{
    return addChildNode(parentId, id, label, null, imgC, imgO);
}
function addChildNodeCBox(parentId, id, label, hasCheckbox)
{
    return addChildNode(parentId, id, label, hasCheckbox, null, null);
}
function getLastChildId(node)
{
    return ( node.childs.length == 0 ? node.id : getLastChildId(node.childs[node.childs.length-1]) );
}


function addChildNode(parentId, id, label, hasCheckbox, imgC, imgO, hasNotChilds)	{
    var parent = getTreeItem(parentId);
    if ( parent == null ) return false;

    var prevRowId = "i"+getLastChildId(parent);
    var n = new Node(id, label, hasCheckbox, imgC, imgO);
    n.hasUnloadedChild = ! hasNotChilds;

    parent.addChild(n);
    if ( treeDeep < parent.childs[parent.childs.length-1].level )
        enlargeDeep();

    if ( !isItIE )
    {
        repaintTree();
        return n;
    }

    // change corner to cross if it need
    var r = document.getElementById(prevRowId);
    if ( parent.childs.length == 1 )
    {
        var crossImg = ( parent.parent != null && ( parent.idx < parent.parent.childs.length-1 )
                         ? "dt_"+( parent.isOpen ? "m" : "p" )+"node.gif"
                         : "dt_"+( parent.isOpen ? "m" : "p" )+"lastnode.gif" );

        r.cells[parent.level].innerHTML = "<a onClick='return clickCross(\""+parent.id+"\");' href='javascript:void(0)' onFocus='blur();'>"+
                                            "<img id='cr"+parent.id+"' src='"+imgBase+""+crossImg+"' border=0></a>";
    }
    // change corner to previouse child node
    else if ( parent.childs.length > 1 )
    {
        var prevNode = parent.childs[parent.childs.length-2];
        r = document.getElementById("i"+prevNode.id);

        if ( prevNode.childs.length == 0 && !prevNode.hasUnloadedChild )
            r.cells[parent.level+1].innerHTML = "<img src='"+imgBase+"dt_node.gif' border=0>";
        else if ( prevNode.childs.length > 0 || prevNode.hasUnloadedChild )
        {
            r.cells[parent.level+1].innerHTML = "<a onClick='return clickCross(\""+prevNode.id+"\");' href='javascript:void(0)' onFocus='blur();'>"+
                                                  "<img id='cr"+prevNode.id+"' src='"+imgBase+"dt_"+( prevNode.isOpen ? "m" : "p" )+"node.gif' border=0></a></td>";
            if ( prevNode.childs.length > 0 )
            {
                var rows = document.getElementById("tree_table").rows;
                var flag = false;
                for (i = 0; i < rows.length; i++)
                {
                    if ( flag )
                        rows[i].cells[parent.level+1].innerHTML = "<img src='"+imgBase+"dt_vertline.gif' border=0>";
                    if ( rows[i].id == prevRowId )
                        break;
                    if ( rows[i] == r )
                        flag = true;
                }
            }
        }
    }

    // show inserted node
    var row = document.getElementById("tree_table").insertRow(document.getElementById(prevRowId).rowIndex+1);
    row.id = "i"+n.id;
    row.style.display = ( parent.isOpen ? "" : "none" );

    var tmp = parent;
    var tdCounter = 0;
    while ( tmp.parent != null )
    {
        var vs = ( ( tmp.idx < tmp.parent.childs.length-1 )
                   ? "dt_vertline.gif" : "dt_blank.gif" );
        cell = row.insertCell(0);
        cell.innerHTML = "<img src='"+imgBase+""+vs+"' border=0>";
        cell.width = "1%";
        tdCounter++;
        tmp = tmp.parent;
    }

    // adding leading space palace or vertikal element that linked to the first cross
    cell = row.insertCell(0);
    cell.innerHTML = "<img src='"+imgBase+"dt_blank.gif' border=0>";
    cell.width = "1%";
    tdCounter++;

    var crText = "<img id='cr"+n.id+"' src='"+imgBase+"dt_lastnode.gif' border=0>";
    if ( n.hasUnloadedChild && ! hasNotChilds )
        crText = "<a onClick='return clickCross(\""+n.id+"\");' href='javascript:void(0)' onFocus='blur();'>"+
                   "<img id='cr"+n.id+"' src='"+imgBase+"dt_plastnode.gif' border=0></a></td>";
    cell = row.insertCell(row.cells.length);
    cell.innerHTML = crText;
    cell.width = "1%";
    tdCounter++;

    cell = row.insertCell(row.cells.length);
    cell.innerHTML = "<img id='f"+n.id+"' src='"+imgBase+( n.imgC != null
                                                           ? n.imgC
                                                           : ( n.hasUnloadedChild
                                                               ? "dt_folderclosed.gif"
                                                               : "dt_doc.gif" ) )+"' border=0>";
    cell.width = "1%";
    tdCounter++;

    if ( checkbox == 1 && n.hasCheckbox )
    {
        cell = row.insertCell(row.cells.length);
        cell.innerHTML = "<input name='cb"+n.id+"' type=checkbox"+
                               " onClick='clickCheck(\""+n.id+"\", this.checked)' onFocus='blur();'"+
                               ( n.isChecked ? " checked" : "" )+">";
        cell.width = "1%";
        tdCounter++;
    }

    cell = row.insertCell(row.cells.length);
	cell.onmouseover = function()	{
		tmpcolor = this.style.backgroundColor;
		this.style.backgroundColor = sColor; 
		return true;
	}
	cell.onmouseout = function()	{
		this.style.backgroundColor = tmpcolor; 
		return true;
	}
    cell.innerHTML = "&nbsp;<a id='a"+n.id+"' class='label' href='javascript:void(0)' onClick='return clickNode(\""+n.id+"\", this);'>"+n.label+"</a>";
//alert(cell.innerHTML);
    cell.colSpan = treeDeep+cross+icons+checkbox-tdCounter+1;
    cell.noWrap = true;

    return n;
}


function dynamicLoadChilds(parentId, ids, labels, hasCheckboxes, imgCs, imgOs, hasChilds)	{
    if ( ids != null && ids.length != null && labels != null && labels.length != null
         && hasCheckboxes != null && hasCheckboxes.length != null
         && imgCs != null && imgCs.length != null && imgOs != null && imgOs.length != null
         && hasChilds != null && hasChilds.length != null
         && ids.length == labels.length && ids.length == hasCheckboxes.length
         && ids.length == imgCs.length && ids.length == imgOs.length
         && ids.length == hasChilds.length )
    {
        for (var i = 0; i < ids.length; i++)
        {
            var n = addChildNode(parentId, ids[i], labels[i], hasCheckboxes[i], imgCs[i], imgOs[i], !hasChilds[i]);
            if ( !hasChilds[i] )
                n.hasUnloadedChild = false;
        }
        var parentNode = getTreeItem(parentId);
        parentNode.hasUnloadedChild = false;
        onLoadChilds(parentNode);
        if ( dynamicLoadAutoOpen && parentNode.childs.length > 0)
        {
            parentNode.isOpen = true;
            expandNode(parentNode);
        }
        if ( parentNode.childs.length == 0 )
            document.getElementById("i"+parentNode.id).cells[parentNode.level].innerHTML = "<img id=\"cr"+parentNode.id+"\" border=0"+
                  " src=\""+imgBase+"dt_"+( parentNode.idx < parentNode.parent.childs.length-1
                                                   ? "" : "last" )+"node.gif\">"
        else if ( parentNode.isOpen )
        {
            document.getElementById("cr"+parentNode.id).src = imgBase+""+
                                                   ( parentNode.idx < parentNode.parent.childs.length-1
                                                     ? "dt_mnode.gif" : "dt_mlastnode.gif" );
            document.getElementById("i"+parentNode.id).cells[parentNode.level+1].innerHTML = "<img id='f"+parentNode.id+"'"+
                                " src='"+imgBase+( parentNode.imgO != null
                                                   ? parentNode.imgO
                                                   : "dt_folderopen.gif" )+"' border=0>";
        }
        document.getElementById("tree_table").style.cursor = "default";
        top.window.status = "";
    }
}

function deleteNode(id)	{
    var node = getTreeItem(id);
    if ( node == null ) return false;

    // remove all childs
    while ( node.childs.length > 0 )
        deleteNode(node.childs[node.childs.length-1].id);

    if ( selectedNode != null && selectedNode.id == id ) selectedNode = null;
    if ( isItIE )
    {
        // remove if displayed
        if ( document.getElementById("i"+id) != null )
        {
            document.getElementById("i"+id).style.display = "none";
            if ( selectedNode != null && selectedNode.id == "i"+id )
                selectedNode = null;
            document.getElementById("i"+id).id = "removed by tch";
            document.getElementById("a"+id).id = "removed by tch";
            document.getElementById("f"+id).id = "removed by tch";
            if ( document.getElementById("cr"+id) != null ) document.getElementById("cr"+id).id = "removed by tch";
            //document.all["i"+id].removeNode(true);
        }
        // change corner to previous node
        if ( node.idx == 0 && node.parent.childs.length == 1 )
        {
            var r = document.getElementById("i"+node.parent.id);
            if ( node.parent.parent != null )
                r.cells[node.parent.level].innerHTML = "<img src='"+imgBase+"dt_"+
                                                                 ( node.parent.idx == node.parent.parent.childs.length-1 ? "last" : "" )+"node.gif' border=0>";
        }
        else if ( node.idx == node.parent.childs.length-1 )
        {
            var prevChild = node.parent.childs[node.idx-1];
            var r = document.getElementById("i"+prevChild.id);
            var iHTML = ( prevChild.childs.length > 0 || prevChild.hasUnloadedChild
                          ? "<a onClick='return clickCross(\""+prevChild.id+"\");' href='javascript:void(0)' onFocus='blur();'>"+
                             "<img id='cr"+prevChild.id+"' src='"+imgBase+"dt_"+( prevChild.isOpen ? "m" : "p" )+"lastnode.gif' border=0></a></td>"
                          : "<img src='"+imgBase+"dt_lastnode.gif' border=0>" );
            r.cells[node.parent.level+1].innerHTML = iHTML;

            if ( prevChild.childs.length > 0 || prevChild.hasUnloadChilds )
            {
                lastChildId = getLastChildId(prevChild);
                var rows = document.getElementById("tree_table").rows;
                var flag = false;
                for (i = 0; i < rows.length; i++)
                {
                    if ( flag )
                        rows[i].cells[prevChild.level].innerHTML = "<img src='"+imgBase+"dt_blank.gif' border=0>";
                    if ( rows[i].id == "i"+lastChildId )
                        break;
                    if ( rows[i].id == "i"+prevChild.id )
                        flag = true;
                }
            }
        }
    }

    // remove from script tree
    if ( node.parent == null )
        treeRoot = null;
    else
    {
        for (var i=node.idx; i < node.parent.childs.length-1; i++)
        {
            node.parent.childs[i] = node.parent.childs[i+1];
            node.parent.childs[i].idx--;
        }
        node.parent.childs.length = node.parent.childs.length-1;
    }
    if ( !isItIE ) repaintTree();


    return true;
}



function repaintModelTree()	{
    var table = document.getElementById("tree_table");
    var count = table.rows.length;
    for (var i = 0; i<count; i++)
        table.deleteRow(0);
    repaintItemFromModel(treeRoot, true, table);
}


function repaintItemFromModel(node, isVisible, table)	{
    // display node row
    newRow = table.insertRow(table.rows.length);
    newRow.id = "i"+node.id;
    newRow.style.display = (isVisible?"":"none");
    getNodeRowForRepaintModel(node, newRow);
    // display childs
    if ( node.childs != null && ( isItIE || node.isOpen ) )
        for (var i=0; i < node.childs.length; i++)
            repaintItemFromModel(node.childs[i], ( isVisible && node.isOpen ), table);
}


function getNodeRowForRepaintModel(node, newRow)	{
    var rowStr, tdCounter;

    if ( node.level != 0 )
    {
        var cell = newRow.insertCell(newRow.cells.length);
        cell.width = "1%";
        cell.innerHTML = "<img src='"+imgBase+"dt_blank.gif' border=0>";
        var tdCounter = 1;
    }
    else
    {
        rowStr = "";
        tdCounter = 0;
    }

    for (var i=0; i < node.level-1; i++)
        if ( a32[i].childs.length != 0 )
        {
            var vs = ( ( a32[i+1].idx < a32[i].childs.length-1 )
                       ? "dt_vertline.gif" : "dt_blank.gif" );
            cell = newRow.insertCell(newRow.cells.length);
            cell.width = "1%";
            cell.innerHTML  = "<img src='"+imgBase+""+vs+"' border=0>";
            tdCounter++;
        }

    if ( node.childs.length != 0 || node.hasUnloadedChild )
    {
        var crossImg = ( node.parent != null && ( node.idx < node.parent.childs.length-1 )
                         ? "dt_"+( node.isOpen ? "m" : "p" )+"node.gif" : "dt_"+( node.isOpen ? "m" : "p" )+"lastnode.gif" );
        cell = newRow.insertCell(newRow.cells.length);
        cell.width = "1%";
        cell.innerHTML = "<a onClick='return clickCross(\""+node.id+"\");' href='javascript:void(0)' onFocus='blur();'>"+
                        "<img id='cr"+node.id+"' src='"+imgBase+""+crossImg+"' border=0></a>";
        tdCounter++;
        cell = newRow.insertCell(newRow.cells.length);
        cell.width = "1%";
        cell.innerHTML = "<img id='f"+node.id+"' src='"+imgBase+
                  ( node.isOpen
                    ? ( node.imgO == null ? "dt_folderopen.gif" : node.imgO )
                    : ( node.imgC == null ? "dt_folderclosed.gif" : node.imgC ) )+"' border=0>";
        tdCounter++;
    }
    else
    {
        var vs = ( node.parent != null && ( node.idx < node.parent.childs.length-1 )
                         ? "dt_node.gif" : "dt_lastnode.gif" );
        cell = newRow.insertCell(newRow.cells.length);
        cell.width = "1%";
        cell.innerHTML = "<img id='cr"+node.id+"' src='"+imgBase+""+vs+"' border=0>";
        tdCounter++;
        cell = newRow.insertCell(newRow.cells.length);
        cell.width = "1%";
        cell.innerHTML = "<img id='f"+node.id+"' src='"+imgBase+( node.imgC == null
                                                                        ? "dt_doc.gif"
                                                                        : node.imgC )+"' border=0>";
        tdCounter++;
    }

    if ( checkbox == 1 && node.hasCheckbox )
    {
        cell = newRow.insertCell(newRow.cells.length);
        cell.width = "1%";
        cell.style.align = "center";
        cell.style.valign = "middle";
        cell.innerHTML =  "<input name='cb"+node.id+"' type=checkbox"+
                          " onClick='return clickCheck(\""+node.id+"\", this.checked)' onFocus='blur();'"+
                          ( node.isChecked ? " checked" : "" )+">";
        tdCounter++;
    }
    cell = newRow.insertCell(newRow.cells.length);
    cell.noWrap = true;

    cell.colSpan = (treeDeep+cross+icons+checkbox-tdCounter+1)+( !isItIE && selectedNode!=null && node.id==selectedNode.id ? " bgcolor='"+sColor+"'" : "" );
    cell.innerHTML =   "&nbsp;<a id='a"+node.id+"' class='label' href='javascript:void(0)'"+" onClick='return clickNode(\""+node.id+"\",this);'>"+node.label+"</a>";

	if (isItIE && selectedNode != null && node.id == selectedNode.id)	{
		if (isItIE)	{
			document.getElementById("a"+node.id).style.backgroundColor = sColor;
			document.getElementById("a"+node.id).hideFocus = true;
			document.getElementById("a"+node.id).firstChild.className = "slabel";
		}else
			repaintTree();
	}

    a32[node.level] = node;
    a32.length = node.level+1;

    return true;
}


function moveUpInModel(node)	{
    if (node==null || node.parent==null || node.idx<1) return false;
    var nodeUp = node.parent.childs[node.idx-1];
    var nodeIdx = node.idx;
    node.idx -= 1; nodeUp.idx += 1;
    node.parent.childs[nodeIdx-1] = node;
    node.parent.childs[nodeIdx] = nodeUp;
}



function moveDownInModel(node)	{
    if (node==null || node.parent==null || node.idx+1>=node.parent.childs.length) return false;
    var nodeDown = node.parent.childs[node.idx+1];
    var nodeIdx = node.idx;
    node.idx += 1; nodeDown.idx -= 1;
    node.parent.childs[nodeIdx+1] = node;
    node.parent.childs[nodeIdx] = nodeDown;
}


function showItemRepaint(node)	{
    // display node row
    var tRow = document.getElementById("i"+node.id);
    nodeRowRepaint(node, tRow);

    // display childs
    if ( node.childs != null && ( isItIE || node.isOpen ) )
        for (var i=0; i < node.childs.length; i++)
            showItemRepaint(node.childs[i]);
}


function nodeRowRepaint(node, tRow)	{
    var rowStr, tdCounter;
    var rowCell;
    if ( node.level != 0 )
    {
        tRow.cells(0).width = "1%";
        tRow.cells(0).innerHTML = "<img src='"+imgBase+"dt_blank.gif' border=0>";
        var tdCounter = 1;
    }
    else
    {
        tdCounter = 0;
    }
    for (var i=0; i < node.level-1; i++)
        if ( a32[i].childs.length != 0 )
        {
            var vs = ( ( a32[i+1].idx < a32[i].childs.length-1 )
                       ? "dt_vertline.gif" : "dt_blank.gif" );
            tRow.cells(tdCounter).width = "1%";
            tRow.cells(tdCounter).innerHTML = "<img src='"+imgBase+""+vs+"' border=0>";
            tdCounter++;
        }

    if ( node.childs.length != 0 || node.hasUnloadedChild )
    {
        var crossImg = ( node.parent != null && ( node.idx < node.parent.childs.length-1 )
                         ? "dt_"+( node.isOpen ? "m" : "p" )+"node.gif" : "dt_"+( node.isOpen ? "m" : "p" )+"lastnode.gif" );
        tRow.cells(tdCounter).width = "1%";
        tRow.cells(tdCounter).innerHTML = "<a onClick='return clickCross(\""+node.id+"\");' href='javascript:void(0)' onFocus='blur();'>"+
                        "<img id='cr"+node.id+"' src='"+imgBase+""+crossImg+"' border=0></a>";
        tdCounter++;
        tRow.cells(tdCounter).width = "1%";
        tRow.cells(tdCounter).innerHTML = "<img id='f"+node.id+"' src='"+imgBase+
                  ( node.isOpen
                    ? ( node.imgO == null ? "dt_folderopen.gif" : node.imgO )
                    : ( node.imgC == null ? "dt_folderclosed.gif" : node.imgC ) )+"' border=0>";
        tdCounter++;
    }
    else
    {
        var vs = ( node.parent != null && ( node.idx < node.parent.childs.length-1 )
                         ? "dt_node.gif" : "dt_lastnode.gif" );
        tRow.cells(tdCounter).width = "1%";
        tRow.cells(tdCounter).innerHTML = "<img id='cr"+node.id+"' src='"+imgBase+""+vs+"' border=0>";
        tdCounter++;
        tRow.cells(tdCounter).width = "1%";
        tRow.cells(tdCounter).innerHTML = "<img id='f"+node.id+"' src='"+imgBase+( node.imgC == null
                                                                        ? "dt_doc.gif"
                                                                        : node.imgC )+"' border=0>";
        tdCounter++;
    }

    if ( checkbox == 1 && node.hasCheckbox )
    {
        tRow.cells(tdCounter).width = "1%";
        tRow.cells(tdCounter).innerHTML = "<input name='cb"+node.id+"' type=checkbox"+
                          " onClick='return clickCheck(\""+node.id+"\", this.checked)' onFocus='blur();'"+
                          ( node.isChecked ? " checked" : "" )+">";
        tdCounter++;
    }
    tRow.cells(tdCounter).noWrap = true;
    tRow.cells(tdCounter).innerHTML = "&nbsp;<a id='a"+node.id+"' class='label' href='javascript:void(0)'"+
                          ( (isItIE && selectedNode!=null && node.id == selectedNode.id) ? " style='background-color:"+sColor+"'": "" )+" onClick='return clickNode(\""+node.id+"\",this);'>"+node.label+"</a>";

    a32[node.level] = node;
    a32.length = node.level+1;

    return true;
}


function moveNodeUp(node)	{
    if (node==null || node.parent==null || node.idx<1) return false;
    var nodeUp = node.parent.childs[node.idx-1];
    if (!isItIEforTree)
    {
        moveUpInModel(node);
        repaintModelTree();
        return true;
    }
    moveNodeDown(nodeUp);
    return true;
}


function moveNodeDown(node)	{
    var table =  document.getElementById("tree_table");
    if (node==null || node.parent==null || node.idx+1>=node.parent.childs.length) return false;
    if (!isItIEforTree)
    {
        moveDownInModel(node);
        repaintModelTree();
        return true;
    }
    var nodeDown = node.parent.childs[node.idx+1];
    var nextNodeParent;
    var count = 0;
    var tRowFrom = document.getElementById("i"+node.id);
    var tRowTo = document.getElementById("i"+nodeDown.id);
    var needToRepaint = false;
    if (nodeDown.idx+1<nodeDown.parent.childs.length)
        nextNodeParent = nodeDown.parent.childs[nodeDown.idx+1];
    else
    {
         nextNodeParent = getNextParentNode(nodeDown);
         needToRepaint = true;
         if (nextNodeParent==null)
         {
            count = table.rows.length - tRowTo.rowIndex;
         }
    }
    if (count==0)
    {
        var tRowNext = document.getElementById("i"+nextNodeParent.id);
        count = tRowNext.rowIndex - tRowTo.rowIndex-1;
    }
    var indexRowFrom = tRowFrom.rowIndex;
    var indexRowTo = ( nextNodeParent == null
                       ? -1 : tRowTo.rowIndex + count );
    var col = tRowTo.rowIndex - indexRowFrom;
    for (var i = 0; i<col; i++)
    {
       table.moveRow(indexRowFrom, indexRowTo);
    }
    var nodeIdx = node.idx;
    nodeDown.parent.childs[nodeIdx+1] = node;
    nodeDown.parent.childs[nodeIdx] = nodeDown;
    nodeDown.parent.childs[nodeIdx].idx = nodeIdx;
    nodeDown.parent.childs[nodeIdx+1].idx = nodeIdx+1;
    if ( nextNodeParent == null )
        showItemRepaint(treeRoot);
    else
    {
        if ( needToRepaint )
            showItemRepaint(nextNodeParent.parent);
    }
    return true;
}


function getNextParentNode(node)	{
    if (node.parent == null) return null;
    if (node.parent.childs.length == node.idx+1)
        return getNextParentNode(node.parent);
    else
        return node.parent.childs[node.idx+1];
}


function getNextTreeItem(id)	{
	var nd = getTreeItem(id);
	if (nd == null || nd.parent == null || nd.parent.childs.length == 1) return null;
	var nextItem = nd.idx+1;
	if (nextItem > nd.parent.childs.length - 1)
		nextItem = 0;

	return nd.parent.childs[nextItem];
}


function getLabelWithoutFont(sLabel)	{
		return sLabel.substring(sLabel.indexOf(">")+1, sLabel.lastIndexOf("<"));	
}


function sortParentNode(node)	{
		if (node==null || node.parent==null || node.parent.childs.length==1 ) return false;
		var table =  document.getElementById("tree_table");
		var parentNode = node.parent;
		var curNode, nodeIdx;
		for (var i = 0; i<parentNode.childs.length-1; i++)
		{
				curNode = parentNode.childs[i];
				nodeIdx = curNode.idx;
				for (var j = i+1; j<parentNode.childs.length; j++)
				{
						replaceNode = parentNode.childs[j];
						replaceNodeIdx = replaceNode.idx;
						if (getLabelWithoutFont(curNode.label) > getLabelWithoutFont(parentNode.childs[j].label))
						{
								curNode.parent.childs[replaceNodeIdx] = curNode;
								curNode.parent.childs[nodeIdx] = replaceNode;
								curNode.parent.childs[nodeIdx].idx = nodeIdx;								
								curNode.parent.childs[replaceNodeIdx].idx = replaceNodeIdx;
								document.getElementById("af"+curNode.id).className = "label";
								document.getElementById("af"+replaceNode.id).className = "label";								
								break;
						}
				}
		}
		repaintModelTree();		
		return true;
}


function setLabel2Node(newLabel, node)	{
//	this.label = newLabel;
//	if ( isItIE )	{
		var al = document.getElementById("a"+node);
		if ( al != null ) 
			al.innerHTML = newLabel;
//	}else
//		repaintTree();
}
