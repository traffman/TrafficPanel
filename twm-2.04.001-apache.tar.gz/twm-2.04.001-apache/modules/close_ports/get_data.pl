#!/usr/bin/perl -w

BEGIN   {
    sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
    (my $file = __FILE__) =~ s/(\/?modules)?(\/?close_ports)?\/?\w+\.pl$/&getPoints($1,$2)/e;
    $file = './' if $file eq '/';$file .= "bin";
    unshift(@INC, $file);
}


use strict;
use Data::Dumper;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
my $xml = readModuleConfigFile($cm{ports});
if (ref $xml->{rule} eq 'HASH')
{
	printRow($xml->{rule});
}
else
{
	
	printRow($_) for (@{$xml->{rule}});
}


sub printRow
{
	print "$_[0]->{port} $_[0]->{proto} $_[0]->{interface}\n";
}
