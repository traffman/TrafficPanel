var isNetscape = (navigator.appName == "Netscape");
var browserVersion = parseInt(navigator.appVersion);
var isNN6Comp = (isNetscape && (browserVersion >= 5));
var isOldNN = (isNetscape && (browserVersion < 5));
var isIEComp = ((navigator.appName == "Microsoft Internet Explorer") 
	|| isNN6Comp);
var isNN = (isNetscape && (document.layers));
var isValidBrowser = (isIEComp || isNN);

var ppcX = 4;
var ppcY = 4;
var isCVisible;
var calfrmName;
var howManyDigits;
var maxYearList;
var minYearList;
var todayDate = new Date; 
var curDate = new Date;
var curBoxDate;
var curImg;
var curDateBox;
var minDate = new Date;
var maxDate = new Date;
var hideDropDowns;
var IsUsingMinMax;
var FuncsToRun;
var m_names = new makeArray0('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
var days  = new makeArray0(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
var dow   = new makeArray0('Su','Mo','Tu','We','Th','Fr','Sa');
var str_img_prev = '<img src="'+img_prev_src+'" name="prev" width=22 height=22 border=0>';
var str_img_next = '<img src="'+img_next_src+'" name="next" width=22 height=22 border=0>';
var str_img_close = '<img src="'+img_close_src+'" name="close" width=15 height=14 border=0>';
var day_cell_bg = '#e7eef0';
var cell_border = '#c8d3d7';
var header_bg = '#c8d3d7';
var header_text = '#000000';
var grey_date_style = 
	'font-family:verdana; font-size:8pt; color:#999999;';
var base_link_style = 'font-family:verdana; font-size:8pt;'
	+ 'color:#000000;';
var important_link_style = 
	'font-family:Verdana,Arial,sans-serif; font-size:8pt;'
	+ ' color:#ff0000;';
var header_style = 'font-family:verdana; font-size:8pt;'
        + ' font-weight:bold; color:' + header_text;
var minYearList = todayDate.getFullYear() - 10;
var maxYearList = todayDate.getFullYear() + 10;
var isCVisible = false;

function calSwapImg(whatID) {
    if (document.images && !isCVisible && document.images[whatID]) {
        document.images[whatID].src = img_calendar_src;
    }
    return true;
}

function getOffsetLeft (el) {
    var ol = el.offsetLeft;
    while ((el = el.offsetParent) != null)
        ol += el.offsetLeft;
    return ol;
}

function getOffsetTop (el) {
    var ot = el.offsetTop;
    while((el = el.offsetParent) != null)
        ot += el.offsetTop;
    return ot;
}


function showCalendar(frmName,dteBox,btnImg,posX,posY,hmd,hideDrops,MnDt, MnMo, MnYr, MxDt, MxMo, MxYr,runFuncs)	{
    hideDropDowns = hideDrops;
    howManyDigits = hmd;
    FuncsToRun = runFuncs;
    calfrmName = frmName;
    if (isCVisible) {
        hideCalendar();
    }else	{
        if (document.images['close'] != null ) 
	    document.images['close'].src = img_close_src;
        if (document.images['prev'] != null ) 
	    document.images['prev'].src = img_prev_src;
        if (document.images['next'] != null ) 
	    document.images['next'].src = img_next_src;
        if (hideDropDowns) {
	    toggleDropDowns('hidden');
	}
        if ((MnDt!=null) && (MnMo!=null) && (MnYr!=null) && (MxDt!=null) 
					&& (MxMo!=null) && (MxYr!=null)) {
            IsUsingMinMax = true;
            minDate.setDate(MnDt);
            minDate.setMonth(MnMo-1);
            minDate.setFullYear(MnYr);
            maxDate.setDate(MxDt);
            maxDate.setMonth(MxMo-1);
            maxDate.setFullYear(MxYr);
        }
        else {
            IsUsingMinMax = false;
        }
        
        curImg = btnImg;
        curDateBox = dteBox;
        if ( isIEComp ) {
            ppcX = getOffsetLeft(document.getElementsByName(btnImg)[0]) + posX;    
            ppcY = getOffsetTop(document.getElementsByName(btnImg)[0]) + posY;
        }else if (isNN)	{
            ppcX = document.getElementsByName(btnImg)[0].x + posX; 
            ppcY = document.getElementsByName(btnImg)[0].y + posY;
        }
        domlay('popupcalendar',1,ppcX,ppcY,Calendar(todayDate.getMonth(), todayDate.getFullYear()));       
//domlay('popupcalendar',1,ppcX,ppcY,Calendar(curDate.getMonth(),curDate.getFullYear()));
        isCVisible = true;
    }
}

function toggleDropDowns(showHow){
    var i; var j;
    for (i=0;i<document.forms.length;i++) {
        for (j=0;j<document.forms[i].elements.length;j++) {
            if (document.forms[i].elements[j].tagName == "select") {
                if (document.forms[i].name != "f_Calendar")
                    document.forms[i].elements[j].style.visibility=showHow;
            }
        }
    }
}

function hideCalendar()	{
    domlay('popupcalendar',0,ppcX,ppcY);
    calSwapImg(curImg);
    isCVisible = false;
    if (hideDropDowns) {
	toggleDropDowns('visible');
    }
}

function calClick() {
        window.focus();
}


function domlay(id,trigger,lax,lay,content)	{
	if (trigger=="1")	{
		if (document.layers)
			document.layers[''+id+''].visibility = "show";
		else if (document.all) 
			document.all[''+id+''].style.visibility = "visible";
		else if (document.getElementById) 
			document.getElementById(''+id+'').style.visibility = "visible";
	}else if (trigger=="0")	{
		if (document.layers) 
			document.layers[''+id+''].visibility = "hide";
		else if (document.all) 
			document.all[''+id+''].style.visibility = "hidden";
		else if (document.getElementById) 
			document.getElementById(''+id+'').style.visibility = "hidden";
	}

    if (lax)	{
		if (document.layers)	{ 
			document.layers[''+id+''].left = lax;
		}else if (document.all)	{
			document.all[''+id+''].style.left=lax;
		}else if (document.getElementById)	{
			document.getElementById(''+id+'').style.left = lax+"px";
		}
    }

	if (lay)	{
		if (document.layers)	{
			document.layers[''+id+''].top = lay;
		}else if (document.all)	{
			document.all[''+id+''].style.top = lay;
		}else if (document.getElementById)	{
			document.getElementById(''+id+'').style.top = lay+"px";
		}
	}

    if (content)	{
		if (document.layers)	{
			sprite = document.layers[''+id+''].document;
			sprite.open();
			sprite.writeln(content);
			document.close();
		}else if (document.all)	{
			document.all["popupcalendar"].innerHTML = content;
		}else if (document.getElementById)	{
			rng = document.createRange();
			el = document.getElementById(''+id+'');
			rng.setStartBefore(el);
			htmlFrag = rng.createContextualFragment(content)
			while (el.hasChildNodes())
				el.removeChild(el.lastChild);
			el.appendChild(htmlFrag);
		}
	}
}


function Calendar(whatMonth,whatYear) {
    var datecolwidth;
    var startMonth;
    var startYear;
    startMonth=whatMonth;
    startYear=whatYear;
    curDate.setMonth(whatMonth);
    curDate.setFullYear(whatYear);
    curDate.setDate(todayDate.getDate());

    var mainCForm = '<form name=f_Calendar action="" method=get>';
    var mainCTable = '<table border=0 class=cal-Table cellspacing=0 cellpadding=0>';
    var output;
    if (isNN6Comp) {
        output = mainCForm + mainCTable;
    } else {
        output = mainCTable + mainCForm;
    }

    output += '<tr><td width="185"' + 'bgcolor="' + header_bg 
	+ '"><table width=\"100%\"'
	+ ' cellspacing="1" cellpadding="1" border="0"><tr valign="middle">'
	+ '<td width="15%" align="right">';
    output += isOldNN ? '&nbsp;'
	: '<a href="#" onClick="javascript:scrollMonth(-1); return false;">'
		+ str_img_prev + '</a>';
    output += '</td><td width="15%" style=" ' + header_style 
	+ ' ">'	+ '<select style=select  name="cboMonth" onChange="changeMonth();">';
    for (month=0; month<12; month++) {
		if (month == whatMonth) {
		    output += '<option value="' + month + '" selected>' + m_names[month] + '</option>';
		}else	{
	    output += '<option value="' + month + '">' + m_names[month] + '</option>';
		}
    }
    output += '</select></td><td width="15%"  style=" ' + header_style 
	+ ' ">'	+ '<select style=select name="cboYear" onChange="changeYear();">';
    for (year=minYearList; year<maxYearList; year++) {
        if (year == whatYear) {
	    output += '<option value="' + year 
		+ '" selected>' + year + '</option>';
	} else {
 	    output += '<option value="' + year 
		+ '">'          + year + '</option>';
	}
    }
    output += '</select></td><td align="left" width="15%">'
    output += isOldNN ? '&nbsp;'
	: '<a href="#" onClick="javascript:scrollMonth(1); return false;">'
		+ str_img_next + '</a>';
    output += '</td><td align="right" valign="top">'
	+ '<a href="#" onClick="javascript:hideCalendar(); return false;">'
	+ str_img_close + '</a></td></tr></table></td></tr>'
	+ '<tr><td width="185" align="center" bgcolor="' + cell_border + '">';
    firstDay = new Date(whatYear,whatMonth,1);
    startDay = firstDay.getDay();
    if (((whatYear % 4 == 0) && (whatYear % 100 != 0)) || (whatYear % 400 == 0)) {
         days[1] = 29;
    } else {
         days[1] = 28;
    }
    output += '<table width="100%" cellspacing="1" cellpadding="2" border="0"><tr>';
    for (i=0; i<7; i++) {
        if (i == 0 || i == 6) {
            datecolwidth = "15%";
        } else {
            datecolwidth = "14%";
        }
        output += '<td width="' + datecolwidth + '" bgcolor="' + header_bg 
		+ '" align="center" valign="middle"><span style="' 
		+ header_style +'">' + dow[i] +'</span></td>';
    }
    output += '</tr><tr>';
    var column = 0;
    var lastMonth = whatMonth - 1;
    var lastYear = whatYear;
    if (lastMonth == -1) { lastMonth = 11; lastYear=lastYear-1;}
    for (i = 0; i < startDay; i++, column++) {
        output += getDayLink((days[lastMonth]-startDay+i+1),true,lastMonth,lastYear);
    }
    for (i = 1; i <= days[whatMonth]; i++, column++) {
        output += getDayLink(i,false,whatMonth,whatYear);
        if (column == 6) {
            output += '</tr><tr>';
            column = -1;
        }
    }
    
    var nextMonth = whatMonth+1;
    var nextYear = whatYear;
    if (nextMonth==12) { 
		nextMonth=0; nextYear=nextYear+1;
    }
    if (column > 0) {
        for (i=1; column<7; i++, column++) {
            output +=  getDayLink(i,true,nextMonth,nextYear);
        }
        output += '</tr></table></td></tr>';
    }else	{
        output = output.substr(0,output.length-4); 
        output += '</table></td></tr>';
    }
    
    if (isNN6Comp) {
        output += '</table></form>';
    }else	{
        output += '</form></table>';
    }
    curDate.setDate(1);
    curDate.setMonth(startMonth);
    curDate.setFullYear(startYear);
    return output;
}

function getDayLink(linkDay,isGreyDate,linkMonth,linkYear) {
    var templink;
    if (!(IsUsingMinMax)) {
        if (isGreyDate) {
            templink = '<td align="center" bgcolor="' + day_cell_bg 
		+ '" class="cal-DayCell">' + '<span style="' 
		+ grey_date_style +'" class="cal-GreyDate">' 
		+ linkDay+'</span></td>';
        }
        else {
            if (isDayToday(linkDay)) {
                templink='<td align="center" bgcolor="' + day_cell_bg 
		    + '" class="cal-DayCell">'+'<a style="'+important_link_style
		    + '" class="cal-TodayLink" onmouseover="self.status=\' \';'
		    + ' return true;" href="#" onclick="javascript:changeDay(' 
		    + linkDay + '); return false;">' + linkDay + '</a>' +'</td>';
            }
            else {
                templink='<td align="center" bgcolor="' + day_cell_bg 
		    + '" class="cal-DayCell">' + '<a style="' + base_link_style
		    + '" class="cal-DayLink" onmouseover="self.status=\' \';'
		    + ' return true;" href="#" onclick="javascript:changeDay(' 
		    + linkDay + '); return false;">' + linkDay + '</a>' +'</td>';
            }
        }
    }
    else {
        if (isDayValid(linkDay,linkMonth,linkYear)) {
            if (isGreyDate){
            	templink = '<td align="center" bgcolor="' + day_cell_bg 
		    + '" class="cal-DayCell">' + '<span style="' 
		    + grey_date_style +'" class="cal-GreyDate">'
		    +linkDay+'</span></td>';
            }
            else {
                if (isDayToday(linkDay)) {
 		    templink='<td align="center" bgcolor="' + day_cell_bg 
		        + '" class="cal-DayCell">'+'<a style="'+important_link_style
		        + '" class="cal-TodayLink" onmouseover="self.status=\' \';'
		        + ' return true;" href="#" onclick="javascript:changeDay(' 
		        + linkDay + '); return false;">' + linkDay + '</a>' +'</td>';
                }
                else {
                    templink='<td align="center" bgcolor="' + day_cell_bg 
		        + '" class="cal-DayCell">' + '<a style="' + base_link_style
		        + '" class="cal-DayLink" onmouseover="self.status=\' \';'
		        + ' return true;" href="#" onclick="javascript:changeDay(' 
		        + linkDay + '); return false;">' + linkDay + '</a>' +'</td>';
                }
            }
        }
        else {
            templink = '<td align="center" bgcolor="' + day_cell_bg 
		+ '" class="cal-DayCell">' + '<span style="' 
		+ grey_date_style + '" class="cal-GreyDate">'
		+ linkDay + '</span></td>';
        }
    }
    return templink;
}

function isDayToday(isDay) {
    return ((curDate.getFullYear() == todayDate.getFullYear()) 
		&& (curDate.getMonth() == todayDate.getMonth()) 
		&& (isDay == todayDate.getDate())) ;
}

function isDayValid(validDay, validMonth, validYear) {
    
    curDate.setDate(validDay);
    curDate.setMonth(validMonth);
    curDate.setFullYear(validYear);
    
    if ((curDate >= minDate) && (curDate <= maxDate)) {
        return true;
    }
    else {
        return false;
    }
}

function padout(number) {
 return (number < 10) ? '0' + number : number; 
}

function clearDay() {
    eval('document.' + calfrmName + '.' + curDateBox + '.value = \'\'');
    hideCalendar();
    if (FuncsToRun!=null)
        FuncsToRun(); 
}


function changeDay(whatDay) {
    curDate.setDate(whatDay);
    var year;
    if(howManyDigits==4){
      year = curDate.getFullYear();
    }
    else{
      year = (""+curDate.getFullYear()).substring(2,4);
     
    }
    eval('document.' + calfrmName + '.' + curDateBox + '.value = "' + 
	year + "-" + padout(m_names[curDate.getMonth()]) + "-" + padout(curDate.getDate())+ '"');
    hideCalendar();
    if (FuncsToRun!=null)
        FuncsToRun();
}


function scrollMonth(amount) {
    var monthCheck;
    var yearCheck;
    if (isIEComp) {
        monthCheck = document.forms.f_Calendar.cboMonth.selectedIndex + amount;
    } else if (isNN) {
        monthCheck = document.popupcalendar.document.forms.f_Calendar.cboMonth.selectedIndex + amount;
    }
    if (monthCheck < 0) {
        yearCheck = curDate.getFullYear() - 1;
        if ( yearCheck < minYearList ) {
            yearCheck = minYearList;
            monthCheck = 0;
        }
        else {
            monthCheck = 11;
        }
        curDate.setFullYear(yearCheck);
    }
    else if (monthCheck >11) {
        yearCheck = curDate.getFullYear() + 1;
        if ( yearCheck > maxYearList-1 ) {
            yearCheck = maxYearList-1;
            monthCheck = 11;
        }
        else {
            monthCheck = 0;
        }      
        curDate.setFullYear(yearCheck);
    }
    
    if (isIEComp) {
        curDate.setMonth(document.forms.f_Calendar.cboMonth.options[monthCheck].value);
    }else if (isNN)	{
        curDate.setMonth (document.popupcalendar.document.forms.f_Calendar.cboMonth.options[monthCheck].value);
    }
    domlay('popupcalendar',1,ppcX,ppcY,Calendar(curDate.getMonth(),curDate.getFullYear()));
}


function changeMonth()	{
    if (isIEComp) {        
        curDate.setMonth(document.forms.f_Calendar.cboMonth.options[document.forms.f_Calendar.cboMonth.selectedIndex].value);
        domlay('popupcalendar',1,ppcX,ppcY,Calendar(curDate.getMonth(),curDate.getFullYear()));
    }else if (isNN)	{
        curDate.setMonth(document.popupcalendar.document.forms.f_Calendar.cboMonth.options[document.popupcalendar.document.forms.f_Calendar.cboMonth.selectedIndex].value);
        domlay('popupcalendar',1,ppcX,ppcY,Calendar(curDate.getMonth(),curDate.getFullYear()));
    }
}


function changeYear()	{
    if (isIEComp)	{
        curDate.setFullYear(document.forms.f_Calendar.cboYear.options[document.forms.f_Calendar.cboYear.selectedIndex].value);
        domlay('popupcalendar',1,ppcX,ppcY,Calendar(curDate.getMonth(),curDate.getFullYear()));
    }else if (isNN)	{
        curDate.setFullYear(document.popupcalendar.document.forms.f_Calendar.cboYear.options[document.popupcalendar.document.forms.f_Calendar.cboYear.selectedIndex].value);
        domlay('popupcalendar',1,ppcX,ppcY,Calendar(curDate.getMonth(),curDate.getFullYear()));
    }
}


function makeArray0() {
	for (i = 0; i<makeArray0.arguments.length; i++)	{
		this[i] = makeArray0.arguments[i];
	}
}
