package Bandwidth;

require 5;

BEGIN	
{
	use TWM;
	use Data::Dumper;
}

sub new
{
	my $self = {
		this_module_code => 'http_bandwidth',
		ip_mask => '255.255.255.255'
	};
	return bless $self;
}

sub DESTROY	{
	my $self = shift;
	delete $self->{$_} for (keys %$self);
	undef(%$self);
	undef $self;
}


##################################################
# Converts pool xml to sorted array
##################################################
sub convertPool2Array
{
	my ($self, $item) = (shift, shift);
	my @items;
	if (ref $item->{pool} eq 'HASH')
	{
		if (exists($item->{pool}->{name}))
		{
			push @items, $item->{pool};
		}
		else
		{
			for (keys %{$item->{pool}})
			{
				$item->{pool}->{$_}->{name} = $_;
				push @items, $item->{pool}->{$_};
			}
		}
	}
	return sort {$a->{order} <=> $b->{order}} @items;
}


sub getClassName
{
	my ($self, $item, $name) = (shift, shift, shift);
	if (ref $item->{acl} eq 'HASH')
	{
		return [$item->{acl}->{name}, $item->{acl}->{label}] if (exists($item->{acl}->{name}) && $item->{acl}->{name} eq $name);
		for (keys %{$item->{acl}})
		{
			return [$_, $item->{acl}->{$_}->{label}] if ($_ eq $name);
		}
	}
	'';
}

##################################################
# Converts acl xml to array
##################################################
sub convertACL2Array
{
	my ($self, $item) = (shift, shift);
	my @items;
	if (ref $item->{acl} eq 'HASH')
	{
		if (exists($item->{acl}->{name}))
		{
			push @items, $item->{acl};
		}
		else
		{
			for (keys %{$item->{acl}})
			{
				$item->{acl}->{$_}->{name} = $_;
				push @items, $item->{acl}->{$_};
			}
		}
	}
	@items;
}

sub saveClass
{
	my ($self, $xml, $disable_logging) = (shift, shift, shift);
	saveModuleConfigFile($C->{$self->{this_module_code}}->{classes_config}, $xml, $self->{this_module_code});
	$self->runManageSquid();
}

sub savePool
{
	my ($self, $xml, $disable_logging) = (shift, shift, shift);
	saveModuleConfigFile($C->{$self->{this_module_code}}->{pools_config}, $xml, $self->{this_module_code});
	$self->runManageSquid();
}


sub runManageSquid
{
	my ($self, $disable_logging) = (shift, shift);
	run_twm_script('manageSquid.sh', $self->{this_module_code}, $disable_logging);
}


sub getACL
{
	my ($self, $name, $item) = (shift, shift, shift);
	if ($name)
	{
		if (ref $item->{acl}->{$name} eq 'HASH')
		{
			return $item->{acl}->{$name};
		}
		elsif ($item->{acl}->{name} eq $name)
		{
			return $item->{acl};
		}
	}
	return ();
}


sub parseData	
{
	my ($self, $data) = (shift, shift);
	my @items;
	for (@$data)
	{
		s/^\s+//;
		s/\s+$//;
		next if !$_;
		my %h = (
			'type' => '- as is -'
			);
		if (s/^\(\.\+\\\.\)\?(.+)//)
		{
			$h{'type'} = 'Server Name';
			$h{'fld'} = $1;
		}
		elsif (/^\\\.(.+)\$/)
		{
			$h{'type'} = 'File Extention';
			$h{'fld'} = $1;
		}
		elsif (/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/)
		{
			$h{'fld'} = $1;
		}
		else
		{
			$h{'fld'} = $_;
		}
		$h{'fld'} =~ s/\\\./\./g;
		push @items, \%h;
	}
	@items;
}

sub getFriendlyType
{
	my ($self, $data) = (shift, shift);
	if ($data eq 'src')
	{
		return 'IP address';
	}
	elsif ($data eq 'url_regex')
	{
		return 'Name';
	}
	elsif ($data eq 'urlpath_regex')
	{
		return 'Request URI';
	}
	return '';
}


return 1;
END {}
