#!/bin/bash

if [ -e "/usr/scripts/twm/squid" ]; then
	/usr/scripts/twm/squid $1
elif [ -e "/etc/init.d/squid" ]; then
	/etc/init.d/squid $1
else
	service squid $1
fi
