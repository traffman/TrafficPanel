#!/usr/bin/perl -w


BEGIN   
{
  (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
  unshift(@INC, $file);
}


use strict;
use CGI;
use TWM;
use Data::Dumper;
if (isDebug())
{
  use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasUserAccess;
print "Content-Type: text/html\n\n";
my $cg = new CGI;
my $todo = $cg->param("todo") || '';
my $title = "Server shutdown management";
my $time = 1;

my ($resultString, $debugString) = ('')x2;
if ($allowEdit && $todo)
{
	if ($todo eq 'halt')
	{
		$resultString = "halted";
		$todo = "-h +$time 'quick halt'";
	}
	else
	{
		$resultString = "rebooted";
		$todo = "-r +$time 'quick reboot'";
	}
	run_script("$cm{shutdown} $todo");
	$debugString = getWebDebugLog();
	$resultString = "Server will $resultString in $time min<br><br>";
	keepHistory($resultString);
}


print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
</head>
<body>
<form name=f1 action="" method=post>
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
  <tr>
    <td style="padding-left: 20px;">
<br>
<div>System name: ${\(join("<br>", run_script("$cm{uname} -a")))}</div>
<div>Uptime: ${\(join("<br>", run_script("$cm{uptime}")))}</div>
    </td>
  </tr>
  <tr>
    <td width=100%>
$debugString
<center>
<table width=200 style="padding-top: 100px;">
  <tr>
    <td align=middle>
<table width=100% bgcolor=#d0d0d0>
  <tr height=10><td colspan=2>&nbsp;<b>$resultString</b></td></tr>
  <tr height=20>
    <td style="padding-left: 5px;">&nbsp;Action:</td>
    <td>
      <select name=todo class=input>
        <option value=>
        <option value=reboot>Reboot
        <option value=halt>Halt
      </select>
    </td>
  </tr>

__EOF
if ($allowEdit)
{
	print <<__EOF;
  <tr height=20><td colspan=2>&nbsp;</td></tr>
  <tr height=20>
    <td>&nbsp;</td>
    <td><input type=submit class=control style="width: 70px;" name=submit value="Submit"></td>
  </tr>
__EOF
}
print <<__EOF;
  <tr height=20><td colspan=2>&nbsp;</td></tr>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>
</center>

<div class=help style="width: 400px; height: 100px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
You can see current system info and reboot or shutdown the server.
</div>

</body>
</html>
__EOF

__END__
