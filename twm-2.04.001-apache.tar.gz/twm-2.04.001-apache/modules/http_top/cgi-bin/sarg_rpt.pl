#!/usr/bin/perl -w

BEGIN   {
    (my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
    unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

sub read_index {
	my ($dt, $fl, $squid) = (shift, shift, shift);
	if (-e "../logs/$squid/$dt/$fl")
	{
		open(FILE, "../logs/$squid/$dt/$fl") || die "can't open file $!\n";
		print while (<FILE>);
		close(FILE);
	}
	else
	{
		print <<__EOF;
<html>
<body>
<table width=100% height=300 border=0>
  <tr>
    <td align=center valign=middle>Required report was not found.</td>
  </tr>
</table>
</body>
</html>
__EOF
	}
}

my $query = new CGI;
my $dt = $query->param(-name=>'dt');
my $fl = $query->param(-name=>'fl');
my $squid = $query->param('squid')||'';

print $query->header,
	$query->start_html('Sarg report page');

if ($dt && $fl)
{
	if ($fl =~ /d(\d{1,3}[._]\d{1,3}[._]\d{1,3}[._]\d{1,3})/)
	{ 
		$fl = "$1/d$1.html";
		read_index($dt,$fl,$squid);
	}
	elsif ($fl =~ /tt(\d{1,3}[._]\d{1,3}[._]\d{1,3}[._]\d{1,3})(.+\.html)/)
	{
		$fl = "$1/tt$1$2"; 
		read_index($dt,$fl,$squid);
	}
	elsif ($fl =~ /(\d{1,3}[._]\d{1,3}[._]\d{1,3}[._]\d{1,3})/)
	{
		$fl = "$1/$1.html"; 
		read_index($dt,$fl,$squid);
	}
	elsif ($fl =~ /\w{8}\.\w{4}/)
	{
		if (-e "../logs/$squid/$dt/$fl")
		{
			open(FILE, "../logs/$squid/$dt/$fl") || die "can't open file $!\n";
			if ($cm{top_sites} >= 100)
			{
				while (<FILE>)
				{
					print;
				}
			}
			else
			{
				local $/ = undef;
				my $num = ++$cm{top_sites};
				my @top = split(/<\w{2}><\w{2}\s\w{5}="\w{4}">$num<\/\w{2}><\w{2}\s\w{5}="\w{4}\d"><\w\s\w{4}="\w{4}:\/\/.+\n.+\n.+$|<\w{2}><\w{2}\s\w{5}="\w{4}">100<\/\w{2}><\w{2}\s\w{5}="\w{4}\d"><\w\s\w{4}="\w{4}:\/\/.+\n.+\n.+$/m, <FILE>);
				print $top[0],$top[2];
				close(FILE);
			}
		}
	}
	else 
	{
		read_index($dt, $fl);
	}
}
elsif (defined $dt)
{
	if ($dt =~ /(\d{4}\w{3}\d{2}-\d{4}\w{3}\d{2})(.\w{3})/)
	{
		run_twm_script("unpack.sh $ck{twmfolder} $1$2", $mc);
		system "$ck{twmfolder}modules/$mc/unpack.sh $ck{twmfolder} $1$2";
		read_index($1,'index.html',$squid);
	}
	else
	{
		read_index($dt,'index.html',$squid);
	}
}

print $query->end_html;

__END__
