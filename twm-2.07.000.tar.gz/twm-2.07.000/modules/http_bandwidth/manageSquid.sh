#!/bin/bash

if [ -e $TWMFOLDER/modules/http_bandwidth/manageSquid.pl ]; then
	/usr/bin/perl ${TWMFOLDER}/modules/http_bandwidth/manageSquid.pl
fi

exit 0
