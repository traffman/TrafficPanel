#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

sub read_index
{
	my ($fl) = (shift);
	if (-e $fl)
	{
		open(FILE, $fl) || die "can't open file $!\n";
		while (<FILE>) {print $_}
		close(FILE);
	}
	else
	{
		print <<__EOF;
<html>
<body>
<span style='display: none;'>$fl</span>
<table width=100% height=300 border=0>
  <tr>
    <td align=center valign=middle>Required report was not found.</td>
  </tr>
</table>
</body>
</html>
__EOF
	}
}

my $query = new CGI;
my $dt = $query->param(-name=>'dt');
my $fl = $query->param(-name=>'fl');
my $squid = $query->param("squid") || '';

print $query->header,
	$query->start_html('Sarg report page');

if (defined $dt && defined $fl)
{
	if ($fl =~ /d(\d{1,3}[_.]\d{1,3}[_.]\d{1,3}[_.]\d{1,3})/)
	{ 
		$fl = "$1/d$1.html";
	}
	elsif ($fl =~ /tt(\d{1,3}[_.]\d{1,3}[_.]\d{1,3}[_.]\d{1,3})(.+\.html)/)
	{ 
		$fl = "$1/tt$1$2";
	}
	elsif ($fl =~ /(\d{1,3}[_.]\d{1,3}[_.]\d{1,3}[_.]\d{1,3})/)
	{ 
		$fl = "$1/$1.html";
	}
}
elsif (defined $dt) 
{
	$fl = 'index.html';
} 
else 
{
	my $dt=`/bin/date +%Y%b%d`;
	chomp $dt;
	$fl = 'index.html';
}

read_index("../logs/$squid/$dt-$dt/$fl");

print $query->end_html;

__END__
