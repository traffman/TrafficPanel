#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasUserAccess;
print "Content-Type: text/html\n\n";

my $cg = new CGI;
my $todo = $cg->param('todo') || '';
my $todo2 = $cg->param('todo2') || '';
my $what = $cg->param('what') || '';
my $is_default = $cg->param('is_default') || '';
my $masq = $cg->param('masq') || '';
my $title = 'ISP management';
my $notification = '';

if ($cm{'show_up_pppd'})
{
	my $pppd = join("", run_script("$ck{ps} ax | $ck{grep} 'pppd call ' | $ck{grep} -v grep"));
	$notification = $pppd && "<br>There is up some pppd daemon already. Please check line bellow before start new one:\n<br>\n<pre>$pppd</pre>";
}

my $restarting_masq = join("", run_script("$ck{ps} ax | $ck{grep} masq.sh | $ck{grep} -v grep | $ck{wc} -l"));
chomp $restarting_masq;
my $masq_message = $restarting_masq?'<br><i><font size=3 color=330000>Please wait while masquerade script will finish...</font></i><br><br>':'';

my %isp_name;
my $isp_list = &getISP;
for(keys %$isp_list)
{
	$isp_name{$isp_list->{$_}->{shell}} = $isp_list->{$_}->{code}
}

my ($resultString, $debugString) = '' x 2;

if ($allowEdit) {

	if ($todo && $what) {
		run_twm_script("$cm{run_isp} $what $todo $is_default", $mc, 0);
		$debugString = getWebDebugLog();
		$resultString .= $isp_name{$what}." will be ${todo}ed soon.";
		$resultString =~ s/stoped/stopped/;
		keepHistory("Connect action: $cm{run_isp} $what $todo $is_default");
	}
	elsif ($todo2 && $what) {
		run_twm_script("$cm{run_isp} $what $todo2", $mc, 0);
		$debugString = getWebDebugLog();
		$resultString .= $isp_name{$what}." will be ${todo2} soon.";
		$resultString =~ s/stoped/stopped/;
		keepHistory("Connect action: $cm{run_isp} $what $todo2");
	}
	elsif ($masq) {
		run_twm_script($ck{_masq_script});
		$debugString = getWebDebugLog();
		$resultString = 'Masquerade restarted.';
		keepHistory("Masquerade restarted.");
	}

}

print $debugString if $debugString;
print "<div style=\"width: 300px; margin-top: 10px; padding-bottom: 20px; text-align: left; padding-left: 10px;\"><b>$resultString</b></div>" if $resultString;

my $gw = join("", run_script("$ck{ip} route | $ck{grep} default | $ck{gawk} '{print \$5}'"));
chomp $gw;

my %data;
my $if = undef;
my @ifinfo = run_script($ck{ifconfig});
for (@ifinfo)
{
	if (/^(\w\w\w\d+(\:\d+)?)\s+Link encap:(.+)/)
	{
		$if = $1;
		$data{$if}->{type} = $3;
		$data{$if}->{extra} .= "Default Gateway<br>" if ($gw eq $if);
	}
	elsif (/^\s+inet addr:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(.+)/)
	{
		$data{$if}->{ip} = $1;
		$data{$if}->{extra} .= "P-t-P addr: $1<br>" if ($2 =~ /P\-t\-P:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/);
	}
	elsif (/^\s+RX bytes\:\d+ \((.+?)\)  TX bytes\:\d+ \((.+?)\)/)
	{
		$data{$if}->{rx} = $1;
		$data{$if}->{tx} = $2;
	}
}

print <<__EOF;
<html>
<head>
<script src="/twm.js"></script>
<link href="/twm.css" rel=stylesheet type=text/css>
<META http-equiv="refresh" content="$cm{state_autorefresh}; URL=state.pl">
</head>
<body>
<form name=f1 action="" method=post>
<table cellpadding=0 cellspacing=0 border=0 width=720>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 width=100%>
  <tr>
    <td class=titlepage>$title</td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</table>
<span>$masq_message</span>
<span>$notification</span>
<table cellspacing=1 cellpadding=1 border=0 style="margin: 10 0 0 10;" width=720>
  <tr bgcolor=#dddddd>
    <td>
<table cellpadding=1 cellspacing=1 width=720 border=0>
  <tr height=24>
    <th>Interface</td>
    <th>ip</td>
    <th>Received</td>
    <th>Transfered</td>
    <th>Extra information</td>
__EOF
if(!$restarting_masq) {
print <<__EOF;
    <th>Default</td>
    <th>Action</td>
__EOF
}
print'</tr>';

my $current_gw = join("", run_script("$ck{route} -n|$ck{grep} 'UG'|wc -l"));
chomp $current_gw;
if ($current_gw)
{
	$current_gw = join("", run_script("$ck{route} -n|$ck{grep} 'UG'"));
	chomp $current_gw;
}


for(keys %$isp_list) {
	if (!$isp_list->{$_}{'attributes'}{'internal'}) {
		my ($f1,$f2);
		my $is_isp_up = join("", run_script("$ck{ifconfig} $isp_list->{$_}{'inf'} | $ck{grep} $isp_list->{$_}{'ip'} | $ck{grep} -v grep | $ck{wc} -l"));
		chomp $is_isp_up;
		if(!$restarting_masq) {
			$f2 = "<input type='hidden' name='what' value=$isp_list->{$_}{'shell'}>";
			if($is_isp_up) {
				$f2 .= "<input class=control type='submit' name='todo' value='stop' style='width: 50px'>";
				$f1 = 'Yes';
				if($isp_list->{$_}{'attributes'}{'default'}) {
					if($current_gw !~ $isp_list->{$_}{'inf'}) {
						$f1 = 'No';
						$f2 .= '&nbsp<input class=control type="submit" name="todo2" value="default">';
					}
				}
				else {
					if($current_gw !~ $isp_list->{$_}{'inf'}) {
						$f1 = 'No';
						$f2 .= '&nbsp<input class=control type="submit" name="todo2" value="default">';
					}
				}
			}
			else {
				if($isp_list->{$_}{'attributes'}{'default'}) {
					$f1 = "<input type='checkbox' name='is_default' value='default' checked>";
				}
				else {
					$f1 = "<input type='checkbox' name='is_default' value='default'>";
				}
				$f2 .= "<input class=control type='submit' name='todo' value='start' style='width: 50px;'>";
			}
		}
		$data{$isp_list->{$_}{'inf'}}{'f1'} = $f1;
		$data{$isp_list->{$_}{'inf'}}{'f2'} = $f2;
	}
}

for(keys %data) {
	print <<__EOF;
<form action='' method='post'>
<tr height=24 onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff><td
style='padding-left: 5px;'>$_ ${\(exists($isp_name{$_})?"($isp_name{$_})":'')}</td><td
style='padding-left: 5px;'>$data{$_}->{ip}</td><td
style='padding-left: 5px;'>$data{$_}->{rx}</td><td
style='padding-left: 5px;'>$data{$_}->{tx}</td><td
style='padding-left: 5px;'>$data{$_}->{extra}</td>
__EOF
	if(!$restarting_masq) {
		print <<__EOF;
<td align=center>${\($data{$_}{'f1'}||'')}</td>
<td style='padding-left: 5px;' align=middle valign=center>${\($data{$_}{'f2'}||'')}</td>
__EOF
	}
	print <<__EOF;
</tr>
</form>
__EOF
}

print <<__EOF;
</table>
    </td>
  </tr>
<!-- <tr height=20><td align=right><input class=control type=submit name=submit value="Refresh"></td></tr> -->
</table>

<p>Autorefresh is $cm{state_autorefresh} sec.
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
    </td>
  </tr>
__EOF

if ( ! $restarting_masq ) {
	print <<__EOF;
<table cellpadding=1 cellspacing=1 width=740>
	<tr><td align=right>
	<form action='' method='post'><input class=control type=submit name='masq' value='Restart masquerade'"></form>
	</td></tr>
</table>
__EOF
}

print <<__EOF;
</table>
</form>
<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This table shows statistics of all interfaces found in the server. 
In the round brackets of the "Interfaces" column you can see the interface name from the main configuration.
This page autorefreshes in $cm{state_autorefresh} seconds automatically to show live information. You can change the timeout in the config module.
</div>
</body>
</html>
__EOF

__END__
