#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(system\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
}

use strict;
use TWM;

my $host = $ARGV[0];
exit if ($host);

print <<__EOF;
fullrow=0

<div class="paneltitle"><span class="paneltitlerow">System information</span></div>
<div class="panelcontent">
<div class="panelcontentrow">
__EOF

my @i = run_script("$cm{uname} -a");
$i[0] =~ /^([^#]+?#\d+)\s*(\w{3}\s+[\w:\s]+\s*\d{4})\s*(.+)/;
my($kernel,$time,$arc) = ($1,$2,$3);
my @i2 = run_script("$cm{uptime}");

print_row($kernel,$time,$arc,$i2[0]);

=comment
<div style="margin: 3px;">System name: ${\(join("<br>", run_script("$cm{uname} -a")))}</div>
<div style="margin: 3px;">Uptime: ${\(join("<br>", run_script("$cm{uptime}")))}</div>
=cut

print <<__EOF;
</div>
</div>
__EOF

sub print_row
{
    my($kernel,$time,$arc,$uptime) = (shift,shift,shift,shift);
    print <<__EOF;
<div style='padding-left: 10px;'>$kernel</div>
<div style='padding-left: 10px;'>$time</div>
<div style='padding-left: 10px;'>$arc</div>
<br><div style='padding-left: 10px;'>Uptime:<br>$uptime</div>
__EOF
}

__END__
