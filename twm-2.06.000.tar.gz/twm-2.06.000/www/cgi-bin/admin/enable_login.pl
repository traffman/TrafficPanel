#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/\/admin\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;
my $allowEdit = &hasAdminAccess;
print "Content-Type: text/xml\n\n";
my $co = new CGI;
my $nick = $co->param('login');
my $enable = $co->param('enable');

my $login = &getLogin($nick);
my ($status, $message) = ('true', '');
if ($allowEdit && ref $login eq 'HASH')
{
	$login->{enabled} = $enable;
}
elsif (!$allowEdit)
{
	($status, $message) = ('false', 'Permission denied');
}
else
{
	($status, $message) = ('false', 'Login was not found');
}
saveLogin($login) if ($status eq 'true');

print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
