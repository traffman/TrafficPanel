#!/bin/bash

version=`cat version.conf | grep "version=" | sed -e "s/version=//g"`
cd ../
mv release twm-$version-apache

cp -Rf twm-$version-apache twm-$version
tar -czf twm-$version-apache.tar.gz twm-$version-apache

mv twm-$version/install/configure_VHOST.sh twm-$version/install/configure.sh
rm -Rf twm-$version/apache
tar -czf twm-$version.tar.gz twm-$version

