#!/usr/bin/perl -w

BEGIN   
{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use CGI;
use TWM;
use File::Copy;
use Data::Dumper;

if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}

&checkAuthorization;

print "Content-Type: text/html\n\n";

my $allowEdit = &hasAdminAccess;
my $co = new CGI;
my $strAllCBQ = "\n";
my $isp_list = &getISP;

print <<__EOF;
<html>
<head>
<title>Delay Access management</title>
<link href="/twm.css" rel=stylesheet type=text/css>
<script src="/twm.js"></script>
</head>
<body>
<script>
function formValidate()	{
	var f = document.forms.f1;
	f.values.value = "1";
	f.submit();
	return false;
}

function addItem()	{
	var obj = document.getElementById("cTable").tBodies[0];
	var tr = document.createElement("TR");
	tr.height = 25;
	var dt = '&&temp&&.'+Date.parse(new Date);
	document.getElementsByName("classes")[0].value += '#'+dt;
	tr.id = 'tr_'+dt;
	tr.setAttribute('path',dt);
	tr.onmouseover = function()	{ovrMouse(this);};
	tr.onmouseout = function()	{outMouse(this);};
	tr.className = "hover";
	var td = document.createElement("TD");
	td.width = 10;
	td.vAlign = "top";
	td.style.paddingTop = '15px';
	td.innerHTML = '<a href="" class=grid onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a>';
	tr.appendChild(td);
	var td = document.createElement("TD");
	td.vAlign = "top";
	td.style.border = '1px #eeeeee solid;';
	var s = ''+
		'<table cellpadding=1 cellspacing=1 border=0>'+
		'<tbody>'+
		'  <tr>'+
		'    <td>&nbsp;ID:</td>'+
		'    <td>&nbsp;<input class=control type=text name='+dt+'_id value="" maxlength=10 size=4></td>'+
		'  </tr>'+
		'  <tr>'+
		'    <td>&nbsp;Name</td>'+
		'    <td>&nbsp;<input class=control type=text name='+dt+'_name value="" maxlength=50 size=25></td>'+
		'  </tr>'+
		'</tbody>'+
		'</table>'+
		'<table cellpadding=0 cellspacing=0 border=0 width=100% id=class_'+dt+' style="display: block; padding: 5 5 5 5;" bgcolor=#eeeeee>'+
		'<tbody>'+
		'  <tr height=25>'+
		'    <td>&nbsp;Device Name:<td>'+
      		'    <td><select name='+dt+'_dev>'+
__EOF

print "'<option value=\"$_\">$_</option>'+\n" for (keys %$isp_list);
print <<__EOF;
	        '</select></td>'+
		'  </tr>'+
		'  <tr height=25>'+
		'    <td>&nbsp;Class Rate:<td>'+
		'    <td><input class=control type=text name='+dt+'_rate_speed value="" maxlength=50 size=10>'+
		'      <select name='+dt+'_rate_dim class=control>'+
		'        <option value="Mbit">MBit'+
		'        <option value="Kbit" >KBit'+
		'        <option value="b" >Bit'+
		'      </select>'+
		'    </td>'+
		'  </tr>'+
		'  <tr height=25>'+
		'    <td>&nbsp;Priority:<td>'+
		'    <td><input class=control type=text name='+dt+'_prio value="5" maxlength=50 size=10></td>'+
		'  </tr>'+
		'  <tr height=25>'+
		'    <td valign=top>&nbsp;Rules:<td>'+
		'    <td><textarea class=control name='+dt+'_rules cols=25 rows=3></textarea></td>'+
		'  </tr>'+
		'</tbody>'+
		'</table>';

	td.innerHTML = s;
	tr.appendChild(td);
	obj.appendChild(tr);
}


function removeRow(thisRow){
    thisRow.parentNode.removeChild(thisRow,true);
}


function chView(p1)	{
	var obj = document.getElementById("class_"+p1);
	if (!obj)
		return;

	if (obj.style.display == "none")	{
		obj.style.display = "block";
	}else	{
		obj.style.display = "none";
	}
}


function deleteItem(obj)	{
	var myregexp = new RegExp();
	myregexp.compile('#'+obj.parentNode.parentNode.getAttribute("path")+'#',"gi");
	document.getElementsByName("classes")[0].value = ('#'+document.getElementsByName("classes")[0].value+'#').replace(myregexp, '#');
	var myregexp = new RegExp();
	myregexp.compile('##',"gi");
	document.getElementsByName("classes")[0].value = document.getElementsByName("classes")[0].value.replace(myregexp, '#');
	removeRow(obj.parentNode.parentNode);
}
</script>
<form name=f1 action="" method=post onSubmit="formValidate(); return false;">
<input type=hidden name=values value="">
<table cellpadding=0 cellspacing=0 border=0 width=800>
  <tr>
    <td width=100%>
<table cellpadding=0 cellspacing=0 border=0 style="margin: 10 0 0 10;" width=100%>
  <tr>
    <td width=100%>
__EOF

my $xml = &readModuleConfigFile($cm{cbq_conf});
my $cbqlist = $xml->{item};

if (exists($cbqlist->{'class_rate_speed'}))
{
	$xml->{item} = copyHash($cbqlist);
	$cbqlist = $xml->{item};
}
my $resultString = "";

if ($allowEdit && $co->param("values"))
{
	foreach my $key (keys(%$cbqlist))
	{
		if ($co->param($key."_dev"))
		{
			$resultString .= populate_item($key, $cbqlist, $co);
		}
		else 
		{
		        delete($cbqlist->{$key});
		}
	}
}

if ($allowEdit && $co->param("classes"))
{
	my @classes = split /\#/, $co->param("classes");
	for (@classes)	
	{
		$resultString .= populate_item($_, $cbqlist, $co) if $_;

	}
}
if ($allowEdit && ($co->param("values") || $co->param("classes")) && !$resultString)
{
	saveModuleConfigFile($cm{cbq_conf}, $xml);
	my @res = run_twm_script($cm{build_cbq}, $mc);
	$resultString = " Data are saved and shaper restarted";
	$resultString .= getWebDebugLog();
}
else
{
	$xml = readModuleConfigFile($cm{cbq_conf});
	$cbqlist = $xml->{item};
}

print <<__EOF;
<table cellpadding=0 cellspacing=0 border=0 width=100%>
<tbody>
  <tr>
    <td><span class=titlepage>Shaper classes</span></td>
    <td align=right><a href="" class=help onClick="showHelp(); return false;"><img src="/help.gif" border=0 width=16 height=16></a></td>
  </tr>
</tbody>
</table>
<p><small>$resultString</small></p>
<table id=cTable cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;" width=400>
<tbody>
__EOF

my $classes = '';
my %cbqlist_sorted;

if (ref $cbqlist eq 'HASH')	{

	$cbqlist = copyHash($cbqlist) if (exists($cbqlist->{'class_rate_speed'}));

	foreach(keys(%$cbqlist)) {
		$cbqlist_sorted{$cbqlist->{$_}{'id'}} = $cbqlist->{$_};
		$cbqlist_sorted{$cbqlist->{$_}{'id'}}{'class_name'} = $_;
	}

	print_row($cbqlist_sorted{$_}, $cbqlist_sorted{$_}{'class_name'}) foreach(sort(keys(%cbqlist_sorted)));
}

print <<__EOF;
</tbody>
</table>
<input type=hidden name=classes value="$classes">
__EOF

if ($allowEdit)
{
	print <<__EOF;
<table cellpadding=1 cellspacing=1 border=0 style="margin: 10 0 0 10;">
<tbody>
  <tr><td colspan=2>&nbsp;</td></tr>
  <tr>
    <td colspan=2>
      <input class=control type=button name=add value="Add Item" onClick="addItem(this); return false">
      <span style="width: 8px;">&nbsp;</span>
      <input class=control type=submit name="todo"  value=Save>
    </td>
  </tr>
</tbody>
</table>
__EOF
}
print <<__EOF;
    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</form>


<div class=help style="width: 400px; height: 200px;" id=divHelp>
<table cellpadding=2 cellspacing=0 border=0 width=100%>
<tbody>
  <tr><td align=right><a href="" onclick="showHelp(); return false;" title="Close help"><img onmouseout="this.src='/close.gif'" onmouseover="this.src='/close-hover.gif'" src="/close.gif" border=0 width=16 height=16></a></a></td></tr>
</tbody>
</table>
This page manages traffic bandwidth groups.<br><br>
<b>ID</b> - hex number between 0002-FFFF. Groups are ordered by ID and the first group applies first.<br>
<b>Name</b> - your class name<br>
<br>
<b>Device Name</b> - interface name that this group applied<br>
<b>Class Rate</b> - tcp traffic bandwidth available for this group. Definition exceeding the interface bandwidth does not make any sense.<br>
<b>Priority</b> - class priority [1-8]. default 5<br>
<b>IP list</b> - a list of ip's of this group. On the ip list you can specify particular ip host address ( 192.168.1.1 ) or network range ( 192.168.1.0/24 ). One row is one ip address.
</div>


</body>
</html>
__EOF

sub populate_item
{
	my ($key, $cbqlist, $co) = (shift, shift, shift);

	$cbqlist->{$key}->{device} = $co->param($key."_dev");
	$cbqlist->{$key}->{class_rate_speed} = $co->param($key."_rate_speed");
	$cbqlist->{$key}->{class_rate_dim} = $co->param($key."_rate_dim");
	$cbqlist->{$key}->{prio} = $co->param($key."_prio");
	$cbqlist->{$key}->{ip} = $co->param($key."_rules");
	$cbqlist->{$key}->{name} = $key =~ /\&\&temp\&\&/?$co->param($key."_name"):$key;
	$cbqlist->{$key}->{id} = $co->param($key."_id") if $co->param($key."_id");

	$cbqlist->{$key}->{ip} =~ s/\r//g;

	return validate($cbqlist->{$key});
}


sub validate
{
	my $item = shift;
	my ($l_error);
	$l_error .= "<br>Incorrect device name" if (!$item->{device});
	$l_error .= "<br>Rate speed should be number" if (!$item->{class_rate_speed} || $item->{class_rate_speed} =~ /\D/);
	$l_error .= "<br>Incorrect rate size" if (!$item->{class_rate_dim} || $item->{class_rate_dim} =~ /\W/);
	$l_error .= "<br>Rate speed should be more > 10 if rate size is Bit. Correct speed or size." if ($item->{class_rate_dim} eq 'b' && $item->{class_rate_speed} =~ /^\d$/);
	$l_error .= "<br>Priority should be number" if (!$item->{prio} || $item->{prio} =~ /\D/);
	$l_error .= "<br>Incorrect rules" if (!$item->{ip} || $item->{ip} =~ /[^\d\.\n\r\:\/\,\s]/);
	$l_error .= "<br>Class Id hould be hex number from 0000 to FFFFF" if (!$item->{id} && $item->{id} =~ /[0-9,a-f,A-F]{4}/);
	$l_error .= "<br>Incorrect class name" if (!$item->{name} && $item->{name} =~ /[0-9,a-f,A-F]/);

	$l_error && return "<div style='padding-left: 5px;'>Class <b>$item->{name}</b> validate:<div style='padding-left: 5px;'>$l_error</div></div>";
	return "";
}

sub copyHash
{
	my $cbqlist = shift;
	my $_cbqlist;
	$_cbqlist->{$cbqlist->{'name'}} = {
		'device' => $cbqlist->{'name'},
		'class_rate_speed' => $cbqlist->{'class_rate_speed'},
		'class_rate_dim' => $cbqlist->{'class_rate_dim'},
		'prio' => $cbqlist->{'prio'},
		'ip' => $cbqlist->{'ip'},
		'name' => $cbqlist->{'name'},
		'id' => $cbqlist->{'id'}
	};
	return $_cbqlist;

}

sub print_row
{
	my $name = !$_[1]?$_[0]->{name}:$_[1];
	$name = $_[0]->{name} if ($name =~ /\&\&temp\&\&/);
print <<__EOF;
  <tr height=25 id=tr_${\$name} name="tr_${\$name}" onmouseover="ovrMouse(this);" onmouseout="outMouse(this);" bgcolor=#ffffff><td 
width=10 valign=top style="padding-top: 15px;"><a href="" onClick="delItem(this); return false;" style="visibility: hidden;"><img src="$ck{include_dir}delete.gif" border=0></a></td><td 
style="border: 1px #eeeeee solid;" valign=top>
<table cellpadding=1 cellspacing=1 border=0>
<tbody>
  <tr>
    <td>&nbsp;ID:</td>
    <td>&nbsp;${\$_[0]->{id}}</td>
  </tr>
  <tr>
    <td>&nbsp;Name</td>
    <td>&nbsp;<a href="" class=grid onClick="chView('$name'); return false;">$name</a></td>
  </tr>
</tbody>
</table>
<table cellpadding=0 cellspacing=0 border=0 width=100% id=class_${\$name} style="display: none; padding: 5 5 5 5;" bgcolor=#eeeeee>
<tbody>

  <tr height=25>
    <td>&nbsp;Device Name:<td>
    <td>
      <select class="control" name=${\$name}_dev>
__EOF
	print "<option value='$_' ".${\($_ eq $_[0]->{device}?'selected':'')}.">$_</option>" for (keys %$isp_list);
	print <<__EOF;
      </select>
    </td>
  </tr>
  <tr height=25>
    <td>&nbsp;Class Rate:<td>
    <td><input class=control type=text name=${\$name}_rate_speed value="${\$_[0]->{class_rate_speed}}" maxlength=50 size=10>
      <select class="control" name=${\$name}_rate_dim class=control>
        <option value="Mbit" ${\(($_[0]->{class_rate_dim} eq 'Mbit')?'selected':'')}>MBit
        <option value="Kbit" ${\(($_[0]->{class_rate_dim} eq 'Kbit')?'selected':'')}>KBit
        <option value="b" ${\(($_[0]->{class_rate_dim} eq 'b')?'selected':'')}>Bit
      </select>
    </td>
  </tr>
  <tr height=25>
    <td>&nbsp;Priority:<td>
    <td><input class=control type=text name=${\$name}_prio value="${\$_[0]->{prio}}" maxlength=50 size=10></td>
  </tr>
  <tr height=25>
    <td valign=top>&nbsp;IP list:<td>
    <td><textarea class=control name=${\$name}_rules cols=25 rows=3>${\$_[0]->{ip}}</textarea></td>
  </tr>
</tbody>
</table>

</td></tr>
__EOF
}

__END__
