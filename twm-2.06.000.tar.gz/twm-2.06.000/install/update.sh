#!/bin/bash

cd ../
update_folder=/root/TWM/update
version=`cat version.conf | grep "version=" | sed -e "s/version=//g"`

rm -Rf $update_folder
mkdir $update_folder

cd /root/TWM/release
find . -type d | while read item ; do
	mkdir $update_folder/$item
done
find . -mtime -10 -type f  | while read item ; do
	cp -Rf $item $update_folder/$item
done
cd /usr/local/twm/install

find $update_folder -type d -empty | xargs rm -Rf

cd /root/TWM/
mv update twm-$version-update
tar -czf twm-$version-update.tar.gz twm-$version-update
