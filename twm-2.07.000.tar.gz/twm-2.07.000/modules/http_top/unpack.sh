#!/bin/bash

if [ ! $# -eq 2 ]; then
    echo "Usage: $0 TWM_folder log_folder"
    exit
fi

tar=`perl $1/bin/get_varValue.pl tar`

$tar -xzf $1/modules/http_top/logs/$2 -C $1/modules/http_top/logs/;
