#!/bin/bash

perl $TWMFOLDER/modules/shaping_cbq/build_cbq.pl
$TWMFOLDER/modules/shaping_cbq/cbq.init compile nocache
$TWMFOLDER/modules/shaping_cbq/cbq.init restart nocache

exit 0
