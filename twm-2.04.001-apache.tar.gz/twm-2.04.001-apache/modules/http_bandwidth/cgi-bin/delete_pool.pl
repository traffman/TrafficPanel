#!/usr/bin/perl -w

BEGIN	{
	(my $file = __FILE__)=~ s/modules\/.+?\/.\w+\.pl$//;
	unshift(@INC, $file);
}

use strict;
use Data::Dumper;
use CGI;
use TWM;
if (isDebug())
{
	use CGI::Carp qw(fatalsToBrowser);
}
use Bandwidth;
$ck{print_stdout} = 0;
&checkAuthorization;
my $allowEdit = &hasManagerAccess;
my $co = new CGI;
my $name = $co->param('name');
my $objBandWidth = Bandwidth->new();

print "Content-Type: text/xml\n\n";
my $xml = &readModuleConfigFile($cm{pools_config});

my ($status, $message) = ('true', '');
if ($allowEdit && ref $xml->{pool} eq 'HASH')
{
	if (exists($xml->{pool}->{name}) && $name eq $xml->{pool}->{name})
	{
		if ($xml->{pool}->{readonly} eq 'false')
		{
			$xml->{pool} = ();
		}
		else
		{
			($status, $message) = ('false', 'You can not remove readonly pool');
		}
	}
	else
	{
		if (exists($xml->{pool}->{$name}))
		{
			if ($xml->{pool}->{$name}->{readonly} eq 'false')
			{
				delete $xml->{pool}->{$name};
			}
			else
			{
				($status, $message) = ('false', 'You can not remove readonly pool');
			}
		}
		else
		{
			($status, $message) = ('false', 'Pool file was not found');
		}
	}
}
elsif (!$allowEdit)
{
	($status, $message) = ('false', 'Access denied');
}
else
{
	($status, $message) = ('false', 'Pool list is empty');
}

if ($status eq 'true')
{
	$objBandWidth->savePool($xml, 1);
	keepHistory("Deleted $name\n".Dumper($xml));
}

print <<__EOF;
<?xml version="1.0" standalone="yes"?>
<response>
  <status>$status</status>
  <message>$message</message>
</response>
__EOF
