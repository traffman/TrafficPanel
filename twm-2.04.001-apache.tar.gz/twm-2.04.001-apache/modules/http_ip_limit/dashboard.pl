#!/usr/bin/perl -w

BEGIN   
{
	sub getPoints{return '../../' if (!$_[1]);return '../' if (!$_[0]);return '/';}
	(my $file = __FILE__) =~ s/\/?(modules\/)?(http_ip_limit\/)?(\w+\.pl)$/&getPoints($1,$2)/e;
	$file = './' if $file eq '/';
	unshift(@INC, $file."bin");
	unshift(@INC, $file.'modules/http_ip_limit');
	unshift(@INC, $file.'modules/http_bandwidth');
}

use strict;
use TWM;
use IPLimit;
use Bandwidth;

my $host = $ARGV[0];

exit unless $host;

print <<__EOF;
fullrow=0

__EOF

print <<__EOF;
  <div class="paneltitle"><span class="paneltitlerow">HTTP Amount Limitation</span></div>
  <div class="panelcontent">
    <div class="panelcontentrow">

__EOF

my $objIPLimit = IPLimit->new();
my $blockedlist = $objIPLimit->get_blocked_list();

my $xml = &readModuleConfigFile($cm{restriction_file});
my $areas = $xml->{'pc'};
$areas = [$areas] if ref $areas eq 'HASH';

my %usedTraffic = %{$objIPLimit->load_total()};
print_row($host, $usedTraffic{$host});

print <<__EOF;

</div>
  </div>
__EOF

sub print_row
{
	my ($ip, $used) = (shift, shift);
	my $available = get_available_value($areas, $ip);
	my $status = in_array($blockedlist,$ip)?"<div class=warning>HTTP traffic is blocked</div>":"<div>HTTP traffic is not blocked</div>";
	print <<__EOF;
$status
<div>Defined HTTP traffic limit is $available MB</div>
<div>Used ${\getHumanTrafficNumber($used, 'm')} MB</div>
__EOF
}

sub get_available_value
{
    foreach (@{$_[0]})
    {
        return $_->{size} if ($_->{ip} eq $_[1]);
    }
    return $cm{default_amount};
}

__END__
